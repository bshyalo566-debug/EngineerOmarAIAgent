# Changelog

All notable changes to **Engineer Omar AI Agent** are documented here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned
- Neural on-device LLM backend (llama.cpp / MLC) behind the existing `AiProvider` interface.
- Room FTS4 → FTS5 upgrade path with migration test.
- WorkManager-driven periodic Knowledge-Base reindex.

## [1.0.0] — 2026-07-19

### Added — Core platform
- **Clean Architecture** foundation: domain (pure Kotlin) / data / presentation layers with a unidirectional dependency rule.
- **MVVM + Compose** UI: Material 3 "Luxury Black + Gold" theme with full **RTL/LTR** (Arabic + English) localization.
- **Hilt** dependency graph (App, Database, Network, Repository, Executor modules).
- **Room** offline-first database with 8 entities + DAOs covering projects, conversations, messages, knowledge (with FTS4), command logs, memory, and file items.
- **EncryptedSharedPreferences** + Android Keystore for secrets; optional **biometric / PIN** lock at launch.

### Added — Engineering modules
- **AI Engineering Agent** with provider abstraction (OpenAI, on-device local), long-term memory, and the 8-stage **Command Engine** pipeline (Intent → Plan → Permission → Execute → Verify → Log → Report).
- **Local AI provider** — fully offline completion engine (template model + n-gram Markov + rule-based review/explain) with zero network dependency.
- **Code Editor** — regex syntax highlighter (12 languages) via `VisualTransformation`, debounced diagnostics, formatter, find/replace, autocomplete, minimap, tabs, dark/light editor themes.
- **File Manager** — browse, copy/move/rename/delete, ZIP compress/extract (zip-slip guarded), search, favorites, recent.
- **Git Engine** — full JGit integration: init, clone, status, add, commit, push, pull, fetch, checkout, merge, branches, log, diff.
- **GitHub API** — Retrofit client with PAT auth interceptor: user, repos, create repo, commits, PRs, issues, releases.
- **Knowledge Base** — PDF (PDFBox-Android) / Markdown / TXT / DOCX extraction, FTS4 keyword + offline TF-IDF **semantic search**.
- **Voice Assistant** — `SpeechRecognizer` STT + `TextToSpeech` TTS (Arabic + English).
- **Floating Assistant** — `SYSTEM_ALERT_WINDOW` overlay bubble + Compose panel with full lifecycle/saved-state wiring.
- **Plugin SDK** — sandboxed `PluginContext` with per-permission capability gating.
- **Android Automation** — official-intents-only surface (open URL/app, share via FileProvider, clipboard, notifications).

### Added — Engineering rigour
- **ProGuard/R8** rules for every dependency; release build with `isMinifyEnabled` + `isShrinkResources`.
- **`standard` / `fdroid` product flavors**; debug/release build types with optional keystore signing.
- **GitHub Actions CI/CD**: lint → test → debug APK on every push; signed AAB/APK on version tags.
- Comprehensive **unit-test suite** covering the command engine, highlighter, formatter, diagnostics, find/replace, TF-IDF index, mappers, repositories, and ViewModels.
- Full **documentation suite**: architecture, folder structure, DB schema, developer guide, deployment guide, security, testing, user manual (EN/AR), API reference.
- `bootstrap-gradle.sh` one-time wrapper generator; Android `.gitignore`; Apache 2.0 `LICENSE`; `CONTRIBUTING.md`.

### Security
- No root, no accessibility-service abuse, no cleartext traffic.
- All secrets in Keystore-backed encrypted storage; never logged.
- FileProvider with scoped `<paths>`; zip-slip path-traversal guard in extract.
- `POST_NOTIFICATIONS`, `SYSTEM_ALERT_WINDOW`, `RECORD_AUDIO`, biometric, and foreground-service permissions all requested lazily, in context.

[Unreleased]: https://github.com/engineeromar/ai-agent/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/engineeromar/ai-agent/releases/tag/v1.0.0
