# ───────────────────────────────────────────────────────────────────────
# Engineer Omar AI Agent — R8 / ProGuard rules
# ───────────────────────────────────────────────────────────────────────

# ── Optimization tuning ────────────────────────────────────────────────
# Keep annotations used for reflection (Room, Hilt, serialization).
-keepattributes *Annotation*, InnerClasses, Signature, EnclosingMethod
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations
-keepattributes RuntimeInvisibleAnnotations, RuntimeInvisibleParameterAnnotations
-dontobfuscate  # Keep symbol names for crash-report symbolication.

# ── Application entry points ───────────────────────────────────────────
-keep class com.engineeromar.aiagent.EngineerOmarApp { *; }
-keep class com.engineeromar.aiagent.MainActivity { *; }
-keep class com.engineeromar.aiagent.HiltTestRunner { *; }

# Hilt-generated sources are already obfuscation-safe, but its @HiltAndroidApp
# and the Worker classes need their default constructors preserved.
-keepclassmembers class * {
    @javax.inject.Inject <init>(...);
}
-keep,allowobfuscation,allowshrinking class kotlin.coroutines.Continuation
-keep,allowobfuscation,allowshrinking interface kotlin.coroutines.Continuation

# ── Room ───────────────────────────────────────────────────────────────
-keep class * extends androidx.room.RoomDatabase { <init>(); }
-dontwarn androidx.room.paging.**
# Room DAOs are referenced reflectively by the generated *_Impl classes.
-keep class com.engineeromar.aiagent.data.local.dao.** { *; }
-keep class com.engineeromar.aiagent.data.local.entity.** { *; }

# ── Hilt / Dagger ──────────────────────────────────────────────────────
-dontwarn com.google.errorprone.annotations.**
-dontwarn org.checkerframework.**
-keep,allowobfuscation,allowshrinking @dagger.hilt.android.HiltAndroidApp class *
-keep class dagger.hilt.** { *; }

# ── kotlinx.serialization ──────────────────────────────────────────────
-keepattributes RuntimeVisibleAnnotations,AnnotationDefault
# Keep @Serializable companion serializer() lookups.
-if @kotlinx.serialization.Serializable class **
-keepclassmembers class <1> {
    static <1>$Companion Companion;
}
-if @kotlinx.serialization.Serializable class ** {
    static **$* *;
}
-keepclassmembers class <2>$<3> {
    kotlinx.serialization.KSerializer serializer(...);
}
# Keep all DTOs used by the GitHub API.
-keep,allowobfuscation,allowshrinking class com.engineeromar.aiagent.data.remote.github.** { *; }
-keep class com.engineeromar.aiagent.data.remote.github.**$$serializer { *; }

# ── Retrofit / OkHttp ──────────────────────────────────────────────────
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}
-dontwarn org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement

# ── Coroutines ─────────────────────────────────────────────────────────
-keepclassmembers class kotlinx.coroutines.** { *; }
-dontwarn kotlinx.coroutines.**
-keep class kotlin.coroutines.intrinsics.CoroutineSingletons

# ── Compose / Material 3 ───────────────────────────────────────────────
# Compose ships its own consumer rules; nothing extra required.

# ── JGit / SLF4J ───────────────────────────────────────────────────────
-dontwarn org.eclipse.jgit.**
-dontwarn org.slf4j.**
-keep class org.eclipse.jgit.** { *; }
# JGit uses reflection to load transport/crypto factories.
-keep class org.eclipse.jgit.transport.** { *; }
-keep class org.eclipse.jgit.lib.** { *; }

# ── PDFBox-Android ─────────────────────────────────────────────────────
-dontwarn com.tom_roush.**
-keep class com.tom_roush.pdfbox.** { *; }
-keep class org.apache.fontbox.** { *; }

# ── Kotlin metadata ────────────────────────────────────────────────────
-keep class kotlin.Metadata { *; }
-keep class kotlin.Unit
-keep class kotlin.collections.**

# ── EncryptedSharedPreferences / AndroidX Security ─────────────────────
-keep class androidx.security.crypto.** { *; }

# ── ViewModels (Hilt @HiltViewModel uses reflection) ───────────────────
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    <init>();
}
-keep,allowobfuscation class com.engineeromar.aiagent.**ViewModel { *; }

# ── Plugin SDK (extension point; plugins load reflectively in future) ──
-keep class com.engineeromar.aiagent.plugin.** { *; }
