package com.engineeromar.aiagent.plugin

import com.engineeromar.aiagent.core.automation.AndroidAutomation
import com.engineeromar.aiagent.core.automation.Notifications
import com.engineeromar.aiagent.core.logging.Logger
import com.engineeromar.aiagent.data.local.db.AppDatabase
import com.engineeromar.aiagent.domain.model.PluginPermission
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Builds permission-scoped [PluginContext] instances. Each capability is
 * wrapped so access is gated by the plugin's declared permissions — a plugin
 * that did not declare NETWORK gets a `null` network capability, etc.
 */
@Singleton
class PluginContextFactory @Inject constructor(
    private val client: OkHttpClient,
    private val database: AppDatabase,
    private val automation: AndroidAutomation,
    private val notifications: Notifications,
) {
    fun create(permissions: Set<PluginPermission>): PluginContext = PluginContextImpl(permissions)

    private inner class PluginContextImpl(
        override val permissions: Set<PluginPermission>,
    ) : PluginContext {

        override fun network(): PluginNetwork? =
            if (PluginPermission.NETWORK in permissions) PluginNetworkImpl(client) else null

        override fun fileAccess(): PluginFileAccess? =
            if (PluginPermission.FILE_READ in permissions || PluginPermission.FILE_WRITE in permissions)
                PluginFileAccessImpl(permissions) else null

        override fun database(): PluginDatabase? =
            if (PluginPermission.DATABASE in permissions) PluginDatabaseImpl(database) else null

        override fun ai(): PluginAi? =
            if (PluginPermission.AI_PROVIDER in permissions) PluginAiImpl() else null

        override fun clipboard(): PluginClipboard? =
            if (PluginPermission.CLIPBOARD in permissions) PluginClipboardImpl(automation) else null

        override fun notifications(): PluginNotifications? =
            if (PluginPermission.NOTIFICATIONS in permissions) PluginNotificationsImpl(notifications) else null
    }

    private class PluginNetworkImpl(private val client: OkHttpClient) : PluginNetwork {
        override suspend fun get(url: String): String = withContext(Dispatchers.IO) {
            client.newCall(okhttp3.Request.Builder().url(url).build()).execute().use { it.body?.string().orEmpty() }
        }
        override suspend fun post(url: String, body: String, contentType: String): String = withContext(Dispatchers.IO) {
            val req = okhttp3.Request.Builder().url(url)
                .post(body.toRequestBody(contentType.toMediaType())).build()
            client.newCall(req).execute().use { it.body?.string().orEmpty() }
        }
    }

    private class PluginFileAccessImpl(private val perms: Set<PluginPermission>) : PluginFileAccess {
        override fun read(path: String): String {
            require(PluginPermission.FILE_READ in perms)
            return File(path).readText()
        }
        override fun write(path: String, content: String) {
            require(PluginPermission.FILE_WRITE in perms)
            File(path).writeText(content)
        }
        override fun list(directory: String): List<String> {
            require(PluginPermission.FILE_READ in perms)
            return File(directory).listFiles()?.map { it.absolutePath } ?: emptyList()
        }
        private fun require(p: PluginPermission) {
            if (p !in perms) throw PluginSecurityException("Missing $p")
        }
    }

    private class PluginDatabaseImpl(private val db: AppDatabase) : PluginDatabase {
        override suspend fun query(sql: String, vararg args: Any): List<Map<String, Any?>> = withContext(Dispatchers.IO) {
            // Read-only raw query surface for plugins; writes go through declared DAOs.
            db.openHelper.readableDatabase.query(sql, args.map { it.toString() }.toTypedArray()).use { cursor ->
                val rows = ArrayList<Map<String, Any?>>(cursor.count)
                while (cursor.moveToNext()) {
                    val row = LinkedHashMap<String, Any?>()
                    for (i in 0 until cursor.columnCount) {
                        row[cursor.getColumnName(i)] = when (cursor.getType(i)) {
                            android.database.Cursor.FIELD_TYPE_INTEGER -> cursor.getLong(i)
                            android.database.Cursor.FIELD_TYPE_FLOAT -> cursor.getDouble(i)
                            android.database.Cursor.FIELD_TYPE_BLOB -> cursor.getBlob(i)
                            else -> if (cursor.isNull(i)) null else cursor.getString(i)
                        }
                    }
                    rows.add(row)
                }
                rows
            }
        }
    }

    private class PluginAiImpl : PluginAi {
        override suspend fun complete(prompt: String, maxTokens: Int): String {
            // Delegates to the active provider via the agent; here returns a
            // structured note so plugin authors wire their own provider if needed.
            Logger.i("PluginAi") { "Plugin AI request (${prompt.length} chars)" }
            return "Plugin AI requires a configured provider — implement via AiProviderFactory."
        }
    }

    private class PluginClipboardImpl(private val automation: AndroidAutomation) : PluginClipboard {
        override fun copy(text: String) = automation.copyToClipboard("plugin", text)
        override fun paste(): String = ""
    }

    private class PluginNotificationsImpl(private val notifications: Notifications) : PluginNotifications {
        override fun show(title: String, body: String) = notifications.show(title.hashCode(), title, body)
    }
}
