package com.engineeromar.aiagent.feature.filemanager

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.engineeromar.aiagent.core.storage.StorageDirectories
import com.engineeromar.aiagent.domain.model.FileItem
import com.engineeromar.aiagent.domain.model.FileOperationResult
import com.engineeromar.aiagent.domain.model.SortOrder
import com.engineeromar.aiagent.domain.usecase.file.CompressUseCase
import com.engineeromar.aiagent.domain.usecase.file.CopyFileUseCase
import com.engineeromar.aiagent.domain.usecase.file.CreateDirectoryUseCase
import com.engineeromar.aiagent.domain.usecase.file.DeleteFileUseCase
import com.engineeromar.aiagent.domain.usecase.file.ExtractUseCase
import com.engineeromar.aiagent.domain.usecase.file.ListDirectoryUseCase
import com.engineeromar.aiagent.domain.usecase.file.MoveFileUseCase
import com.engineeromar.aiagent.domain.usecase.file.RenameFileUseCase
import com.engineeromar.aiagent.domain.usecase.file.SearchFilesUseCase
import com.engineeromar.aiagent.domain.usecase.file.ToggleFavoriteUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class FileManagerViewModel @Inject constructor(
    private val storage: StorageDirectories,
    private val listDir: ListDirectoryUseCase,
    private val createDir: CreateDirectoryUseCase,
    private val rename: RenameFileUseCase,
    private val copy: CopyFileUseCase,
    private val move: MoveFileUseCase,
    private val delete: DeleteFileUseCase,
    private val compress: CompressUseCase,
    private val extract: ExtractUseCase,
    private val search: SearchFilesUseCase,
    private val toggleFavorite: ToggleFavoriteUseCase,
) : ViewModel() {

    private val _current = MutableStateFlow(storage.root.absolutePath)
    val current: StateFlow<String> = _current.asStateFlow()

    private val _items = MutableStateFlow<List<FileItem>>(emptyList())
    val items: StateFlow<List<FileItem>> = _items.asStateFlow()

    private val _sortOrder = MutableStateFlow(SortOrder.NAME_ASC)
    val sortOrder: StateFlow<SortOrder> = _sortOrder.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _results = MutableStateFlow<List<FileItem>>(emptyList())
    val results: StateFlow<List<FileItem>> = _results.asStateFlow()

    private val _lastResult = MutableStateFlow<FileOperationResult?>(null)
    val lastResult: StateFlow<FileOperationResult?> = _lastResult.asStateFlow()

    init { refresh() }

    fun navigateTo(path: String) { _current.value = path; refresh() }

    fun up() {
        val parent = java.io.File(_current.value).parentFile ?: return
        if (parent.canRead()) navigateTo(parent.absolutePath)
    }

    fun setSortOrder(order: SortOrder) { _sortOrder.value = order; refresh() }

    fun onQueryChange(q: String) {
        _query.value = q
        viewModelScope.launch {
            _results.value = if (q.isBlank()) emptyList() else search(_current.value, q)
        }
    }

    fun refresh() = viewModelScope.launch {
        _items.value = listDir(_current.value, _sortOrder.value)
    }

    fun createDirectory(name: String) = viewModelScope.launch {
        val path = java.io.File(_current.value, name).absolutePath
        _lastResult.value = createDir(path); refresh()
    }

    fun rename(item: FileItem, newName: String) = viewModelScope.launch {
        _lastResult.value = rename(item.path, newName); refresh()
    }

    fun copy(item: FileItem, destDir: String) = viewModelScope.launch {
        _lastResult.value = copy(item.path, java.io.File(destDir, item.name).absolutePath); refresh()
    }

    fun move(item: FileItem, destDir: String) = viewModelScope.launch {
        _lastResult.value = move(item.path, java.io.File(destDir, item.name).absolutePath); refresh()
    }

    fun delete(item: FileItem) = viewModelScope.launch {
        _lastResult.value = delete(item.path); refresh()
    }

    fun compress(items: List<FileItem>, destZip: String) = viewModelScope.launch {
        _lastResult.value = compress(items.map { it.path }, destZip); refresh()
    }

    fun extract(zip: FileItem, destDir: String) = viewModelScope.launch {
        _lastResult.value = extract(zip.path, destDir); refresh()
    }

    fun toggleFavorite(item: FileItem) = viewModelScope.launch {
        _lastResult.value = toggleFavorite(item.path); refresh()
    }
}
