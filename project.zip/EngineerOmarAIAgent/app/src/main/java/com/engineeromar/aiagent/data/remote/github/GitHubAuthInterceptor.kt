package com.engineeromar.aiagent.data.remote.github

import com.engineeromar.aiagent.core.security.SecureStorage
import okhttp3.Interceptor
import okhttp3.Response
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Attaches the GitHub Personal Access Token to every request as a Bearer
 * header + the API version + UA headers GitHub requires. The token is read
 * lazily per call from [SecureStorage]; never held in a field.
 */
@Singleton
class GitHubAuthInterceptor @Inject constructor(
    private val storage: SecureStorage,
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val token = storage.get(SecureStorage.KEY_GITHUB_PAT)
        val request = chain.request().newBuilder()
            .apply {
                if (!token.isNullOrEmpty()) header("Authorization", "Bearer $token")
                header("Accept", "application/vnd.github+json")
                header("X-GitHub-Api-Version", "2022-11-28")
                header("User-Agent", "EngineerOmarAIAgent")
            }
            .build()
        return chain.proceed(request)
    }
}
