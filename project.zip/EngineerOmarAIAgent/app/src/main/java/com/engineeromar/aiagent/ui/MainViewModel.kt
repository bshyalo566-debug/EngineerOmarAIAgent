package com.engineeromar.aiagent.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.engineeromar.aiagent.core.config.AppConfig
import com.engineeromar.aiagent.core.config.ConfigurationManager
import com.engineeromar.aiagent.core.config.Language
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class MainViewModel @Inject constructor(
    configManager: ConfigurationManager,
) : ViewModel() {
    val config: StateFlow<AppConfig?> = configManager.config
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val language: Language get() = config.value?.language ?: Language.ENGLISH
}
