package com.engineeromar.aiagent.ai.memory

import com.engineeromar.aiagent.data.local.dao.MemoryDao
import com.engineeromar.aiagent.data.local.entity.MemoryEntity
import com.engineeromar.aiagent.domain.model.MemoryScope
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The Agent's long-term memory. Stores and retrieves scoped facts, preferences,
 * patterns, and recurring commands. Used to prime the AI context window so the
 * agent remembers the user, the project, and prior decisions — all on-device.
 */
@Singleton
class MemoryManager @Inject constructor(
    private val dao: MemoryDao,
) {
    suspend fun remember(
        scope: MemoryScope,
        category: String,
        content: String,
        importance: Int = 3,
    ): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        dao.upsert(
            MemoryEntity(
                id = id, scope = scope.raw, category = category, content = content,
                importance = importance.coerceIn(1, 5), createdAt = now, lastAccessedAt = now,
            )
        )
        return id
    }

    suspend fun recall(scope: MemoryScope, limit: Int = 8): List<MemoryEntity> {
        val items = dao.topForScope(scope.raw, limit)
        val now = System.currentTimeMillis()
        items.forEach { dao.touch(it.id, now) }
        return items
    }

    suspend fun search(query: String): List<MemoryEntity> = dao.search(query)

    suspend fun forget(id: String) = dao.delete(id)

    /** Builds a compact context block injected into AI prompts. */
    suspend fun contextBlock(scope: MemoryScope): String =
        recall(scope).takeIf { it.isNotEmpty() }?.joinToString("\n") { "- (${it.category}) ${it.content}" }
            ?: "No prior context."
}
