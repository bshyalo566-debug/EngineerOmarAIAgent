package com.engineeromar.aiagent.data.repository

import com.engineeromar.aiagent.core.error.AppError
import com.engineeromar.aiagent.data.remote.github.CreateRepoDto
import com.engineeromar.aiagent.data.remote.github.GitHubApi
import com.engineeromar.aiagent.domain.model.CreateRepositoryInput
import com.engineeromar.aiagent.domain.model.GitHubAsset
import com.engineeromar.aiagent.domain.model.GitHubCommit
import com.engineeromar.aiagent.domain.model.GitHubIssue
import com.engineeromar.aiagent.domain.model.GitHubPullRequest
import com.engineeromar.aiagent.domain.model.GitHubRelease
import com.engineeromar.aiagent.domain.model.GitHubRepository
import com.engineeromar.aiagent.domain.model.GitHubUser
import com.engineeromar.aiagent.domain.repository.GitHubRepository as GitHubRepoContract
import com.engineeromar.aiagent.domain.util.Result
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Singleton
class GitHubRepositoryImpl @Inject constructor(
    private val api: GitHubApi,
) : GitHubRepoContract {

    private val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    override suspend fun currentUser(): Result<GitHubUser> = withContext(Dispatchers.IO) {
        val resp = runCatching { api.currentUser() }
            .getOrElse { return@withContext Result.Failure(it.toAppError()) }
        resp.fold({ Result.Success(it.toDomain()) }, { Result.Failure(it) })
    }

    override suspend fun listRepositories(page: Int, perPage: Int): Result<List<GitHubRepository>> =
        withContext(Dispatchers.IO) {
            val resp = runCatching { api.listRepos(page, perPage) }
                .getOrElse { return@withContext Result.Failure(it.toAppError()) }
            resp.fold(
                onSuccess = { list -> Result.Success(list.map { it.toDomain() }) },
                onFailure = { Result.Failure(it) },
            )
        }

    override suspend fun createRepository(input: CreateRepositoryInput): Result<GitHubRepository> =
        withContext(Dispatchers.IO) {
            val resp = runCatching {
                api.createRepo(
                    CreateRepoDto(
                        name = input.name,
                        description = input.description,
                        private = input.isPrivate,
                        autoInit = input.autoInit,
                        gitignoreTemplate = input.gitignoreTemplate,
                    )
                )
            }.getOrElse { return@withContext Result.Failure(it.toAppError()) }
            resp.fold({ Result.Success(it.toDomain()) }, { Result.Failure(it) })
        }

    override suspend fun getRepository(owner: String, repo: String): Result<GitHubRepository> =
        withContext(Dispatchers.IO) {
            val resp = runCatching { api.getRepo(owner, repo) }
                .getOrElse { return@withContext Result.Failure(it.toAppError()) }
            resp.fold({ Result.Success(it.toDomain()) }, { Result.Failure(it) })
        }

    override suspend fun listCommits(owner: String, repo: String, branch: String?): Result<List<GitHubCommit>> =
        withContext(Dispatchers.IO) {
            val resp = runCatching { api.listCommits(owner, repo, branch) }
                .getOrElse { return@withContext Result.Failure(it.toAppError()) }
            resp.fold(
                onSuccess = { list -> Result.Success(list.map { it.toDomain() }) },
                onFailure = { Result.Failure(it) },
            )
        }

    override suspend fun listPullRequests(owner: String, repo: String, state: String): Result<List<GitHubPullRequest>> =
        withContext(Dispatchers.IO) {
            val resp = runCatching { api.listPulls(owner, repo, state) }
                .getOrElse { return@withContext Result.Failure(it.toAppError()) }
            resp.fold(
                onSuccess = { list -> Result.Success(list.map { it.toDomain() }) },
                onFailure = { Result.Failure(it) },
            )
        }

    override suspend fun listIssues(owner: String, repo: String, state: String): Result<List<GitHubIssue>> =
        withContext(Dispatchers.IO) {
            val resp = runCatching { api.listIssues(owner, repo, state) }
                .getOrElse { return@withContext Result.Failure(it.toAppError()) }
            resp.fold(
                onSuccess = { list -> Result.Success(list.map { it.toDomain() }) },
                onFailure = { Result.Failure(it) },
            )
        }

    override suspend fun listReleases(owner: String, repo: String): Result<List<GitHubRelease>> =
        withContext(Dispatchers.IO) {
            val resp = runCatching { api.listReleases(owner, repo) }
                .getOrElse { return@withContext Result.Failure(it.toAppError()) }
            resp.fold(
                onSuccess = { list -> Result.Success(list.map { it.toDomain() }) },
                onFailure = { Result.Failure(it) },
            )
        }

    override suspend fun isTokenValid(): Result<Boolean> = withContext(Dispatchers.IO) {
        val resp = runCatching { api.currentUser() }
            .getOrElse { return@withContext Result.Failure(it.toAppError()) }
        Result.Success(resp.isSuccessful)
    }

    // ── mappers ────────────────────────────────────────────────────────

    private fun retrofit2.Response<*>.failure(): AppError.Network {
        val body = runCatching { errorBody()?.string() }.getOrNull()
        return AppError.Network("GitHub ${code()}: ${body?.take(300) ?: message()}")
    }

    private fun <T : Any, R> retrofit2.Response<T>.fold(onSuccess: (T) -> R, onFailure: (AppError.Network) -> R): R =
        if (isSuccessful) {
            val body = body() ?: return onFailure(AppError.Network("GitHub empty body (${code()})"))
            onSuccess(body)
        } else {
            onFailure(failure())
        }

    private fun parseDate(s: String): java.util.Date =
        runCatching { iso.parse(s) }.getOrDefault(java.util.Date(0))

    private fun com.engineeromar.aiagent.data.remote.github.UserDto.toDomain() = GitHubUser(
        login = login, id = id, avatarUrl = avatarUrl, htmlUrl = htmlUrl,
        name = name, bio = bio, publicRepos = publicRepos, followers = followers,
    )

    private fun com.engineeromar.aiagent.data.remote.github.RepoDto.toDomain() = GitHubRepository(
        id = id, name = name, fullName = fullName, owner = owner.login,
        description = description, htmlUrl = htmlUrl, cloneUrl = cloneUrl,
        isPrivate = `private`, isFork = fork, defaultBranch = defaultBranch,
        stars = stars, forks = forks, language = language, updatedAt = parseDate(updatedAt),
    )

    private fun com.engineeromar.aiagent.data.remote.github.CommitDto.toDomain() = GitHubCommit(
        sha = sha, shortSha = sha.take(7),
        message = commit.message, author = commit.author.name,
        date = parseDate(commit.author.date), htmlUrl = htmlUrl,
    )

    private fun com.engineeromar.aiagent.data.remote.github.PullDto.toDomain() = GitHubPullRequest(
        number = number, title = title, state = state, isDraft = draft,
        user = user?.login ?: "", headBranch = head.ref, baseBranch = base.ref,
        htmlUrl = htmlUrl, updatedAt = parseDate(updatedAt),
    )

    private fun com.engineeromar.aiagent.data.remote.github.IssueDto.toDomain() = GitHubIssue(
        number = number, title = title, state = state, body = body,
        user = user?.login ?: "", labels = labels.map { it.name },
        htmlUrl = htmlUrl, updatedAt = parseDate(updatedAt),
    )

    private fun com.engineeromar.aiagent.data.remote.github.ReleaseDto.toDomain() = GitHubRelease(
        id = id, tagName = tagName, name = name, body = body,
        isPrerelease = prerelease, isDraft = draft, htmlUrl = htmlUrl,
        publishedAt = publishedAt?.let(::parseDate),
        assets = assets.map {
            GitHubAsset(
                id = it.id, name = it.name, downloadUrl = it.downloadUrl,
                sizeBytes = it.size, downloadCount = it.downloadCount,
            )
        },
    )
}
