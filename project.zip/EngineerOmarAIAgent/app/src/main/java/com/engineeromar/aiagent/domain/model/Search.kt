package com.engineeromar.aiagent.domain.model

/**
 * A ranked search hit. [score] is the retrieval score (TF-IDF cosine for the
 * offline semantic index, or FTS rank for keyword search). Both surfaces
 * return this type so the UI binds one model.
 */
data class SearchResult(
    val documentId: String,
    val title: String,
    val category: KnowledgeCategory,
    val fileType: KnowledgeFileType,
    val snippet: String,
    val score: Float,
    val filePath: String,
)

/** A tokenised chunk of a document used for indexing and snippet rendering. */
data class DocumentChunk(
    val documentId: String,
    val ordinal: Int,
    val text: String,
    val tokenCount: Int,
)
