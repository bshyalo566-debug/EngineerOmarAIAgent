package com.engineeromar.aiagent.plugin

import com.engineeromar.aiagent.ai.engine.ExecutionPlan
import com.engineeromar.aiagent.ai.engine.ExecutionResult
import com.engineeromar.aiagent.domain.model.PluginManifest
import com.engineeromar.aiagent.domain.model.PluginPermission

/**
 * Contract a plugin implements to extend the agent. A plugin is granted a
 * sandboxed [PluginContext] whose capabilities are limited to the permissions
 * declared in its manifest. Plugins are loaded dynamically and isolated from
 * the core — they cannot touch subsystems they did not declare.
 *
 * Lifecycle:
 *   [onLoad] → [onEnable] … [onDisable] → [onUnload]
 */
interface Plugin {

    val manifest: PluginManifest

    /** Called once after instantiation; perform one-time setup. Return false to fail load. */
    suspend fun onLoad(context: PluginContext): Boolean

    suspend fun onEnable() {}
    suspend fun onDisable() {}

    /**
     * Optional command handler. Returning null means the plugin declines to
     * handle the request; the registry continues to the next plugin or the
     * default agent path.
     */
    suspend fun handle(request: String, plan: ExecutionPlan): ExecutionResult? = null

    /** Called when the plugin is unloaded (disabled / app shutdown). */
    fun onUnload() {}
}

/**
 * Capability surface exposed to plugins. Each capability checks the granted
 * permissions and throws [PluginSecurityException] if undeclared — defence in
 * depth so a buggy/malicious plugin cannot escape its declared scope.
 */
interface PluginContext {
    val permissions: Set<PluginPermission>

    fun network(): PluginNetwork?
    fun fileAccess(): PluginFileAccess?
    fun database(): PluginDatabase?
    fun ai(): PluginAi?
    fun clipboard(): PluginClipboard?
    fun notifications(): PluginNotifications?
}

class PluginSecurityException(message: String) : SecurityException(message)
