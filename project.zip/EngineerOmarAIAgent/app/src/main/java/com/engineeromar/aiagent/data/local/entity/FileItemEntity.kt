package com.engineeromar.aiagent.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * File-Manager index entry. Mirrors frequently-accessed files so the File
 * Manager + Code Editor can offer search/favorites/recent without repeated
 * disk walks. Real files live on disk; this is a metadata cache.
 */
@Entity(
    tableName = "file_items",
    indices = [Index("path", unique = true), Index("projectId"), Index("isFavorite"), Index("lastOpenedAt")],
)
data class FileItemEntity(
    @PrimaryKey val id: String,
    val path: String,               // canonical absolute path
    val name: String,
    val ext: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val projectId: String?,
    val isFavorite: Boolean = false,
    val lastOpenedAt: Long? = null,
    val mimeType: String? = null,
)
