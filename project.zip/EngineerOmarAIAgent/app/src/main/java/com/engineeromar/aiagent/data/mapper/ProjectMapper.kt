package com.engineeromar.aiagent.data.mapper

import com.engineeromar.aiagent.data.local.entity.ProjectEntity
import com.engineeromar.aiagent.domain.model.Project
import com.engineeromar.aiagent.domain.model.ProjectStatus

fun ProjectEntity.toDomain(): Project = Project(
    id = id,
    name = name,
    description = description,
    rootPath = rootPath,
    techStack = techStack,
    language = language,
    status = runCatching { ProjectStatus.valueOf(status.uppercase()) }.getOrDefault(ProjectStatus.ACTIVE),
    repoUrl = repoUrl,
    createdAt = createdAt,
    updatedAt = updatedAt,
    pinned = pinned,
    color = color,
)

fun Project.toEntity(): ProjectEntity = ProjectEntity(
    id = id,
    name = name,
    description = description,
    rootPath = rootPath,
    techStack = techStack,
    language = language,
    status = status.name.lowercase(),
    repoUrl = repoUrl,
    createdAt = createdAt,
    updatedAt = updatedAt,
    pinned = pinned,
    color = color,
)
