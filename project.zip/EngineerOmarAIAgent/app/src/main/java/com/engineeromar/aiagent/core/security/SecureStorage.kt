package com.engineeromar.aiagent.core.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Encrypted key/value store for secrets — API keys, OAuth tokens, GitHub PATs.
 * Backed by EncryptedSharedPreferences (AES-GCM 256, AES-SIV-CMAC256 keys),
 * keys in the Android Keystore. Never log values from this store.
 */
@Singleton
class SecureStorage @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val masterKey: MasterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs by lazy {
        EncryptedSharedPreferences.create(
            context, SECURE_FILE, masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    fun put(key: String, value: String) = prefs.edit().putString(key, value).apply()
    fun get(key: String): String? = prefs.getString(key, null)
    fun remove(key: String) = prefs.edit().remove(key).apply()
    fun contains(key: String): Boolean = prefs.contains(key)

    /** Wipe all secrets — used by the "lock app" / "reset secrets" actions. */
    fun clear() = prefs.edit().clear().apply()

    companion object {
        const val SECURE_FILE = "eo_secure"
        const val KEY_OPENAI_API_KEY = "openai_api_key"
        const val KEY_ANTHROPIC_API_KEY = "anthropic_api_key"
        const val KEY_GEMINI_API_KEY = "gemini_api_key"
        const val KEY_GITHUB_PAT = "github_pat"
        const val KEY_APP_PIN_HASH = "app_pin_hash"
        const val KEY_BACKUP_PASSPHRASE = "backup_passphrase"
    }
}
