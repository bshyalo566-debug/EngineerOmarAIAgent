package com.engineeromar.aiagent.data.repository

import com.engineeromar.aiagent.core.error.AppError
import com.engineeromar.aiagent.core.logging.Logger
import com.engineeromar.aiagent.data.knowledge.TextExtractionPipeline
import com.engineeromar.aiagent.data.local.dao.KnowledgeDao
import com.engineeromar.aiagent.data.local.dao.KnowledgeFtsDao
import com.engineeromar.aiagent.data.local.entity.KnowledgeEntity
import com.engineeromar.aiagent.data.local.entity.KnowledgeFtsEntity
import com.engineeromar.aiagent.data.mapper.toDomain
import com.engineeromar.aiagent.domain.model.KnowledgeCategory
import com.engineeromar.aiagent.domain.model.KnowledgeDocument
import com.engineeromar.aiagent.domain.model.KnowledgeFileType
import com.engineeromar.aiagent.domain.model.SearchResult
import com.engineeromar.aiagent.domain.repository.KnowledgeRepository
import com.engineeromar.aiagent.domain.search.SemanticIndex
import com.engineeromar.aiagent.domain.util.Result
import java.io.File
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

@Singleton
class KnowledgeRepositoryImpl @Inject constructor(
    private val dao: KnowledgeDao,
    private val ftsDao: KnowledgeFtsDao,
    private val pipeline: TextExtractionPipeline,
    private val semantic: SemanticIndex,
) : KnowledgeRepository {

    override fun observeDocuments(): Flow<List<KnowledgeDocument>> =
        dao.observeAll().map { rows -> rows.map { it.toDomain() } }

    override fun observeByCategory(category: KnowledgeCategory): Flow<List<KnowledgeDocument>> =
        dao.observeByCategory(category.name.lowercase()).map { rows -> rows.map { it.toDomain() } }

    override suspend fun importDocument(filePath: String, category: KnowledgeCategory): Result<KnowledgeDocument> =
        withContext(Dispatchers.IO) {
            val file = File(filePath)
            if (!file.exists()) return@withContext Result.Failure(AppError.Storage("File not found: $filePath"))
            val type = typeFor(file) ?: return@withContext Result.Failure(
                AppError.Validation("fileType", "Unsupported file type: ${file.extension}")
            )
            val text = pipeline.extract(file, type)
            val id = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            val entity = KnowledgeEntity(
                id = id, title = file.nameWithoutExtension, filePath = file.absolutePath,
                fileType = type.ext, category = category.name.lowercase(), contentText = text,
                sizeBytes = file.length(), pageCount = estimatePages(text, type),
                createdAt = now, lastOpenedAt = null, tags = listOf(type.ext, category.name.lowercase()),
            )
            dao.upsert(entity)
            ftsDao.upsert(
                KnowledgeFtsEntity(docId = id, title = entity.title, body = "${entity.title}. $text")
            )
            semantic.upsert(id, "${entity.title}. $text")
            Logger.i("Knowledge") { "Imported ${file.name} (${text.length} chars)" }
            Result.Success(entity.toDomain())
        }

    override suspend fun deleteDocument(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            dao.delete(id); ftsDao.deleteByDoc(id); semantic.remove(id)
        }.fold({ Result.Success(Unit) }, { Result.Failure(AppError.Storage("delete failed: ${it.message}")) })
    }

    override suspend fun rebuildIndex(): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            semantic.clear()
            ftsDao.all().forEach { row -> semantic.upsert(row.docId, "${row.title}. ${row.body}") }
            semantic.size()
        }.fold({ Result.Success(it) }, { Result.Failure(AppError.Database("rebuild failed: ${it.message}")) })
    }

    override suspend fun search(query: String, limit: Int): List<SearchResult> = withContext(Dispatchers.IO) {
        val ftsQuery = toFtsQuery(query)
        val docIds = if (ftsQuery.isBlank()) emptyList() else ftsDao.searchDocIds(ftsQuery, limit)
        docIds.mapNotNull { id -> dao.getById(id)?.toSearchResult(query) }
    }

    override suspend fun semanticSearch(query: String, limit: Int): List<SearchResult> = withContext(Dispatchers.IO) {
        semantic.search(query, limit).mapNotNull { scored ->
            dao.getById(scored.documentId)?.toSearchResult(query, scored.score)
        }
    }

    override suspend fun getDocument(id: String): Result<KnowledgeDocument> = withContext(Dispatchers.IO) {
        val entity = dao.getById(id)
            ?: return@withContext Result.Failure(AppError.Storage("Document not found: $id"))
        dao.touch(id, System.currentTimeMillis())
        Result.Success(entity.toDomain())
    }

    override suspend fun documentText(id: String): Result<String> = withContext(Dispatchers.IO) {
        val entity = dao.getById(id)
            ?: return@withContext Result.Failure(AppError.Storage("Document not found: $id"))
        Result.Success(entity.contentText)
    }

    // ── helpers ──────────────────────────────────────────────────────────

    private fun typeFor(file: File): KnowledgeFileType? = when (file.extension.lowercase()) {
        "pdf" -> KnowledgeFileType.PDF
        "md", "markdown" -> KnowledgeFileType.MARKDOWN
        "txt" -> KnowledgeFileType.TEXT
        "docx" -> KnowledgeFileType.DOCX
        else -> null
    }

    private fun estimatePages(text: String, type: KnowledgeFileType): Int = when (type) {
        KnowledgeFileType.PDF, KnowledgeFileType.DOCX -> (text.length / 2200).coerceAtLeast(1)
        else -> 0
    }

    /** Quotes multi-word terms so FTS MATCH treats them as a phrase/AND query. */
    private fun toFtsQuery(query: String): String {
        val cleaned = query.trim().split(Regex("\\s+"))
            .filter { it.isNotBlank() }
            .joinToString(" ") { word ->
                val w = word.replace("\"", "")
                if (w.any { c -> !c.isLetterOrDigit() }) "\"$w\"" else w
            }
        return cleaned
    }

    private fun KnowledgeEntity.toSearchResult(query: String, score: Float = 1f): SearchResult {
        val snippet = snippetOf(contentText, query)
        return SearchResult(
            documentId = id, title = title,
            category = runCatching { KnowledgeCategory.valueOf(category.uppercase().replace("-", "_")) }
                .getOrDefault(KnowledgeCategory.GENERAL),
            fileType = runCatching { KnowledgeFileType.valueOf(fileType.uppercase()) }
                .getOrDefault(KnowledgeFileType.TEXT),
            snippet = snippet, score = score, filePath = filePath,
        )
    }

    private fun snippetOf(text: String, query: String, window: Int = 160): String {
        if (text.length <= window) return text.take(window)
        val idx = text.indexOf(query, ignoreCase = true)
        val start = (idx - window / 2).coerceAtLeast(0)
        val end = (start + window).coerceAtMost(text.length)
        return (if (start > 0) "…" else "") + text.substring(start, end).replace("\n", " ") +
            (if (end < text.length) "…" else "")
    }
}
