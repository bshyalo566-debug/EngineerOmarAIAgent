package com.engineeromar.aiagent.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Foreground service that runs long Command-Engine tasks (git operations,
 * bulk file processing, AI refactors) so they survive backgrounding and the
 * OS keeps the user informed. Declared with foregroundServiceType="specialUse".
 */
class CommandExecutionService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification("Running task…"))
        // Actual work is dispatched via WorkManager + the CommandEngine;
        // this service holds the foreground slot for the duration.
        return START_NOT_STICKY
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("Engineer Omar")
        .setContentText(text)
        .setSmallIcon(android.R.drawable.ic_menu_manage)
        .setOngoing(true)
        .build()
        .also {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Tasks", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }

    companion object {
        private const val NOTIF_ID = 4202
        private const val CHANNEL_ID = "eo_tasks"
    }
}
