package com.engineeromar.aiagent.feature.voice

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.engineeromar.aiagent.ai.agent.EngineeringAgent
import com.engineeromar.aiagent.core.permission.PermissionManager
import com.engineeromar.aiagent.core.voice.SpeechToText
import com.engineeromar.aiagent.core.voice.TextToSpeechEngine
import com.engineeromar.aiagent.domain.model.ConversationScope
import com.engineeromar.aiagent.domain.model.VoiceEvent
import com.engineeromar.aiagent.domain.model.VoiceLanguage
import com.engineeromar.aiagent.domain.util.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class VoiceViewModel @Inject constructor(
    private val stt: SpeechToText,
    private val tts: TextToSpeechEngine,
    private val agent: EngineeringAgent,
    private val permissions: PermissionManager,
) : ViewModel() {

    private val _listening = MutableStateFlow(false)
    val listening: StateFlow<Boolean> = _listening.asStateFlow()

    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()

    private val _transcript = MutableStateFlow("")
    val transcript: StateFlow<String> = _transcript.asStateFlow()

    private val _reply = MutableStateFlow("")
    val reply: StateFlow<String> = _reply.asStateFlow()

    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    private val _language = MutableStateFlow(VoiceLanguage.ENGLISH)
    val language: StateFlow<VoiceLanguage> = _language.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun setLanguage(language: VoiceLanguage) { _language.value = language }

    /** Returns false if RECORD_AUDIO is not granted (UI shows rationale). */
    fun startListening(): Boolean {
        val check = permissions.validate(android.Manifest.permission.RECORD_AUDIO)
        if (check is Result.Failure) {
            _error.value = check.error.message
            return false
        }
        _listening.value = true
        _partial.value = ""
        viewModelScope.launch {
            stt.listen(_language.value).collect { event ->
                when (event) {
                    is VoiceEvent.Listening -> _partial.value = event.partialTranscript
                    is VoiceEvent.Recognized -> {
                        _transcript.value = event.text
                        _listening.value = false
                        runAgent(event.text)
                    }
                    is VoiceEvent.Error -> {
                        _error.value = event.message
                        _listening.value = false
                    }
                    VoiceEvent.Ready -> Unit
                    else -> Unit
                }
            }
        }
        return true
    }

    fun stop() { _listening.value = false; stt /* stop handled by flow close */ }

    fun speak(text: String) = viewModelScope.launch {
        _speaking.value = true
        tts.speak(text, _language.value).collect { event ->
            when (event) {
                is VoiceEvent.SpeakingStarted -> _speaking.value = true
                is VoiceEvent.SpeakingDone -> _speaking.value = false
                is VoiceEvent.Error -> { _speaking.value = false; _error.value = event.message }
                else -> Unit
            }
        }
    }

    private fun runAgent(text: String) = viewModelScope.launch {
        if (text.isBlank()) return@launch
        val answer = agent.ask(history = emptyList(), userInput = text, scope = ConversationScope.GENERAL)
        _reply.value = answer
        speak(answer)
    }
}
