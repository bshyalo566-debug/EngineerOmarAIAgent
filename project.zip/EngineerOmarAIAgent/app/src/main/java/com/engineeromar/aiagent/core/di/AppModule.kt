package com.engineeromar.aiagent.core.di

import android.content.Context
import com.engineeromar.aiagent.core.cache.CacheManager
import com.engineeromar.aiagent.core.config.ConfigurationManager
import com.engineeromar.aiagent.core.error.GlobalErrorHandler
import com.engineeromar.aiagent.core.lifecycle.AppLifecycleObserver
import com.engineeromar.aiagent.core.logging.FileLogger
import com.engineeromar.aiagent.core.permission.PermissionManager
import com.engineeromar.aiagent.core.security.BiometricAuthManager
import com.engineeromar.aiagent.core.security.SecureStorage
import com.engineeromar.aiagent.core.storage.StorageDirectories
import com.engineeromar.aiagent.core.update.UpdateManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Core subsystem bindings. Everything is `@Singleton` so subsystems have a
 * stable identity across the app.
 *
 * Every method that needs the app context uses `@ApplicationContext` so Hilt
 * resolves the pre-qualified application-context binding.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideGlobalErrorHandler() = GlobalErrorHandler()

    @Provides @Singleton
    fun provideStorageDirectories(@ApplicationContext ctx: Context) = StorageDirectories(ctx)

    @Provides @Singleton
    fun provideFileLogger(storage: StorageDirectories) = FileLogger(storage)

    @Provides @Singleton
    fun provideCacheManager(storage: StorageDirectories) = CacheManager(storage)

    @Provides @Singleton
    fun provideSecureStorage(@ApplicationContext ctx: Context) = SecureStorage(ctx)

    @Provides @Singleton
    fun provideBiometricManager(@ApplicationContext ctx: Context) = BiometricAuthManager(ctx)

    @Provides @Singleton
    fun providePermissionManager(@ApplicationContext ctx: Context) = PermissionManager(ctx)

    @Provides @Singleton
    fun provideConfigManager(@ApplicationContext ctx: Context) = ConfigurationManager(ctx)

    @Provides @Singleton
    fun provideUpdateManager() = UpdateManager()

    @Provides @Singleton
    fun provideLifecycleObserver(cache: CacheManager) = AppLifecycleObserver(cache)
}
