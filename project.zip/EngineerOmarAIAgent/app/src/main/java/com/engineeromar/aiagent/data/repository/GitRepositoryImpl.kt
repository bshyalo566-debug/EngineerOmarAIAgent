package com.engineeromar.aiagent.data.repository

import com.engineeromar.aiagent.core.error.AppError
import com.engineeromar.aiagent.data.git.GitCredentialProvider
import com.engineeromar.aiagent.data.git.JGitEngine
import com.engineeromar.aiagent.domain.model.ChangeType
import com.engineeromar.aiagent.domain.model.GitBranch
import com.engineeromar.aiagent.domain.model.GitCloneResult
import com.engineeromar.aiagent.domain.model.GitCommit
import com.engineeromar.aiagent.domain.model.GitDiffEntry
import com.engineeromar.aiagent.domain.model.GitRepository as GitRepoSummary
import com.engineeromar.aiagent.domain.model.GitStatus
import com.engineeromar.aiagent.domain.repository.GitRepository
import com.engineeromar.aiagent.domain.util.Result
import java.io.File
import java.util.Date
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.eclipse.jgit.api.Git
import org.eclipse.jgit.diff.DiffEntry
import org.eclipse.jgit.lib.ObjectId
import org.eclipse.jgit.revwalk.RevCommit

@Singleton
class GitRepositoryImpl @Inject constructor(
    private val engine: JGitEngine,
    private val creds: GitCredentialProvider,
) : GitRepository {

    override suspend fun init(repositoryPath: String): Result<String> = withContext(Dispatchers.IO) {
        if (engine.init(File(repositoryPath))) Result.Success(repositoryPath)
        else Result.Failure(AppError.Storage("git init failed for $repositoryPath"))
    }

    override suspend fun clone(remoteUrl: String, destinationDir: String): Result<GitCloneResult> =
        withContext(Dispatchers.IO) {
            val dest = File(destinationDir)
            if (engine.clone(remoteUrl, dest)) {
                val count = engine.open(dest)?.use { git -> git.log().call().count() } ?: 0
                Result.Success(GitCloneResult(true, destinationDir, count, "Cloned $remoteUrl"))
            } else Result.Failure(AppError.Network("git clone failed for $remoteUrl"))
        }

    override suspend fun status(repositoryPath: String): Result<GitStatus> = withContext(Dispatchers.IO) {
        withGit(repositoryPath) { git ->
            val st = git.status().call()
            val branch = engine.currentBranch(git) ?: "HEAD"
            val staged = st.added.map { GitDiffEntry(it, ChangeType.ADDED, 0, 0) } +
                st.changed.map { GitDiffEntry(it, ChangeType.MODIFIED, 0, 0) } +
                st.removed.map { GitDiffEntry(it, ChangeType.DELETED, 0, 0) }
            val unstaged = st.modified.map { GitDiffEntry(it, ChangeType.MODIFIED, 0, 0) } +
                st.missing.map { GitDiffEntry(it, ChangeType.DELETED, 0, 0) }
            GitStatus(
                staged = staged, unstaged = unstaged, untracked = st.untracked.toList(),
                branch = branch, isClean = st.isClean,
            )
        }
    }

    override suspend fun add(repositoryPath: String, paths: List<String>): Result<Unit> = withContext(Dispatchers.IO) {
        withGit(repositoryPath) { git ->
            val cmd = git.add()
            if (paths.isEmpty()) cmd.addFilepattern(".") else paths.forEach { cmd.addFilepattern(it) }
            cmd.call()
        }
    }

    override suspend fun commit(repositoryPath: String, message: String, amend: Boolean): Result<GitCommit> =
        withContext(Dispatchers.IO) {
            withGit(repositoryPath) { git ->
                engine.commit(git, message, amend)
                    ?: throw IllegalStateException("git commit failed")
                git.log().setMaxCount(1).call().first().toDomain()
            }
        }

    override suspend fun push(repositoryPath: String, remote: String): Result<Unit> = withContext(Dispatchers.IO) {
        withGit(repositoryPath) { git ->
            if (!engine.push(git, remote)) throw IllegalStateException("git push failed")
        }
    }

    override suspend fun pull(repositoryPath: String, remote: String): Result<Unit> = withContext(Dispatchers.IO) {
        withGit(repositoryPath) { git ->
            if (!engine.pull(git, remote)) throw IllegalStateException("git pull failed")
        }
    }

    override suspend fun fetch(repositoryPath: String, remote: String): Result<Unit> = withContext(Dispatchers.IO) {
        withGit(repositoryPath) { git ->
            if (!engine.fetch(git, remote)) throw IllegalStateException("git fetch failed")
        }
    }

    override suspend fun checkout(repositoryPath: String, ref: String, createBranch: Boolean): Result<Unit> =
        withContext(Dispatchers.IO) {
            withGit(repositoryPath) { git ->
                if (!engine.checkout(git, ref, createBranch)) throw IllegalStateException("git checkout failed: $ref")
            }
        }

    override suspend fun merge(repositoryPath: String, branch: String): Result<Unit> = withContext(Dispatchers.IO) {
        withGit(repositoryPath) { git ->
            if (!engine.merge(git, branch)) throw IllegalStateException("git merge failed: $branch")
        }
    }

    override suspend fun branches(repositoryPath: String): Result<List<GitBranch>> = withContext(Dispatchers.IO) {
        withGit(repositoryPath) { git ->
            val current = engine.currentBranch(git)
            engine.listLocalBranches(git).map { ref ->
                val name = ref.name.removePrefix("refs/heads/")
                val last = lastCommitOn(git, ref.objectId)
                GitBranch(
                    name = name, isCurrent = name == current, isRemote = false,
                    trackingBranch = null,
                    lastCommitSummary = last?.shortMessage ?: "",
                    lastCommitDate = Date((last?.commitTime?.toLong() ?: 0L) * 1000),
                )
            }
        }
    }

    override suspend fun log(repositoryPath: String, limit: Int): Result<List<GitCommit>> = withContext(Dispatchers.IO) {
        withGit(repositoryPath) { git ->
            git.log().setMaxCount(limit).call().map { it.toDomain() }
        }
    }

    override suspend fun diff(repositoryPath: String): Result<List<GitDiffEntry>> = withContext(Dispatchers.IO) {
        withGit(repositoryPath) { git -> git.diff().call().map { it.toDomain() } }
    }

    override suspend fun summary(repositoryPath: String): Result<GitRepoSummary> = withContext(Dispatchers.IO) {
        withGit(repositoryPath) { git ->
            val branch = engine.currentBranch(git) ?: "HEAD"
            val remote = git.repository.config.getString("remote", "origin", "url")
            val st = git.status().call()
            GitRepoSummary(
                rootPath = repositoryPath, branch = branch, remoteUrl = remote,
                isClean = st.isClean, aheadCount = 0, behindCount = 0,
                uncommittedChanges = st.untracked.size + st.modified.size + st.changed.size + st.added.size,
            )
        }
    }

    // ── helpers ──────────────────────────────────────────────────────────

    /**
     * Opens the repo at [path], runs [block] inside, and maps any failure to
     * an [AppError]. The Git handle is always closed. The block returns a
     * domain value T; the helper wraps it in [Result.Success] or, on throw,
     * [Result.Failure] — so callers express failure by throwing.
     */
    private inline fun <T> withGit(path: String, block: (Git) -> T): Result<T> {
        val git = engine.open(File(path))
            ?: return Result.Failure(AppError.Storage("Not a git repository: $path"))
        return git.use {
            runCatching { Result.Success(block(it)) }
                .getOrElse { e -> Result.Failure(AppError.Storage("git error: ${e.message}", e)) }
        }
    }

    private fun RevCommit.toDomain(): GitCommit = GitCommit(
        hash = name, shortHash = name.take(7),
        author = authorIdent.name, authorEmail = authorIdent.emailAddress,
        date = Date(commitTime.toLong() * 1000),
        message = fullMessage.trim(), parents = parents.map { it.name },
    )

    private fun DiffEntry.toDomain(): GitDiffEntry {
        val type = when (changeType) {
            DiffEntry.ChangeType.ADD -> ChangeType.ADDED
            DiffEntry.ChangeType.DELETE -> ChangeType.DELETED
            DiffEntry.ChangeType.MODIFY -> ChangeType.MODIFIED
            DiffEntry.ChangeType.RENAME -> ChangeType.RENAMED
            DiffEntry.ChangeType.COPY -> ChangeType.COPIED
        }
        return GitDiffEntry(
            path = if (type == ChangeType.DELETED) oldPath else newPath,
            changeType = type, insertions = 0, deletions = 0,
        )
    }

    private fun lastCommitOn(git: Git, id: ObjectId): RevCommit? = runCatching {
        git.log().add(id).setMaxCount(1).call().firstOrNull()
    }.getOrNull()
}
