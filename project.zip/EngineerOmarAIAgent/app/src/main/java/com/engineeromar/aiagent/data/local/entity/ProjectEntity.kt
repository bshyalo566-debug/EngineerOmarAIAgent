package com.engineeromar.aiagent.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A managed software project. Supports all listed tech stacks via [techStack]
 * (free-form tags). [status] drives Project Manager views (active/archived/deleted).
 */
@Entity(
    tableName = "projects",
    indices = [Index("status"), Index("techStack"), Index("updatedAt")],
)
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val rootPath: String,            // absolute path under Projects/
    val techStack: List<String>,     // ["Android","Kotlin", ...]
    val language: String,            // primary language e.g. Kotlin
    val status: String,              // active | archived | deleted
    val repoUrl: String? = null,     // optional remote (Git/GitHub)
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean = false,
    val color: Long = 0xFFD4AF37,    // accent for the project card
)
