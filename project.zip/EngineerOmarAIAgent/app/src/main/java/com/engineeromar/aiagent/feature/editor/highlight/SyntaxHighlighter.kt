package com.engineeromar.aiagent.feature.editor.highlight

/**
 * Single-pass regex-driven tokenizer that classifies source code into [Token]s.
 *
 * It is intentionally rule-based (no ANTLR/grammar dep) so it stays fast on
 * mobile, handles partial/invalid input gracefully (the editor feeds live,
 * possibly-incomplete buffers), and supports every language in [CodeLanguage].
 * The tokenizer always covers the entire input — every char belongs to a token.
 */
class SyntaxHighlighter {

    private val rules: List<TokenRule> = buildRules()

    /**
     * Tokenises [source] for [language]. Complexity is O(n) over the input
     * length; designed to run on a background dispatcher per edit.
     */
    fun tokenize(source: String, language: CodeLanguage): List<Token> {
        if (source.isEmpty()) return emptyList()
        val keywords = LanguageDefinitions.keywordsFor(language)
        val builtins = LanguageDefinitions.builtinsFor(language)
        val tokens = ArrayList<Token>(source.length / 4)
        var i = 0
        val n = source.length

        while (i < n) {
            val matched = matchAt(source, i, language) ?: run {
                // Unknown single char — emit as punctuation/unknown and advance.
                tokens.add(Token(source[i].toString(), TokenType.UNKNOWN, i, i + 1))
                i++; continue
            }
            val (text, type) = matched
            val resolved = resolveIdentifier(type, text, language, keywords, builtins)
            tokens.add(Token(text, resolved, i, i + text.length))
            i += text.length
        }
        return tokens
    }

    private fun resolveIdentifier(
        base: TokenType, text: String, lang: CodeLanguage,
        keywords: Set<String>, builtins: Set<String>,
    ): TokenType {
        if (base != TokenType.IDENTIFIER) return base
        return when {
            text in keywords -> TokenType.KEYWORD
            text in builtins -> TokenType.BUILTIN
            text.first().isUpperCase() -> TokenType.TYPE
            else -> TokenType.IDENTIFIER
        }
    }

    private fun matchAt(src: String, idx: Int, lang: CodeLanguage): Pair<String, TokenType>? {
        for (rule in rules) {
            if (rule.languages != null && lang !in rule.languages) continue
            val m = rule.pattern.find(src, idx)
            if (m != null && m.range.first == idx) {
                val text = m.value
                if (rule.isFunctionCall && src.getOrNull(idx + text.length) == '(') {
                    return text to TokenType.FUNCTION
                }
                return text to rule.type
            }
        }
        return null
    }

    private data class TokenRule(
        val type: TokenType,
        val pattern: Regex,
        val languages: Set<CodeLanguage>? = null,
        val isFunctionCall: Boolean = false,
    )

    private fun buildRules(): List<TokenRule> {
        val shebang = TokenRule(TokenType.COMMENT, Regex("^#!.*"), null)
        val blockComment = TokenRule(TokenType.COMMENT, Regex("^/\\*[\\s\\S]*?\\*/"))
        val lineComment = TokenRule(TokenType.COMMENT, Regex("^//[^\\n]*"))
        val pythonComment = TokenRule(TokenType.COMMENT, Regex("^#[^\\n]*"),
            setOf(CodeLanguage.PYTHON, CodeLanguage.SHELL, CodeLanguage.YAML))
        val htmlComment = TokenRule(TokenType.COMMENT, Regex("^<!--[\\s\\S]*?-->"),
            setOf(CodeLanguage.HTML, CodeLanguage.MARKDOWN))
        val yamlComment = TokenRule(TokenType.COMMENT, Regex("^#[^\\n]*"), setOf(CodeLanguage.YAML))

        val tripleString = TokenRule(TokenType.STRING, Regex("^\"\"\"[\\s\\S]*?\"\"\"|^'''[\\s\\S]*?'''"),
            setOf(CodeLanguage.KOTLIN, CodeLanguage.PYTHON))
        val dqString = TokenRule(TokenType.STRING, Regex("^\"(?:\\\\.|[^\"\\\\\\n])*\""))
        val sqString = TokenRule(TokenType.STRING, Regex("^'(?:\\\\.|[^'\\\\\\n])*'"))
        val btString = TokenRule(TokenType.STRING, Regex("^`(?:\\\\.|[^`\\\\])*`"),
            setOf(CodeLanguage.JAVASCRIPT, CodeLanguage.TYPESCRIPT))

        val annotation = TokenRule(TokenType.ANNOTATION, Regex("^@[A-Za-z_][A-Za-z0-9_]*"),
            setOf(CodeLanguage.KOTLIN, CodeLanguage.JAVA))

        val number = TokenRule(TokenType.NUMBER,
            Regex("^0[xX][0-9a-fA-F_]+|^0[bB][01_]+|^\\d[\\d_]*\\.\\d+(?:[eE][+-]?\\d+)?[fFlLdD]?|^\\d[\\d_]*[fFlLdD]?|^\\.\\d+"))

        val operator = TokenRule(TokenType.OPERATOR,
            Regex("^(?:->|=>|<<|>>|>>>|&&|\\|\\||==|!=|<=|>=|\\+\\+|--|\\+=|-=|\\*=|/=|%=|&=|\\|=|\\^=|<<=|>>=|\\?\\.|\\.\\.|[-+*/%=<>!&|^~?:.])"))

        val punctuation = TokenRule(TokenType.PUNCTUATION, Regex("^[(){}\\[\\];,]"))

        val identifier = TokenRule(TokenType.IDENTIFIER, Regex("^[A-Za-z_$][A-Za-z0-9_$]*"),
            isFunctionCall = true)

        val whitespace = TokenRule(TokenType.WHITESPACE, Regex("^[\\s]+"))

        return listOf(
            shebang, blockComment, lineComment, htmlComment, yamlComment, pythonComment,
            tripleString, dqString, sqString, btString, annotation,
            number, operator, punctuation, identifier, whitespace,
        )
    }
}
