package com.engineeromar.aiagent.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** A single message inside a conversation. */
@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversationId"],
            onDelete = ForeignKey.CASCADE,
        )
    ],
    indices = [Index("conversationId"), Index("createdAt")],
)
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val role: String,           // user | assistant | system | tool
    val content: String,
    val createdAt: Long,
    val tokensIn: Int = 0,
    val tokensOut: Int = 0,
    val model: String? = null,
    val attachments: List<String> = emptyList(),
    val status: String = "ok",  // ok | error | streaming
)
