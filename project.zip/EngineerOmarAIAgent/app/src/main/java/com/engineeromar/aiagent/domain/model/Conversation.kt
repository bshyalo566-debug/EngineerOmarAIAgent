package com.engineeromar.aiagent.domain.model

data class Conversation(
    val id: String,
    val title: String,
    val projectId: String?,
    val scope: ConversationScope,
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean,
    val tokenCount: Int,
)

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val role: MessageRole,
    val content: String,
    val createdAt: Long,
    val model: String?,
    val attachments: List<String>,
)

enum class ConversationScope { GENERAL, PROJECT, KNOWLEDGE, CODE }
enum class MessageRole { USER, ASSISTANT, SYSTEM, TOOL }
