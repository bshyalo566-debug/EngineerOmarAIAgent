package com.engineeromar.aiagent.ai.engine

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Post-execution verifier. For code intents it would compile/lint; for git
 * intents it checks exit code + repo status; for file intents it checks the
 * artifact exists. A single seam so verification policy can evolve centrally.
 */
@Singleton
class Verifier @Inject constructor() {
    fun verify(intent: Intent, plan: ExecutionPlan, result: ExecutionResult): Boolean = result.success
}
