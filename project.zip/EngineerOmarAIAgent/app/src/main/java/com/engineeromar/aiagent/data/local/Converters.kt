package com.engineeromar.aiagent.data.local

import androidx.room.TypeConverter
import java.util.Date

/**
 * Shared Room type converters.
 *
 * Lists are persisted using a control-character (`\u0001`) separator rather
 * than JSON to keep the converter dependency-free and the column greppable.
 * `\u0001` is safe for the data stored here (tech-stack tags, labels,
 * attachment paths) which never contain control characters.
 */
class Converters {
    @TypeConverter fun fromTimestamp(value: Long?): Date? = value?.let { Date(it) }
    @TypeConverter fun dateToTimestamp(date: Date?): Long? = date?.time

    @TypeConverter fun stringListToString(list: List<String>?): String =
        list?.joinToString(separator = SEPARATOR) ?: ""

    @TypeConverter fun stringToStringList(value: String?): List<String> =
        if (value.isNullOrEmpty()) emptyList() else value.split(SEPARATOR)

    private companion object {
        const val SEPARATOR = "\u0001"
    }
}
