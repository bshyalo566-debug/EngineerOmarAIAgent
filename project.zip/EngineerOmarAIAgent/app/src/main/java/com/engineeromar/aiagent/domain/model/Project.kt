package com.engineeromar.aiagent.domain.model

/**
 * Pure domain model — no DB/Android dependency. The data layer maps between
 * [ProjectEntity] and this. UI consumes only domain models.
 */
data class Project(
    val id: String,
    val name: String,
    val description: String,
    val rootPath: String,
    val techStack: List<String>,
    val language: String,
    val status: ProjectStatus,
    val repoUrl: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean,
    val color: Long,
)

enum class ProjectStatus { ACTIVE, ARCHIVED, DELETED }

object TechStack {
    const val FLUTTER = "Flutter"
    const val ANDROID = "Android"
    const val KOTLIN = "Kotlin"
    const val JAVA = "Java"
    const val REACT = "React"
    const val REACT_NATIVE = "React Native"
    const val NEXT_JS = "Next.js"
    const val NODE_JS = "Node.js"
    const val PYTHON = "Python"
    const val HTML = "HTML"
    const val CSS = "CSS"
    const val JAVASCRIPT = "JavaScript"
    const val TYPESCRIPT = "TypeScript"

    val ALL = listOf(FLUTTER, ANDROID, KOTLIN, JAVA, REACT, REACT_NATIVE, NEXT_JS, NODE_JS, PYTHON, HTML, CSS, JAVASCRIPT, TYPESCRIPT)
}
