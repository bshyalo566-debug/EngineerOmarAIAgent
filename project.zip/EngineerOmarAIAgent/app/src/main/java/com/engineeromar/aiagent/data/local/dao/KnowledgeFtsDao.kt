package com.engineeromar.aiagent.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.engineeromar.aiagent.data.local.entity.KnowledgeFtsEntity

/**
 * Full-text search access to the Knowledge Base. Uses SQLite FTS4 MATCH with
 * relevance ranking (`ORDER BY rank`). The repository keeps this table in
 * sync with [com.engineeromar.aiagent.data.local.dao.KnowledgeDao].
 */
@Dao
interface KnowledgeFtsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(row: KnowledgeFtsEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(rows: List<KnowledgeFtsEntity>)

    @Query("DELETE FROM knowledge_fts WHERE docId = :docId")
    suspend fun deleteByDoc(docId: String)

    @Query("DELETE FROM knowledge_fts")
    suspend fun clear()

    @Query(
        """
        SELECT docId FROM knowledge_fts
        WHERE knowledge_fts MATCH :query
        ORDER BY rank
        LIMIT :limit
        """
    )
    suspend fun searchDocIds(query: String, limit: Int): List<String>

    /** Returns every indexed document (used to rebuild the TF-IDF cosine index). */
    @Query("SELECT docId, title, body FROM knowledge_fts")
    suspend fun all(): List<FtsRow>
}

data class FtsRow(val docId: String, val title: String, val body: String)
