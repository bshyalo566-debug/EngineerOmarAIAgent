package com.engineeromar.aiagent.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Immutable, append-only audit trail for the Command Engine. Every request
 * through the pipeline produces one row — the in-app Logs viewer queries it.
 */
@Entity(
    tableName = "command_logs",
    indices = [Index("createdAt"), Index("status"), Index("intent")],
)
data class CommandLogEntity(
    @PrimaryKey val id: String,
    val createdAt: Long,
    val intent: String,             // detected intent, e.g. "git.commit"
    val request: String,            // raw user request
    val plan: String,               // JSON-serialised execution plan
    val status: String,             // queued | running | success | failed | cancelled
    val durationMs: Long,
    val permissionGranted: Boolean,
    val errorMessage: String? = null,
    val subsystem: String,          // agent | git | file | knowledge | voice | ...
    val verificationPassed: Boolean,
)
