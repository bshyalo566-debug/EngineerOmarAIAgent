package com.engineeromar.aiagent.core.automation

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import com.engineeromar.aiagent.core.logging.Logger
import com.engineeromar.aiagent.core.storage.StorageDirectories
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Official-API-only automation surface. Every action uses a documented Intent
 * or framework API — no accessibility-service input injection across other
 * apps, no root, no DEX execution. Each method returns true if the system
 * accepted the intent (the user still sees the standard chooser/resolver).
 */
@Singleton
class AndroidAutomation @Inject constructor(
    @ApplicationContext private val context: Context,
    private val storage: StorageDirectories,
) {

    /** Opens an arbitrary URL in the user's chosen browser. */
    fun openUrl(url: String): Boolean = launch(
        Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )

    /** Opens the system app-details screen for [packageName] (official launch path). */
    fun openAppSettings(packageName: String): Boolean = launch(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(Uri.fromParts("package", packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )

    /**
     * Launches another app by package. Uses getLaunchIntentForPackage — the
     * official, user-consented launcher intent. Returns false if the app is
     * not installed or exposes no launchable activity.
     */
    fun openApp(packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: run {
                Logger.w("Automation") { "No launch intent for $packageName" }
                return false
            }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return launch(intent)
    }

    /** Shares text via the system share sheet (ACTION_SEND). */
    fun shareText(text: String, subject: String? = null): Boolean = launch(
        Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                subject?.let { putExtra(Intent.EXTRA_SUBJECT, it) }
            },
            "Share via"
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )

    /** Shares a file via FileProvider (the secure, content-uri sharing path). */
    fun shareFile(file: File, mimeType: String = "*/*"): Boolean {
        if (!file.exists()) return false
        val uri = FileProvider.getUriForFile(
            context, "${context.packageName}.fileprovider", file
        )
        val intent = Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            },
            "Share ${file.name}"
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return launch(intent)
    )

    /** Copies [text] to the system clipboard. */
    fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
    }

    /** Issues a notification on the app's channel (Notifications module). */
    fun notify(id: Int, title: String, body: String) {
        Notifications.notify(context, id, title, body)
    }

    /** Builds a ACTION_OPEN_DOCUMENT / ACTION_GET_CONTENT picker intent. */
    fun filePickerIntent(mime: String = "*/*"): Intent =
        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = mime
            addCategory(Intent.CATEGORY_OPENABLE)
        }

    private fun launch(intent: Intent): Boolean = runCatching {
        context.startActivity(intent); true
    }.getOrElse {
        Logger.w("Automation") { "Intent launch failed: ${it.message}" }; false
    }
}
