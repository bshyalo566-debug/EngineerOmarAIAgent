package com.engineeromar.aiagent.domain.usecase.git

import com.engineeromar.aiagent.domain.model.GitBranch
import com.engineeromar.aiagent.domain.model.GitCommit
import com.engineeromar.aiagent.domain.model.GitRepository
import com.engineeromar.aiagent.domain.model.GitStatus
import com.engineeromar.aiagent.domain.repository.GitRepository
import javax.inject.Inject

class GitInitUseCase @Inject constructor(private val repo: GitRepository) {
    suspend operator fun invoke(path: String) = repo.init(path)
}

class GitCloneUseCase @Inject constructor(private val repo: GitRepository) {
    suspend operator fun invoke(url: String, dest: String) = repo.clone(url, dest)
}

class GitStatusUseCase @Inject constructor(private val repo: GitRepository) {
    suspend operator fun invoke(path: String): Result<GitStatus> = repo.status(path)
}

class GitAddUseCase @Inject constructor(private val repo: GitRepository) {
    suspend operator fun invoke(path: String, files: List<String>) = repo.add(path, files)
}

class GitCommitUseCase @Inject constructor(private val repo: GitRepository) {
    suspend operator fun invoke(path: String, message: String, amend: Boolean = false) =
        repo.commit(path, message, amend)
}

class GitPushUseCase @Inject constructor(private val repo: GitRepository) {
    suspend operator fun invoke(path: String) = repo.push(path)
}

class GitPullUseCase @Inject constructor(private val repo: GitRepository) {
    suspend operator fun invoke(path: String) = repo.pull(path)
}

class GitCheckoutUseCase @Inject constructor(private val repo: GitRepository) {
    suspend operator fun invoke(path: String, ref: String, create: Boolean = false) =
        repo.checkout(path, ref, create)
}

class GitBranchesUseCase @Inject constructor(private val repo: GitRepository) {
    suspend operator fun invoke(path: String): Result<List<GitBranch>> = repo.branches(path)
}

class GitLogUseCase @Inject constructor(private val repo: GitRepository) {
    suspend operator fun invoke(path: String, limit: Int = 100): Result<List<GitCommit>> =
        repo.log(path, limit)
}

class GitSummaryUseCase @Inject constructor(private val repo: GitRepository) {
    suspend operator fun invoke(path: String): Result<GitRepository> = repo.summary(path)
}
