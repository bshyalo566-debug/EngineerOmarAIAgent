package com.engineeromar.aiagent.feature.editor.highlight

/**
 * A classified lexical token produced by [SyntaxHighlighter]. The UI maps
 * [TokenType] to a colour from the active editor theme.
 */
data class Token(
    val text: String,
    val type: TokenType,
    val start: Int,
    val end: Int,
)

enum class TokenType {
    KEYWORD, BUILTIN, TYPE, NUMBER, STRING, CHAR, COMMENT, ANNOTATION,
    OPERATOR, PUNCTUATION, IDENTIFIER, FUNCTION, PROPERTY, WHITESPACE, UNKNOWN,
}

/** Language families the highlighter recognises. */
enum class CodeLanguage {
    KOTLIN, JAVA, JAVASCRIPT, TYPESCRIPT, PYTHON, JSON, XML, HTML, CSS, MARKDOWN, SHELL, YAML, PLAINTEXT;

    companion object {
        fun forExtension(ext: String): CodeLanguage = when (ext.lowercase()) {
            "kt", "kts" -> KOTLIN
            "java" -> JAVA
            "js", "jsx", "mjs", "cjs" -> JAVASCRIPT
            "ts", "tsx" -> TYPESCRIPT
            "py" -> PYTHON
            "json" -> JSON
            "xml", "svg", "plist" -> XML
            "html", "htm" -> HTML
            "css", "scss" -> CSS
            "md", "markdown" -> MARKDOWN
            "sh", "bash" -> SHELL
            "yml", "yaml" -> YAML
            else -> PLAINTEXT
        }
    }
}
