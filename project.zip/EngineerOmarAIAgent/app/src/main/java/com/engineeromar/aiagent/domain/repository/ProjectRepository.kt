package com.engineeromar.aiagent.domain.repository

import com.engineeromar.aiagent.domain.model.Project
import com.engineeromar.aiagent.domain.model.ProjectStatus
import kotlinx.coroutines.flow.Flow

interface ProjectRepository {
    fun observeProjects(): Flow<List<Project>>
    suspend fun getProject(id: String): Project?
    suspend fun search(query: String): List<Project>
    suspend fun create(project: Project): Project
    suspend fun update(project: Project)
    suspend fun setStatus(id: String, status: ProjectStatus)
    suspend fun delete(project: Project)
}
