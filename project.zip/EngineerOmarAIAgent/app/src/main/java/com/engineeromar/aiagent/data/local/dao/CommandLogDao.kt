package com.engineeromar.aiagent.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.engineeromar.aiagent.data.local.entity.CommandLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CommandLogDao {
    @Query("SELECT * FROM command_logs ORDER BY createdAt DESC LIMIT :limit")
    fun observeRecent(limit: Int = 500): Flow<List<CommandLogEntity>>

    @Query("SELECT * FROM command_logs WHERE subsystem = :sub ORDER BY createdAt DESC")
    fun observeBySubsystem(sub: String): Flow<List<CommandLogEntity>>

    @Query("SELECT * FROM command_logs WHERE status = 'failed' ORDER BY createdAt DESC LIMIT 100")
    fun observeErrors(): Flow<List<CommandLogEntity>>

    @Query("SELECT * FROM command_logs WHERE request LIKE '%' || :q || '%' OR plan LIKE '%' || :q || '%' ORDER BY createdAt DESC")
    suspend fun search(q: String): List<CommandLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: CommandLogEntity)

    @Query("DELETE FROM command_logs WHERE createdAt < :before")
    suspend fun pruneOlderThan(before: Long)
}
