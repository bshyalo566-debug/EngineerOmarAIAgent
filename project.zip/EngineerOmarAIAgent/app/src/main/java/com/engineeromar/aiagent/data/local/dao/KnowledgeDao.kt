package com.engineeromar.aiagent.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.engineeromar.aiagent.data.local.entity.KnowledgeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface KnowledgeDao {
    @Query("SELECT * FROM knowledge ORDER BY lastOpenedAt DESC, createdAt DESC")
    fun observeAll(): Flow<List<KnowledgeEntity>>

    @Query("SELECT * FROM knowledge WHERE category = :cat ORDER BY title")
    fun observeByCategory(cat: String): Flow<List<KnowledgeEntity>>

    @Query("SELECT * FROM knowledge WHERE id = :id")
    suspend fun getById(id: String): KnowledgeEntity?

    // Full-text-like search across extracted plain text (upgradeable to FTS4/FTS5).
    @Query("SELECT * FROM knowledge WHERE contentText LIKE '%' || :q || '%' OR title LIKE '%' || :q || '%'")
    suspend fun search(q: String): List<KnowledgeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(k: KnowledgeEntity)

    @Query("DELETE FROM knowledge WHERE id = :id")
    suspend fun delete(id: String)

    @Query("UPDATE knowledge SET lastOpenedAt = :ts WHERE id = :id")
    suspend fun touch(id: String, ts: Long)
}
