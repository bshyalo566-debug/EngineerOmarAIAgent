package com.engineeromar.aiagent.feature.editor.diagnostics

import com.engineeromar.aiagent.feature.editor.highlight.CodeLanguage

/**
 * A lightweight, offline diagnostics pass. It catches the high-value,
 * zero-dependency issues a phone-based editor can detect without a full
 * compiler: bracket balance, trailing whitespace, tab/space mixing,
 * unconventional line length, and obvious syntax mismatches. Heavy
 * language-server diagnostics are layered in via the Plugin SDK.
 */
data class Diagnostic(
    val severity: Severity,
    val message: String,
    val line: Int,
    val column: Int,
    val rule: String,
)

enum class Severity { ERROR, WARNING, INFO }

class DiagnosticsEngine {

    fun analyze(source: String, language: CodeLanguage, maxLineLength: Int = 120): List<Diagnostic> {
        val out = ArrayList<Diagnostic>()
        val lines = source.split("\n")
        val bracketStack = ArrayDeque<Char>()

        for ((index, line) in lines.withIndex()) {
            val lineNo = index + 1
            if (line.length > maxLineLength) {
                out.add(Diagnostic(Severity.WARNING, "Line exceeds $maxLineLength characters", lineNo, maxLineLength, "line-length"))
            }
            if (line.endsWith(" ")) {
                out.add(Diagnostic(Severity.INFO, "Trailing whitespace", lineNo, line.trimEnd().length + 1, "trailing-ws"))
            }
            if (line.contains("\t") && line.contains("    ")) {
                out.add(Diagnostic(Severity.WARNING, "Mixed tabs and spaces", lineNo, 1, "indent-mix"))
            }

            if (language in BRACKET_LANGUAGES) {
                scanBrackets(line, lineNo, bracketStack, out)
            }
        }

        bracketStack.forEach { open ->
            out.add(Diagnostic(Severity.ERROR, "Unclosed '$open'", lines.size, 1, "unbalanced-bracket"))
        }
        return out
    }

    private fun scanBrackets(
        line: String, lineNo: Int,
        stack: ArrayDeque<Char>, out: ArrayList<Diagnostic>,
    ) {
        var inString: Char? = null
        var escaped = false
        for ((col, ch) in line.withIndex()) {
            when {
                escaped -> escaped = false
                ch == '\\' && inString != null -> escaped = true
                inString != null -> if (ch == inString) inString = null
                ch == '"' || ch == '\'' || ch == '`' -> inString = ch
                ch in "([{<{" -> stack.addLast(ch)
                ch in ")]}>" -> {
                    val opener = stack.removeLastOrNull()
                    val expected = closingFor(opener)
                    if (opener == null || expected != ch) {
                        out.add(Diagnostic(Severity.ERROR, "Mismatched '$ch'", lineNo, col + 1, "bracket-mismatch"))
                    }
                }
            }
        }
    }

    private fun closingFor(open: Char?): Char? = when (open) {
        '(' -> ')'; '[' -> ']'; '{' -> '}'; '<' -> '>'
        else -> null
    }

    companion object {
        private val BRACKET_LANGUAGES = setOf(
            CodeLanguage.KOTLIN, CodeLanguage.JAVA, CodeLanguage.JAVASCRIPT,
            CodeLanguage.TYPESCRIPT, CodeLanguage.JSON,
        )
    }
}
