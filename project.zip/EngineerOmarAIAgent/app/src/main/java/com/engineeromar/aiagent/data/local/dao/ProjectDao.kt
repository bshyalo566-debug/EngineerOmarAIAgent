package com.engineeromar.aiagent.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.engineeromar.aiagent.data.local.entity.ProjectEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects WHERE status != 'deleted' ORDER BY pinned DESC, updatedAt DESC")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getById(id: String): ProjectEntity?

    @Query("SELECT * FROM projects WHERE name LIKE '%' || :q || '%' OR description LIKE '%' || :q || '%'")
    suspend fun search(q: String): List<ProjectEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(project: ProjectEntity)

    @Update suspend fun update(project: ProjectEntity)

    @Query("UPDATE projects SET status = :status, updatedAt = :ts WHERE id = :id")
    suspend fun setStatus(id: String, status: String, ts: Long)

    @Delete suspend fun delete(project: ProjectEntity)

    @Query("SELECT COUNT(*) FROM projects WHERE status = 'active'")
    suspend fun activeCount(): Int
}
