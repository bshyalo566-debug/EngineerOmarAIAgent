package com.engineeromar.aiagent.ai.engine

import dagger.MapKey

/**
 * Dagger map key for binding [Executor]s into the multibinding that backs
 * [ExecutorRegistry]. Each executor is keyed by the intent id it handles,
 * letting the registry resolve a capability in O(1) without changes to its
 * own source when new executors are added.
 */
@MustBeDocumented
@Target(AnnotationTarget.FUNCTION)
@Retention(AnnotationRetention.RUNTIME)
@MapKey
annotation class IntentKey(val value: String)
