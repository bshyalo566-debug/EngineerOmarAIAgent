package com.engineeromar.aiagent.feature.editor.highlight

import androidx.compose.ui.graphics.Color

/**
 * Editor colour themes. Each maps a [TokenType] to a foreground colour. The
 * "Omar Dark" theme matches the app's Luxury Black + Gold identity; a light
 * variant supports the Light Mode setting.
 */
data class EditorTheme(
    val name: String,
    val background: Color,
    val foreground: Color,
    val lineNumber: Color,
    val lineNumberActive: Color,
    val selection: Color,
    val colors: Map<TokenType, Color>,
    val isDark: Boolean,
) {
    fun colorFor(type: TokenType): Color = colors[type] ?: foreground
}

object EditorThemes {
    val OmarDark = EditorTheme(
        name = "Omar Dark",
        background = Color(0xFF0B0B0D),
        foreground = Color(0xFFE6E6E0),
        lineNumber = Color(0xFF4A4A52),
        lineNumberActive = Color(0xFFD4AF37),
        selection = Color(0x33D4AF37),
        isDark = true,
        colors = mapOf(
            TokenType.KEYWORD to Color(0xFFFFB547),
            TokenType.BUILTIN to Color(0xFF4DB6FF),
            TokenType.TYPE to Color(0xFF6FE8C7),
            TokenType.NUMBER to Color(0xFFFF9E64),
            TokenType.STRING to Color(0xFF9ECE6A),
            TokenType.CHAR to Color(0xFF9ECE6A),
            TokenType.COMMENT to Color(0xFF6B6B73),
            TokenType.ANNOTATION to Color(0xFFE0AF68),
            TokenType.OPERATOR to Color(0xFF89DDFF),
            TokenType.PUNCTUATION to Color(0xFFBDBDBD),
            TokenType.IDENTIFIER to Color(0xFFE6E6E0),
            TokenType.FUNCTION to Color(0xFF7AA2F7),
            TokenType.PROPERTY to Color(0xFFBB9AF7),
            TokenType.WHITESPACE to Color.Transparent,
            TokenType.UNKNOWN to Color(0xFFFF6B6B),
        ),
    )

    val OmarLight = EditorTheme(
        name = "Omar Light",
        background = Color(0xFFF7F5EF),
        foreground = Color(0xFF1A1A1A),
        lineNumber = Color(0xFFBDBDBD),
        lineNumberActive = Color(0xFFB8902A),
        selection = Color(0x33B8902A),
        isDark = false,
        colors = mapOf(
            TokenType.KEYWORD to Color(0xFFA1260D),
            TokenType.BUILTIN to Color(0xFF1F6FEB),
            TokenType.TYPE to Color(0xFF0969DA),
            TokenType.NUMBER to Color(0xFF9333EA),
            TokenType.STRING to Color(0xFF0A7C42),
            TokenType.CHAR to Color(0xFF0A7C42),
            TokenType.COMMENT to Color(0xFF6E7781),
            TokenType.ANNOTATION to Color(0xFFB8902A),
            TokenType.OPERATOR to Color(0xFF6639BA),
            TokenType.PUNCTUATION to Color(0xFF57606A),
            TokenType.IDENTIFIER to Color(0xFF1A1A1A),
            TokenType.FUNCTION to Color(0xFF8250DF),
            TokenType.PROPERTY to Color(0xFFB8902A),
            TokenType.WHITESPACE to Color.Transparent,
            TokenType.UNKNOWN to Color(0xFFCF222E),
        ),
    )

    fun forDark(dark: Boolean): EditorTheme = if (dark) OmarDark else OmarLight
}
