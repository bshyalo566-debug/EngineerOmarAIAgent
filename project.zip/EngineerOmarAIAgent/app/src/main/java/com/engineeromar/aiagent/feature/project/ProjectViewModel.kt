package com.engineeromar.aiagent.feature.project

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.engineeromar.aiagent.domain.model.Project
import com.engineeromar.aiagent.domain.usecase.project.ArchiveProjectUseCase
import com.engineeromar.aiagent.domain.usecase.project.CreateProjectUseCase
import com.engineeromar.aiagent.domain.usecase.project.DeleteProjectUseCase
import com.engineeromar.aiagent.domain.usecase.project.ObserveProjectsUseCase
import com.engineeromar.aiagent.domain.usecase.project.SearchProjectsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class ProjectViewModel @Inject constructor(
    observeProjects: ObserveProjectsUseCase,
    private val create: CreateProjectUseCase,
    private val search: SearchProjectsUseCase,
    private val archive: ArchiveProjectUseCase,
    private val delete: DeleteProjectUseCase,
) : ViewModel() {

    val projects: StateFlow<List<Project>> = observeProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _query = MutableStateFlow("")
    val query = _query.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Project>>(emptyList())
    val searchResults = _searchResults.asStateFlow()

    fun onQueryChange(q: String) {
        _query.value = q
        viewModelScope.launch {
            _searchResults.value = if (q.isBlank()) emptyList() else search(q)
        }
    }

    fun createProject(input: com.engineeromar.aiagent.domain.usecase.project.CreateProjectInput) {
        viewModelScope.launch { create(input) }
    }

    fun archive(project: Project) {
        viewModelScope.launch { archive(project.id) }
    }

    fun delete(project: Project) {
        viewModelScope.launch { delete(project) }
    }
}
