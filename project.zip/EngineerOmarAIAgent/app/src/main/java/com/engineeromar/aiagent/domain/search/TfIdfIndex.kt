package com.engineeromar.aiagent.domain.search

import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Offline "semantic" search engine using TF-IDF vectors + cosine similarity.
 *
 * It is fully on-device, deterministic, dependency-free, and fast for the
 * document volumes a phone carries (hundreds to low thousands of docs). True
 * neural embeddings can be layered in later by plugging a vector store behind
 * the same [SemanticIndex] contract — the retrieval API is unchanged.
 */
interface SemanticIndex {
    /** Adds (or replaces) a document in the index. */
    fun upsert(documentId: String, text: String)
    fun remove(documentId: String)
    fun clear()
    /** Returns ranked docIds for [query]. */
    fun search(query: String, limit: Int): List<ScoredDoc>
    fun size(): Int
}

data class ScoredDoc(val documentId: String, val score: Float)

@Singleton
class TfIdfIndex @Inject constructor() : SemanticIndex {

    private val docs = HashMap<String, TermVector>()
    private val documentFrequency = HashMap<String, Int>()  // term -> # docs containing it
    private val totalTerms = HashMap<String, Float>()       // for storing idf cache

    @Synchronized
    override fun upsert(documentId: String, text: String) {
        remove(documentId)
        val tokens = tokenize(text)
        if (tokens.isEmpty()) return
        val tf = HashMap<String, Float>()
        tokens.forEach { t -> tf[t] = (tf[t] ?: 0f) + 1f }
        // Log-frequency term weighting.
        tf.forEach { (t, c) -> tf[t] = 1f + ln(c.toDouble()).toFloat() }
        val vector = TermVector(tf)
        docs[documentId] = vector
        tf.keys.forEach { term -> documentFrequency[term] = (documentFrequency[term] ?: 0) + 1 }
        invalidateIdf()
    }

    @Synchronized
    override fun remove(documentId: String) {
        val existing = docs.remove(documentId) ?: return
        existing.terms.keys.forEach { term ->
            val n = (documentFrequency[term] ?: 1) - 1
            if (n <= 0) {
                documentFrequency.remove(term)
                totalTerms.remove(term)
            } else documentFrequency[term] = n
        }
    }

    @Synchronized override fun clear() {
        docs.clear(); documentFrequency.clear(); totalTerms.clear()
    }

    @Synchronized
    override fun search(query: String, limit: Int): List<ScoredDoc> {
        val n = docs.size
        if (n == 0) return emptyList()
        val qTokens = tokenize(query)
        if (qTokens.isEmpty()) return emptyList()
        val qFreq = HashMap<String, Float>()
        qTokens.forEach { qFreq[it] = (qFreq[it] ?: 0f) + 1f }
        val qTfIdf = qFreq.mapValues { (t, c) -> (1f + ln(c.toDouble()).toFloat()) * idf(t) }
        val qNorm = sqrt(qTfIdf.values.sumOf { (it * it).toDouble() }).toFloat().coerceAtLeast(1e-6f)

        return docs.map { (docId, vec) ->
            var dot = 0f
            qTfIdf.forEach { (t, qw) ->
                val dw = vec.terms[t]
                if (dw != null) dot += qw * dw * idf(t)
            }
            val dNorm = vec.norm
            val score = dot / (qNorm * dNorm)
            ScoredDoc(docId, score)
        }.filter { it.score > 0f }
            .sortedByDescending { it.score }
            .take(limit)
    }

    @Synchronized override fun size(): Int = docs.size

    private fun invalidateIdf() { totalTerms.clear() }

    private fun idf(term: String): Float {
        totalTerms[term]?.let { return it }
        val df = documentFrequency[term] ?: 0
        val value = if (df == 0) 0f else ln((docs.size.toDouble() + 1) / (df + 1)).toFloat() + 1f
        totalTerms[term] = value
        return value
    }

    private fun tokenize(text: String): List<String> {
        val lower = text.lowercase()
        val sb = StringBuilder()
        val out = ArrayList<String>(64)
        for (ch in lower) {
            if (ch.isLetterOrDigit() || ch == '_' || isArabic(ch)) sb.append(ch)
            else {
                if (sb.isNotEmpty()) {
                    val w = sb.toString()
                    if (w.length > 1 && w !in STOPWORDS) out.add(w)
                    sb.setLength(0)
                }
            }
        }
        if (sb.isNotEmpty()) {
            val w = sb.toString()
            if (w.length > 1 && w !in STOPWORDS) out.add(w)
        }
        return out
    }

    private fun isArabic(ch: Char): Boolean = ch in '\u0600'..'\u06FF'

    private class TermVector(val terms: HashMap<String, Float>) {
        val norm: Float = sqrt(terms.values.sumOf { (it * it).toDouble() }).toFloat().coerceAtLeast(1e-6f)
    }

    companion object {
        // Minimal English + code stopword set to improve signal.
        private val STOPWORDS = setOf(
            "the", "a", "an", "and", "or", "but", "if", "of", "to", "in", "on", "for",
            "is", "are", "be", "was", "were", "this", "that", "with", "as", "at", "by",
            "it", "its", "from", "your", "you", "i", "we", "they", "he", "she",
            "var", "val", "let", "const", "function", "return", "import", "package",
        )
    }
}
