package com.engineeromar.aiagent.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.engineeromar.aiagent.data.local.entity.MemoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories WHERE scope = :scope ORDER BY importance DESC, lastAccessedAt DESC")
    fun observeForScope(scope: String): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE scope = :scope ORDER BY importance DESC, lastAccessedAt DESC LIMIT :limit")
    suspend fun topForScope(scope: String, limit: Int): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE content LIKE '%' || :q || '%' ORDER BY importance DESC")
    suspend fun search(q: String): List<MemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(m: MemoryEntity)

    @Query("UPDATE memories SET lastAccessedAt = :ts, accessCount = accessCount + 1 WHERE id = :id")
    suspend fun touch(id: String, ts: Long)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun delete(id: String)
}
