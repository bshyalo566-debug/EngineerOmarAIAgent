package com.engineeromar.aiagent.data.knowledge

import com.engineeromar.aiagent.core.logging.Logger
import com.engineeromar.aiagent.domain.model.KnowledgeFileType
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Resolves a [DocumentTextExtractor] for a given file type and extracts plain
 * text for indexing. Falls back gracefully (returns empty text + logs) so one
 * unparseable document never breaks an import batch.
 */
@Singleton
class TextExtractionPipeline @Inject constructor(
    private val pdfExtractor: PdfTextExtractor,
    private val docxExtractor: DocxTextExtractor,
) {
    fun extract(file: File, type: KnowledgeFileType): String = runCatching {
        when (type) {
            KnowledgeFileType.MARKDOWN, KnowledgeFileType.TEXT -> file.readText()
            KnowledgeFileType.PDF -> pdfExtractor.extract(file)
            KnowledgeFileType.DOCX -> docxExtractor.extract(file)
        }
    }.getOrElse {
        Logger.w("Knowledge") { "Extraction failed for ${file.name}: ${it.message}" }
        ""
    }
}

interface DocumentTextExtractor {
    fun extract(file: File): String
}

/**
 * Extracts text from a .docx without external libraries. A .docx is a ZIP
 * whose `word/document.xml` holds paragraphs inside <w:t> nodes. We stream the
 * XML and concatenate text runs, inserting newlines between paragraphs.
 */
@Singleton
class DocxTextExtractor @Inject constructor() : DocumentTextExtractor {
    override fun extract(file: File): String {
        if (!file.exists()) return ""
        val sb = StringBuilder()
        java.util.zip.ZipInputStream(file.inputStream()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (entry.name == "word/document.xml") {
                    val xml = zis.bufferedReader().readText()
                    sb.append(parseDocumentXml(xml))
                    break
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return sb.toString().trim()
    }

    /** Streams <w:t> text runs; inserts a newline at each </w:p> paragraph boundary. */
    private fun parseDocumentXml(xml: String): String {
        val text = Regex("<w:t[^>]*>(.*?)</w:t>", RegexOption.DOT_MATCHES_ALL)
        val out = StringBuilder()
        var cursor = 0
        while (cursor < xml.length) {
            val closeP = xml.indexOf("</w:p>", cursor)
            val chunkEnd = if (closeP == -1) xml.length else closeP
            text.findAll(xml, cursor).takeWhile { it.range.first < chunkEnd }
                .forEach { out.append(it.groupValues[1]) }
            if (closeP == -1) break
            out.append('\n')
            cursor = closeP + 6
        }
        return out.toString()
    }
}
