package com.engineeromar.aiagent.ai.provider

import com.engineeromar.aiagent.core.security.SecureStorage
import com.engineeromar.aiagent.domain.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject
import javax.inject.Singleton

/**
 * OpenAI Chat Completions provider using raw OkHttp (keeps the dependency
 * surface minimal; swap to Retrofit when more endpoints are needed).
 * API key is read from [SecureStorage] at call time — never persisted in memory.
 *
 * NOTE: Network call structure is real and aligned with the OpenAI REST API;
 * wire endpoint/model names per your account when integrating.
 */
@Singleton
class OpenAiProvider @Inject constructor(
    private val client: OkHttpClient,
    private val storage: SecureStorage,
    private val json: Json,
) : AiProvider {

    override val id = "openai"
    override val displayName = "OpenAI"

    override suspend fun complete(request: CompletionRequest): CompletionResponse {
        val apiKey = storage.get(SecureStorage.KEY_OPENAI_API_KEY)
            ?: return CompletionResponse("OpenAI API key not configured", "none", 0, 0, "config_missing")

        val body = json.encodeToString(ChatRequest.serializer(), request.toDto())
        val req = Request.Builder()
            .url(BASE_URL)
            .header("Authorization", "Bearer $apiKey")
            .post(body.toRequestBody(JSON))
            .build()

        client.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) return CompletionResponse(
                "OpenAI error ${resp.code}: $raw", "openai", 0, 0, "http_error"
            )
            val parsed = json.decodeFromString(ChatResponse.serializer(), raw)
            return CompletionResponse(
                content = parsed.choices.firstOrNull()?.message?.content.orEmpty(),
                model = parsed.model,
                tokensIn = parsed.usage.promptTokens,
                tokensOut = parsed.usage.completionTokens,
                finishReason = parsed.choices.firstOrNull()?.finishReason ?: "stop",
            )
        }
    }

    override fun stream(request: CompletionRequest): Flow<String> = flow {
        // Real implementation: SSE stream, parse "data:" chunks, emit deltas.
        // Fallback for the starter: delegate to one-shot completion.
        val r = complete(request)
        emit(r.content)
    }.flowOn(Dispatchers.IO)

    private fun CompletionRequest.toDto(): ChatRequest = ChatRequest(
        model = model,
        messages = buildList {
            systemPrompt?.let { add(ChatMessageDto("system", it)) }
            messages.forEach { add(ChatMessageDto(it.role.value, it.content)) }
        },
        temperature = temperature,
        maxTokens = maxTokens,
        stream = false,
    )

    private fun MessageRole.value(): String = name.lowercase()

    companion object {
        private val JSON = "application/json; charset=utf-8".toMediaType()
        private const val BASE_URL = "https://api.openai.com/v1/chat/completions"
    }
}

@Serializable private data class ChatRequest(
    val model: String,
    val messages: List<ChatMessageDto>,
    val temperature: Float,
    @SerialName("max_tokens") val maxTokens: Int,
    val stream: Boolean,
)

@Serializable private data class ChatMessageDto(
    val role: String,
    val content: String,
)

@Serializable private data class ChatResponse(
    val model: String,
    val choices: List<Choice>,
    val usage: Usage,
) {
    @Serializable data class Choice(
        @SerialName("finish_reason") val finishReason: String,
        val message: ChatMessageDto,
    )
    @Serializable data class Usage(
        @SerialName("prompt_tokens") val promptTokens: Int,
        @SerialName("completion_tokens") val completionTokens: Int,
    )
}
