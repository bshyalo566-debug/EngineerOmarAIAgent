package com.engineeromar.aiagent.data.mapper

import com.engineeromar.aiagent.data.local.entity.KnowledgeEntity
import com.engineeromar.aiagent.domain.model.KnowledgeCategory
import com.engineeromar.aiagent.domain.model.KnowledgeDocument
import com.engineeromar.aiagent.domain.model.KnowledgeFileType

fun KnowledgeEntity.toDomain(): KnowledgeDocument = KnowledgeDocument(
    id = id,
    title = title,
    filePath = filePath,
    fileType = runCatching { KnowledgeFileType.valueOf(fileType.uppercase()) }
        .getOrDefault(KnowledgeFileType.TEXT),
    category = runCatching { KnowledgeCategory.valueOf(category.uppercase().replace("-", "_")) }
        .getOrDefault(KnowledgeCategory.GENERAL),
    sizeBytes = sizeBytes,
    pageCount = pageCount,
    createdAt = createdAt,
    lastOpenedAt = lastOpenedAt,
    tags = tags,
)
