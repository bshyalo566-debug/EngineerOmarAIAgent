package com.engineeromar.aiagent.ai.engine

/**
 * An [Intent] is the engine's typed interpretation of a user request.
 * Each intent declares required permissions + which executor handles it.
 *
 * Adding a new capability = add an [Intent] + register an [Executor]. The
 * core engine never changes. (Open/Closed Principle.)
 */
data class Intent(
    val id: String,
    val requiredPermissions: List<String> = emptyList(),
    val priority: Int = 0,
)

object Intents {
    val UNKNOWN = Intent("unknown")
    val GENERATE_CODE = Intent("code.generate")
    val EXPLAIN_CODE = Intent("code.explain")
    val REVIEW_CODE = Intent("code.review")
    val REFACTOR_CODE = Intent("code.refactor")
    val ANSWER_QUESTION = Intent("qa.answer")
    val GIT_COMMIT = Intent("git.commit")
    val GIT_PUSH = Intent("git.push")
    val FILE_CREATE = Intent("file.create")
    val FILE_SEARCH = Intent("file.search")
    val KNOWLEDGE_SEARCH = Intent("knowledge.search")
    val OPEN_APP = Intent("automation.open_app")
    val OPEN_URL = Intent("automation.open_url")
    val SHARE = Intent("automation.share")
    val SEARCH_WEB = Intent("web.search")
}

/** Ordered execution plan produced by the planner. */
data class ExecutionPlan(
    val intent: Intent,
    val steps: List<String>,
    val params: Map<String, String> = emptyMap(),
)
