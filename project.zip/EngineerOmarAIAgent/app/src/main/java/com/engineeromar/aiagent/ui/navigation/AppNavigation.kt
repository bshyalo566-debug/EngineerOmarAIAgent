package com.engineeromar.aiagent.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.engineeromar.aiagent.feature.agent.AgentScreen
import com.engineeromar.aiagent.feature.dashboard.DashboardScreen
import com.engineeromar.aiagent.feature.editor.CodeEditorScreen
import com.engineeromar.aiagent.feature.filemanager.FileManagerScreen
import com.engineeromar.aiagent.feature.git.GitScreen
import com.engineeromar.aiagent.feature.github.GitHubScreen
import com.engineeromar.aiagent.feature.knowledge.KnowledgeScreen
import com.engineeromar.aiagent.feature.project.ProjectDetailScreen
import com.engineeromar.aiagent.feature.project.ProjectsScreen
import com.engineeromar.aiagent.feature.settings.SettingsScreen
import com.engineeromar.aiagent.feature.voice.VoiceScreen

@Composable
fun AppNavigation() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Destination.Dashboard.route) {

        composable(Destination.Dashboard.route) {
            DashboardScreen(onNavigate = { nav.navigate(it.route) })
        }
        composable(Destination.Agent.route) { AgentScreen() }
        composable(Destination.Projects.route) {
            ProjectsScreen(onOpenProject = { id -> nav.navigate("${Destination.Projects.route}/$id") })
        }
        composable(
            route = "${Destination.Projects.route}/{projectId}",
            arguments = listOf(navArgument("projectId") { type = NavType.StringType }),
        ) { backStack ->
            ProjectDetailScreen(
                projectId = backStack.arguments?.getString("projectId").orEmpty(),
                onBack = { nav.popBackStack() },
            )
        }
        composable(Destination.Knowledge.route) { KnowledgeScreen() }
        composable(Destination.Editor.route) { CodeEditorScreen() }
        composable(Destination.Files.route) { FileManagerScreen() }
        composable("git") { GitScreen() }
        composable("github") { GitHubScreen() }
        composable("voice") { VoiceScreen() }
        composable("settings") { SettingsScreen() }
    }
}
