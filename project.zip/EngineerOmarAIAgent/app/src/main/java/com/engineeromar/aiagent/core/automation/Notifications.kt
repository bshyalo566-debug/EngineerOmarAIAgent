package com.engineeromar.aiagent.core.automation

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.engineeromar.aiagent.core.logging.Logger
import com.engineeromar.aiagent.core.permission.PermissionManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Centralised, channel-aware notifier. POST_NOTIFICATIONS is validated before
 * each post (Android 13+) so we never silently drop a notification or crash.
 */
@Singleton
class Notifications @Inject constructor(
    @ApplicationContext private val context: Context,
    private val permissions: PermissionManager,
) {
    init { ensureChannels(context) }

    fun show(id: Int, title: String, body: String, channelId: String = CHANNEL_GENERAL) {
        if (!permissions.isGranted(android.Manifest.permission.POST_NOTIFICATIONS) &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Logger.w("Notifications") { "POST_NOTIFICATIONS not granted — skipping" }
            return
        }
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(id, notification) }
            .onFailure { Logger.w("Notifications") { "notify failed: ${it.message}" } }
    }

    companion object {
        const val CHANNEL_GENERAL = "eo_general"
        const val CHANNEL_TASKS = "eo_tasks"
        const val CHANNEL_AGENT = "eo_agent"

        fun notify(context: Context, id: Int, title: String, body: String) {
            ensureChannels(context)
            NotificationManagerCompat.from(context).notify(
                id,
                NotificationCompat.Builder(context, CHANNEL_GENERAL)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title).setContentText(body).setAutoCancel(true).build()
            )
        }

        fun ensureChannels(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            listOf(
                NotificationChannel(CHANNEL_GENERAL, "General", NotificationManager.IMPORTANCE_DEFAULT),
                NotificationChannel(CHANNEL_TASKS, "Tasks", NotificationManager.IMPORTANCE_LOW),
                NotificationChannel(CHANNEL_AGENT, "Agent", NotificationManager.IMPORTANCE_HIGH),
            ).forEach { ch -> nm.createNotificationChannel(ch) }
        }
    }
}
