package com.engineeromar.aiagent.domain.model

import java.util.Date

/**
 * GitHub REST API domain models. DTOs at the network layer map into these
 * pure types so feature/domain code never depends on Retrofit annotations.
 */

data class GitHubUser(
    val login: String,
    val id: Long,
    val avatarUrl: String,
    val htmlUrl: String,
    val name: String?,
    val bio: String?,
    val publicRepos: Int,
    val followers: Int,
)

data class GitHubRepository(
    val id: Long,
    val name: String,
    val fullName: String,
    val owner: String,
    val description: String?,
    val htmlUrl: String,
    val cloneUrl: String,
    val isPrivate: Boolean,
    val isFork: Boolean,
    val defaultBranch: String,
    val stars: Int,
    val forks: Int,
    val language: String?,
    val updatedAt: Date,
)

data class GitHubCommit(
    val sha: String,
    val shortSha: String,
    val message: String,
    val author: String,
    val date: Date,
    val htmlUrl: String,
)

data class GitHubPullRequest(
    val number: Int,
    val title: String,
    val state: String,        // open | closed
    val isDraft: Boolean,
    val user: String,
    val headBranch: String,
    val baseBranch: String,
    val htmlUrl: String,
    val updatedAt: Date,
)

data class GitHubIssue(
    val number: Int,
    val title: String,
    val state: String,
    val body: String?,
    val user: String,
    val labels: List<String>,
    val htmlUrl: String,
    val updatedAt: Date,
)

data class GitHubRelease(
    val id: Long,
    val tagName: String,
    val name: String?,
    val body: String?,
    val isPrerelease: Boolean,
    val isDraft: Boolean,
    val htmlUrl: String,
    val publishedAt: Date?,
    val assets: List<GitHubAsset>,
)

data class GitHubAsset(
    val id: Long,
    val name: String,
    val downloadUrl: String,
    val sizeBytes: Long,
    val downloadCount: Int,
)

data class CreateRepositoryInput(
    val name: String,
    val description: String?,
    val isPrivate: Boolean,
    val autoInit: Boolean = true,
    val gitignoreTemplate: String? = null,
)
