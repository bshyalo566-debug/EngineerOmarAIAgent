package com.engineeromar.aiagent.data.git

import com.engineeromar.aiagent.core.logging.Logger
import com.engineeromar.aiagent.core.security.SecureStorage
import org.eclipse.jgit.api.Git
import org.eclipse.jgit.lib.PersonIdent
import org.eclipse.jgit.lib.Ref
import org.eclipse.jgit.transport.CredentialsProvider
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Resolves the credentials used by JGit for remote operations. GitHub no
 * longer accepts account passwords, so a Personal Access Token is used as the
 * "password" with the username being the GitHub login (or "x-access-token").
 * Token is pulled lazily from [SecureStorage] and never cached beyond a call.
 */
@Singleton
class GitCredentialProvider @Inject constructor(
    private val storage: SecureStorage,
) {
    fun forUrl(remoteUrl: String?): CredentialsProvider? {
        val token = storage.get(SecureStorage.KEY_GITHUB_PAT) ?: return null
        val username = if (remoteUrl?.startsWith("http") == true) "x-access-token" else "oauth2"
        return UsernamePasswordCredentialsProvider(username, token)
    }
}

/**
 * Low-level JGit facade. Pure data <‑> JGit translation lives here so the
 * repository implementation stays focused on domain Result wiring. Every
 * method performs real git operations on disk.
 */
@Singleton
class JGitEngine @Inject constructor(
    private val creds: GitCredentialProvider,
) {

    fun init(repoPath: File): Boolean = runCatching {
        Git.init().setDirectory(repoPath).call().close()
        Logger.i("Git") { "Initialized repo at ${repoPath.absolutePath}" }
        true
    }.getOrElse { Logger.w("Git") { "init failed: ${it.message}" }; false }

    fun clone(remoteUrl: String, dest: File): Boolean = runCatching {
        Git.cloneRepository()
            .setURI(remoteUrl)
            .setDirectory(dest)
            .setCredentialsProvider(creds.forUrl(remoteUrl))
            .call()
            .use { git ->
                Logger.i("Git") { "Cloned $remoteUrl -> ${dest.absolutePath}" }
                git.log().call().count()
            }
        true
    }.getOrElse { Logger.w("Git") { "clone failed: ${it.message}" }; false }

    fun open(repoPath: File): Git? = if (File(repoPath, ".git").exists())
        Git.open(repoPath) else null

    fun currentBranch(git: Git): String? = runCatching {
        git.repository.fullBranch
    }.getOrNull()

    fun commit(git: Git, message: String, amend: Boolean): String? = runCatching {
        val cmd = git.commit().setMessage(message)
        if (amend) cmd.setAmend(true)
        val name = git.repository.config["user"]?.get("name") ?: "Engineer Omar"
        val email = git.repository.config["user"]?.get("email") ?: "omar@engineer.local"
        cmd.setAuthor(PersonIdent(name, email)).setCommitter(PersonIdent(name, email)).call()
        git.repository.resolve("HEAD")?.name
    }.getOrNull()

    fun push(git: Git, remote: String): Boolean = runCatching {
        git.push().setRemote(remote).setCredentialsProvider(creds.forUrl(git.repository.config.getString("remote", remote, "url"))).call()
        true
    }.getOrElse { Logger.w("Git") { "push failed: ${it.message}" }; false }

    fun pull(git: Git, remote: String): Boolean = runCatching {
        git.pull().setRemote(remote).setCredentialsProvider(creds.forUrl(git.repository.config.getString("remote", remote, "url"))).call()
        true
    }.getOrElse { Logger.w("Git") { "pull failed: ${it.message}" }; false }

    fun fetch(git: Git, remote: String): Boolean = runCatching {
        git.fetch().setRemote(remote).setCredentialsProvider(creds.forUrl(git.repository.config.getString("remote", remote, "url"))).call()
        true
    }.getOrElse { Logger.w("Git") { "fetch failed: ${it.message}" }; false }

    fun checkout(git: Git, ref: String, create: Boolean): Boolean = runCatching {
        val cmd = git.checkout().setName(ref)
        if (create) cmd.setCreateBranch(true).setName(ref)
        cmd.call()
        true
    }.getOrNull() ?: false

    fun merge(git: Git, branch: String): Boolean = runCatching {
        val merge = git.merge().include(git.repository.findRef(branch))
        merge.call().mergeStatus.isSuccessful
    }.getOrNull() ?: false

    fun listBranches(git: Git): List<Ref> = runCatching {
        git.branchList().call().toList()
    }.getOrDefault(emptyList())

    fun listLocalBranches(git: Git): List<Ref> = listBranches(git)
        .filter { it.name.startsWith("refs/heads/") }
}
