package com.engineeromar.aiagent.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BubbleChart
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.School
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Destination(val route: String, val titleKey: String, val icon: ImageVector) {
    data object Dashboard : Destination("dashboard", "nav_dashboard", Icons.Outlined.AutoAwesome)
    data object Agent : Destination("agent", "nav_agent", Icons.Outlined.BubbleChart)
    data object Projects : Destination("projects", "nav_projects", Icons.Outlined.Folder)
    data object Editor : Destination("editor", "nav_editor", Icons.Outlined.Code)
    data object Knowledge : Destination("knowledge", "nav_knowledge", Icons.Outlined.School)
    data object Files : Destination("files", "nav_files", Icons.Outlined.Description)
    data object Git : Destination("git", "nav_git", Icons.Outlined.Code)
    data object GitHub : Destination("github", "nav_github", Icons.Outlined.Code)
    data object Voice : Destination("voice", "nav_voice", Icons.Outlined.GraphicEq)
    data object Settings : Destination("settings", "nav_settings", Icons.Outlined.Code)
}

/** Primary bottom-navigation destinations. */
val bottomNav = listOf(
    Destination.Dashboard, Destination.Agent, Destination.Projects, Destination.Knowledge, Destination.Files,
)
