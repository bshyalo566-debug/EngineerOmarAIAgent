package com.engineeromar.aiagent.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.engineeromar.aiagent.core.config.AiProviderType
import com.engineeromar.aiagent.core.config.AppConfig
import com.engineeromar.aiagent.core.config.ConfigurationManager
import com.engineeromar.aiagent.core.config.Language
import com.engineeromar.aiagent.core.config.PerformanceMode
import com.engineeromar.aiagent.core.config.ThemeMode
import com.engineeromar.aiagent.core.security.SecureStorage
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val configManager: ConfigurationManager,
    private val secure: SecureStorage,
) : ViewModel() {

    val config: StateFlow<AppConfig?> = configManager.config
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun setLanguage(language: Language) = viewModelScope.launch {
        configManager.update { it.copy(language = language) }
    }

    fun setTheme(theme: ThemeMode) = viewModelScope.launch {
        configManager.update { it.copy(theme = theme) }
    }

    fun setAiProvider(provider: AiProviderType) = viewModelScope.launch {
        configManager.update { it.copy(aiProvider = provider) }
    }

    fun setBiometric(enabled: Boolean) = viewModelScope.launch {
        configManager.update { it.copy(biometricLock = enabled) }
    }

    fun setPerformance(mode: PerformanceMode) = viewModelScope.launch {
        configManager.update { it.copy(performanceMode = mode) }
    }

    fun saveApiKey(key: String, value: String) {
        if (value.isBlank()) secure.remove(key) else secure.put(key, value)
    }

    fun apiKey(key: String): String = secure.get(key).orEmpty()

    fun clearAllSecrets() = secure.clear()
}
