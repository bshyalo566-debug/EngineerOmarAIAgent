package com.engineeromar.aiagent.data.mapper

import com.engineeromar.aiagent.data.local.entity.FileItemEntity
import com.engineeromar.aiagent.domain.model.FileItem
import java.io.File
import java.util.Date

fun File.toDomain(favorite: Boolean = false, lastOpenedAt: Date? = null): FileItem {
    val name = name
    val ext = if (isDirectory) "" else name.substringAfterLast('.', "")
    return FileItem(
        path = absolutePath,
        name = name,
        extension = ext,
        isDirectory = isDirectory,
        sizeBytes = if (isDirectory) 0L else length(),
        lastModified = Date(lastModified()),
        isHidden = name.startsWith("."),
        mimeType = guessMime(ext, isDirectory),
        isFavorite = favorite,
        lastOpenedAt = lastOpenedAt,
    )
}

fun FileItemEntity.toDomain(): FileItem = FileItem(
    path = path,
    name = name,
    extension = ext,
    isDirectory = isDirectory,
    sizeBytes = sizeBytes,
    lastModified = Date(0),
    isHidden = name.startsWith("."),
    mimeType = mimeType ?: "application/octet-stream",
    isFavorite = isFavorite,
    lastOpenedAt = lastOpenedAt?.let(::Date),
)

fun FileItem.toEntity(projectId: String? = null): FileItemEntity = FileItemEntity(
    id = path,
    path = path,
    name = name,
    ext = extension,
    isDirectory = isDirectory,
    sizeBytes = sizeBytes,
    projectId = projectId,
    isFavorite = isFavorite,
    lastOpenedAt = lastOpenedAt?.time,
    mimeType = mimeType,
)

private fun guessMime(ext: String, isDirectory: Boolean): String {
    if (isDirectory) return "resource/folder"
    return when (ext.lowercase()) {
        "txt", "md" -> "text/plain"
        "kt", "java" -> "text/x-kotlin"
        "xml" -> "application/xml"
        "json" -> "application/json"
        "html", "htm" -> "text/html"
        "css" -> "text/css"
        "js" -> "application/javascript"
        "ts" -> "application/typescript"
        "py" -> "text/x-python"
        "pdf" -> "application/pdf"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "png", "jpg", "jpeg", "gif", "webp" -> "image/*"
        "zip" -> "application/zip"
        else -> "application/octet-stream"
    }
}
