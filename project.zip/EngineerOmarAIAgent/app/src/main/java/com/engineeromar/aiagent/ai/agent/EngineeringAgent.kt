package com.engineeromar.aiagent.ai.agent

import com.engineeromar.aiagent.ai.engine.CommandEngine
import com.engineeromar.aiagent.ai.engine.CompletionReport
import com.engineeromar.aiagent.ai.memory.MemoryManager
import com.engineeromar.aiagent.ai.provider.AiProvider
import com.engineeromar.aiagent.ai.provider.AiProviderFactory
import com.engineeromar.aiagent.ai.provider.CompletionRequest
import com.engineeromar.aiagent.ai.provider.EngineeringSystemPrompt
import com.engineeromar.aiagent.core.config.AiProviderType
import com.engineeromar.aiagent.core.config.ConfigurationManager
import com.engineeromar.aiagent.core.logging.Logger
import com.engineeromar.aiagent.domain.model.ChatMessage
import com.engineeromar.aiagent.domain.model.ConversationScope
import com.engineeromar.aiagent.domain.model.MemoryScope
import com.engineeromar.aiagent.domain.model.MessageRole
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.first

/**
 * The AI Engineering Agent. Combines:
 *  - the [AiProvider] for raw completions,
 *  - the [MemoryManager] for long-term recall,
 *  - the [CommandEngine] for executable actions.
 *
 * Conversation history persistence is delegated to ConversationRepository.
 * This class is deliberately orchestration-only (Single Responsibility).
 */
@Singleton
class EngineeringAgent @Inject constructor(
    private val providerFactory: AiProviderFactory,
    private val memory: MemoryManager,
    private val commandEngine: CommandEngine,
    private val config: ConfigurationManager,
) {
    suspend fun ask(
        history: List<ChatMessage>,
        userInput: String,
        scope: ConversationScope,
    ): String {
        val provider = activeProvider()
        val memoryScope = scopeToMemory(scope)
        val context = memory.contextBlock(memoryScope)

        val messages = history + ChatMessage(
            id = "tmp", conversationId = "tmp", role = MessageRole.USER,
            content = userInput, createdAt = System.currentTimeMillis(),
            model = null, attachments = emptyList(),
        )

        val request = CompletionRequest(
            model = "gpt-4o-mini",
            messages = messages,
            systemPrompt = EngineeringSystemPrompt.TEXT + "\n# Long-term context\n$context",
        )

        return runCatching { provider.complete(request).content }
            .onFailure { Logger.e("Agent") { it.message ?: "provider error" } }
            .getOrElse { "I couldn't reach the AI provider. Check your API key in Settings." }
    }

    /** Routes a request through the deterministic command pipeline. */
    suspend fun run(request: String): CompletionReport = commandEngine.execute(request)

    /** Learns a durable fact about the user/project. */
    suspend fun remember(scope: ConversationScope, content: String, category: String) =
        memory.remember(scopeToMemory(scope), category, content)

    private suspend fun activeProvider(): AiProvider =
        providerFactory.forType(config.config.first().aiProvider)

    private fun scopeToMemory(scope: ConversationScope): MemoryScope = when (scope) {
        ConversationScope.GENERAL -> MemoryScope.USER
        ConversationScope.PROJECT -> MemoryScope.GLOBAL
        ConversationScope.KNOWLEDGE -> MemoryScope.GLOBAL
        ConversationScope.CODE -> MemoryScope.USER
    }
}
