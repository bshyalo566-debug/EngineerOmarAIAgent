package com.engineeromar.aiagent.domain.model

/**
 * Plugin SDK domain types. A plugin is a versioned, sandboxed extension that
 * contributes [Executor]s, [Intent]s, and UI contributions to the agent
 * without modifying the core. See `plugin/` package for the contract.
 */
data class PluginManifest(
    val id: String,
    val name: String,
    val version: String,
    val author: String,
    val description: String,
    val minAppVersion: String,
    val permissions: List<PluginPermission>,
    val entryPointClass: String,
)

enum class PluginPermission {
    NETWORK,
    FILE_READ,
    FILE_WRITE,
    DATABASE,
    AI_PROVIDER,
    CLIPBOARD,
    NOTIFICATIONS,
}

enum class PluginState { LOADED, ENABLED, DISABLED, ERRORED }

data class PluginInfo(
    val manifest: PluginManifest,
    val state: PluginState,
    val loadDurationMs: Long,
    val errorMessage: String?,
)
