package com.engineeromar.aiagent.feature.github

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun GitHubScreen(vm: GitHubViewModel = hiltViewModel()) {
    val user by vm.user.collectAsStateWithLifecycle()
    val repos by vm.repos.collectAsStateWithLifecycle()
    val tokenValid by vm.tokenValid.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()

    var newName by remember { mutableStateOf("") }
    var newDesc by remember { mutableStateOf("") }
    var isPrivate by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.checkToken() }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("GitHub", style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary)

        tokenValid?.let { valid ->
            Text(
                if (valid) "Token valid" else "Token invalid or missing — add a PAT in Settings",
                color = if (valid) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(vertical = 4.dp),
            )
            if (valid) {
                OutlinedButton(onClick = vm::loadProfile, enabled = !busy) { Text("Load profile & repos") }
            }
        }

        user?.let { u ->
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(u.name ?: u.login, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("@${u.login}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${u.publicRepos} repos · ${u.followers} followers", fontSize = 12.sp)
                    u.bio?.let { Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }

        Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text("New repository", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.size(6.dp))
                OutlinedTextField(newName, { newName = it }, Modifier.fillMaxWidth(),
                    label = { Text("Name") }, singleLine = true)
                Spacer(Modifier.size(6.dp))
                OutlinedTextField(newDesc, { newDesc = it }, Modifier.fillMaxWidth(),
                    label = { Text("Description") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(isPrivate, { isPrivate = it })
                    Spacer(Modifier.size(8.dp))
                    Text(if (isPrivate) "Private" else "Public")
                }
                Spacer(Modifier.size(6.dp))
                Button(onClick = { if (newName.isNotBlank()) vm.create(newName, newDesc, isPrivate) },
                    enabled = !busy && newName.isNotBlank()) { Text("Create") }
            }
        }

        message?.let { Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(vertical = 4.dp)) }

        Text("Repositories", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(repos, key = { it.id }) { repo ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(repo.fullName, fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary)
                        repo.description?.let { Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        Text("★ ${repo.stars} · ⑂ ${repo.forks} · ${repo.language ?: "—"}",
                            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
