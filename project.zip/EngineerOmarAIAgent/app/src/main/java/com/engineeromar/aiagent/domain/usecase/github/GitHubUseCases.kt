package com.engineeromar.aiagent.domain.usecase.github

import com.engineeromar.aiagent.domain.model.CreateRepositoryInput
import com.engineeromar.aiagent.domain.model.GitHubRepository
import com.engineeromar.aiagent.domain.repository.GitHubRepository
import javax.inject.Inject

class GetCurrentUserUseCase @Inject constructor(private val repo: GitHubRepository) {
    suspend operator fun invoke() = repo.currentUser()
}

class ListReposUseCase @Inject constructor(private val repo: GitHubRepository) {
    suspend operator fun invoke(page: Int = 1) = repo.listRepositories(page)
}

class CreateRepoUseCase @Inject constructor(private val repo: GitHubRepository) {
    suspend operator fun invoke(input: CreateRepositoryInput) = repo.createRepository(input)
}

class ValidateGitHubTokenUseCase @Inject constructor(private val repo: GitHubRepository) {
    suspend operator fun invoke() = repo.isTokenValid()
}
