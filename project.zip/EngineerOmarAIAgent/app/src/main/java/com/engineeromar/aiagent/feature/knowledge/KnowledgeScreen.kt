package com.engineeromar.aiagent.feature.knowledge

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.engineeromar.aiagent.domain.model.KnowledgeCategory

@Composable
fun KnowledgeScreen(vm: KnowledgeViewModel = hiltViewModel()) {
    val docs by vm.documents.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    val semantic by vm.semantic.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val path = uri?.path
        if (path != null) vm.import(path, KnowledgeCategory.GENERAL)
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Knowledge Base", style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary)
        Text("${docs.size} documents indexed · offline search",
            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)

        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query, onValueChange = vm::onQueryChange,
                modifier = Modifier.weight(1f), singleLine = true,
                label = { Text("Search") }, leadingIcon = { Icon(Icons.Outlined.Search, null) },
            )
            Spacer(Modifier.size(8.dp))
            Switch(semantic, vm::setSemantic)
            Spacer(Modifier.size(4.dp))
            Text("Semantic", fontSize = 11.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = vm::search) { Text("Search") }
            OutlinedButton(onClick = vm::rebuild) { Icon(Icons.Outlined.Refresh, null); Spacer(Modifier.size(4.dp)); Text("Rebuild index") }
        }

        message?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
        }

        if (results.isNotEmpty()) {
            Text("Results", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(results, key = { it.documentId }) { hit ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            Text(hit.title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            Text(hit.snippet, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3)
                            Text("score ${"%.2f".format(hit.score)} · ${hit.category}",
                                fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { picker.launch(arrayOf("application/pdf", "text/*", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }) {
                    Icon(Icons.Outlined.PictureAsPdf, null); Spacer(Modifier.size(4.dp)); Text("Import document")
                }
            }
            Text("Library", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(docs, key = { it.id }) { doc ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.School, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.size(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(doc.title, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                                Text("${doc.fileType.ext} · ${doc.category} · ${doc.sizeBytes / 1024} KB",
                                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { vm.delete(doc.id) }) {
                                Icon(Icons.Outlined.Delete, "Delete", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}
