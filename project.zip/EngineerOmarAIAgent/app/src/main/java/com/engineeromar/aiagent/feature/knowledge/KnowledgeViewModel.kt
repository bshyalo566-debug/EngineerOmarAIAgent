package com.engineeromar.aiagent.feature.knowledge

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.engineeromar.aiagent.domain.model.KnowledgeCategory
import com.engineeromar.aiagent.domain.model.KnowledgeDocument
import com.engineeromar.aiagent.domain.model.SearchResult
import com.engineeromar.aiagent.domain.repository.KnowledgeRepository
import com.engineeromar.aiagent.domain.util.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class KnowledgeViewModel @Inject constructor(
    private val repo: KnowledgeRepository,
) : ViewModel() {

    val documents: StateFlow<List<KnowledgeDocument>> = repo.observeDocuments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _query = MutableStateFlow("")
    val query = _query.asStateFlow()

    private val _results = MutableStateFlow<List<SearchResult>>(emptyList())
    val results = _results.asStateFlow()

    private val _semantic = MutableStateFlow(false)
    val semantic = _semantic.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message = _message.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()

    fun onQueryChange(q: String) { _query.value = q }

    fun setSemantic(enabled: Boolean) { _semantic.value = enabled }

    fun search() = viewModelScope.launch {
        val q = _query.value.trim()
        if (q.isEmpty()) { _results.value = emptyList(); return@launch }
        _busy.value = true
        _results.value = if (_semantic.value) repo.semanticSearch(q) else repo.search(q)
        _busy.value = false
    }

    fun import(path: String, category: KnowledgeCategory) = viewModelScope.launch {
        _busy.value = true
        when (val r = repo.importDocument(path, category)) {
            is Result.Success -> _message.value = "Imported ${r.data.title}"
            is Result.Failure -> _message.value = r.error.message
        }
        _busy.value = false
    }

    fun delete(id: String) = viewModelScope.launch {
        when (val r = repo.deleteDocument(id)) {
            is Result.Success -> _message.value = "Deleted"
            is Result.Failure -> _message.value = r.error.message
        }
    }

    fun rebuild() = viewModelScope.launch {
        when (val r = repo.rebuildIndex()) {
            is Result.Success -> _message.value = "Index: ${r.data} docs"
            is Result.Failure -> _message.value = r.error.message
        }
    }
}
