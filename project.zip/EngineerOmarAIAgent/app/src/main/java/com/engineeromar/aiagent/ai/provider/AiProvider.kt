package com.engineeromar.aiagent.ai.provider

import com.engineeromar.aiagent.domain.model.ChatMessage
import com.engineeromar.aiagent.domain.model.MessageRole
import kotlinx.coroutines.flow.Flow

/**
 * Pluggable AI provider contract (Strategy pattern). The agent depends only
 * on this interface — OpenAI, Anthropic, Gemini, and a future local (on-device)
 * provider each implement it. New providers never touch the agent core.
 */
interface AiProvider {
    val id: String
    val displayName: String

    suspend fun complete(request: CompletionRequest): CompletionResponse

    /** Streaming variant for the chat UI — emits token deltas. */
    fun stream(request: CompletionRequest): Flow<String>
}

data class CompletionRequest(
    val model: String,
    val messages: List<ChatMessage>,
    val systemPrompt: String? = null,
    val temperature: Float = 0.2f,
    val maxTokens: Int = 2048,
    val tools: List<ToolDescriptor> = emptyList(),
)

data class CompletionResponse(
    val content: String,
    val model: String,
    val tokensIn: Int,
    val tokensOut: Int,
    val finishReason: String,
)

data class ToolDescriptor(
    val name: String,
    val description: String,
    val parametersJson: String,
)

/** Helper to build the canonical engineering system prompt used across providers. */
object EngineeringSystemPrompt {
    const val TEXT = """
You are Engineer Omar, a senior Android & software engineering agent embedded in an Android phone.
You operate inside a clean-architecture, MVVM, offline-first application.
Always:
- Break large requests into numbered, verifiable steps before writing code.
- Produce production-ready, well-structured code with correct error handling.
- Prefer official, on-platform APIs; never suggest rooting or exploits.
- Cite which file/module a change targets.
- Ask for missing permissions/data only when strictly necessary.
Be concise. When you execute actions, return a short structured completion report.
"""
}
