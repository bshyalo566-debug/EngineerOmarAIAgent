package com.engineeromar.aiagent.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Knowledge Base document. Supports PDF/MD/TXT/DOCX. [contentText] is the
 * extracted plain text used for FTS/semantic search; [embedding] is an
 * optional vector for future on-device semantic search.
 */
@Entity(
    tableName = "knowledge",
    indices = [Index("category"), Index("fileType"), Index("title")],
)
data class KnowledgeEntity(
    @PrimaryKey val id: String,
    val title: String,
    val filePath: String,
    val fileType: String,           // pdf | md | txt | docx
    val category: String,           // books | api-docs | notes | framework-docs
    val contentText: String,        // extracted plain text (indexed)
    val embedding: ByteArray? = null,
    val sizeBytes: Long,
    val pageCount: Int = 0,
    val createdAt: Long,
    val lastOpenedAt: Long? = null,
    val tags: List<String> = emptyList(),
) {
    override fun equals(other: Any?): Boolean = other is KnowledgeEntity && other.id == id
    override fun hashCode(): Int = id.hashCode()
}
