package com.engineeromar.aiagent.feature.git

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.GitCommit
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun GitScreen(vm: GitViewModel = hiltViewModel()) {
    val status by vm.status.collectAsStateWithLifecycle()
    val summary by vm.summary.collectAsStateWithLifecycle()
    val log by vm.logFlow.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()

    var commitMsg by remember { mutableStateOf("") }
    var cloneUrl by remember { mutableStateOf("") }
    var cloneName by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Git", style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary)

        Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text("Clone repository", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.size(6.dp))
                OutlinedTextField(cloneUrl, { cloneUrl = it }, Modifier.fillMaxWidth(),
                    label = { Text("Remote URL") }, singleLine = true)
                Spacer(Modifier.size(6.dp))
                OutlinedTextField(cloneName, { cloneName = it }, Modifier.fillMaxWidth(),
                    label = { Text("Local folder name") }, singleLine = true)
                Spacer(Modifier.size(6.dp))
                Button(onClick = { if (cloneUrl.isNotBlank()) vm.cloneRepo(cloneUrl, cloneName.ifBlank { "repo" }) },
                    enabled = !busy && cloneUrl.isNotBlank()) {
                    Text("Clone")
                }
            }
        }

        summary?.let {
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Branch: ${it.branch}", fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface)
                    Text("Remote: ${it.remoteUrl ?: "—"}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    Text("Status: ${if (it.isClean) "clean" else "${it.uncommittedChanges} changes"}",
                        color = if (it.isClean) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.error)
                }
            }
        }

        status?.let {
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Changes", style = MaterialTheme.typography.titleSmall)
                    val all = it.staged + it.unstaged
                    all.take(8).forEach { e ->
                        Text("• [${e.changeType}] ${e.path}",
                            fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (it.untracked.isNotEmpty()) {
                        Text("Untracked: ${it.untracked.size}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(commitMsg, { commitMsg = it },
                Modifier.weight(1f), label = { Text("Commit message") }, singleLine = true)
            OutlinedButton(onClick = { if (commitMsg.isNotBlank()) vm.commitAll(commitMsg).also { commitMsg = "" } },
                enabled = !busy) { Icon(Icons.Outlined.GitCommit, null); Spacer(Modifier.size(4.dp)); Text("Commit") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = vm::push, enabled = !busy) {
                Icon(Icons.Outlined.CloudUpload, null); Spacer(Modifier.size(4.dp)); Text("Push")
            }
            OutlinedButton(onClick = vm::pull, enabled = !busy) {
                Icon(Icons.Outlined.CloudDownload, null); Spacer(Modifier.size(4.dp)); Text("Pull")
            }
        }

        message?.let {
            Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(vertical = 6.dp))
        }

        Text("History", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(log, key = { it.hash }) { c ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(c.shortHash, color = MaterialTheme.colorScheme.primary,
                        fontFamily = FontFamily.Monospace, modifier = Modifier.padding(end = 8.dp))
                    Column {
                        Text(c.message.lineSequence().firstOrNull().orEmpty(),
                            color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, maxLines = 1)
                        Text("${c.author} · ${c.date}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}
