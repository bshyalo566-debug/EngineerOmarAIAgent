package com.engineeromar.aiagent.ai.engine

import com.engineeromar.aiagent.core.logging.Logger
import com.engineeromar.aiagent.core.permission.PermissionManager
import com.engineeromar.aiagent.data.local.dao.CommandLogDao
import com.engineeromar.aiagent.data.local.entity.CommandLogEntity
import com.engineeromar.aiagent.domain.model.CommandStatus
import com.engineeromar.aiagent.domain.util.Result
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.serialization.json.Json

/**
 * The Command Execution Engine — the heart of the agent.
 *
 * Pipeline (deterministic, observable, fully logged):
 *
 *   User Request
 *     → Intent Detection
 *     → Task Planning
 *     → Permission Validation
 *     → Execution
 *     → Verification
 *     → Logging
 *     → Completion Report
 *
 * Each stage is a pure function / collaborator, so the engine is trivially
 * unit-testable and extensible (Plugin System slots new [Intent]s here).
 */
@Singleton
class CommandEngine @Inject constructor(
    private val intentDetector: IntentDetector,
    private val taskPlanner: TaskPlanner,
    private val permissionManager: PermissionManager,
    private val executorRegistry: ExecutorRegistry,
    private val verifier: Verifier,
    private val logDao: CommandLogDao,
    private val json: Json,
) {

    private val _reports = MutableSharedFlow<CompletionReport>(replay = 0, extraBufferCapacity = 16)
    val reports: SharedFlow<CompletionReport> = _reports.asSharedFlow()

    suspend fun execute(rawRequest: String, subsystem: String = "agent"): CompletionReport {
        val id = UUID.randomUUID().toString()
        val started = System.currentTimeMillis()
        Logger.i("CommandEngine") { "→ $rawRequest" }

        // 1) Intent detection
        val intent = intentDetector.detect(rawRequest)

        // 2) Task planning
        val plan = taskPlanner.plan(intent, rawRequest)

        // 3) Permission validation
        val permissionResult = permissionManager.validate(intent.requiredPermissions)
        if (permissionResult is Result.Failure) {
            return fail(id, rawRequest, intent, plan, subsystem, permissionResult.error.message, started, perms = false)
        }

        // 4) Execution
        val executor = executorRegistry.executorFor(intent)
            ?: return fail(id, rawRequest, intent, plan, subsystem, "No executor for intent ${intent.id}", started)

        val execResult = runCatching { executor.execute(plan) }
            .getOrElse { return fail(id, rawRequest, intent, plan, subsystem, it.message ?: "Execution error", started) }

        // 5) Verification
        val verificationPassed = verifier.verify(intent, plan, execResult)

        // 6) Logging + 7) Completion report
        val duration = System.currentTimeMillis() - started
        val report = CompletionReport(
            id = id, intent = intent.id, request = rawRequest, plan = plan.steps,
            status = if (verificationPassed) CommandStatus.SUCCESS else CommandStatus.FAILED,
            durationMs = duration, message = execResult.message, verificationPassed = verificationPassed,
        )
        persist(id, rawRequest, intent, plan, subsystem, report.status, duration, null, verificationPassed)
        _reports.tryEmit(report)
        return report
    }

    private suspend fun fail(
        id: String, request: String, intent: Intent, plan: ExecutionPlan,
        subsystem: String, message: String?, started: Long, perms: Boolean = true,
    ): CompletionReport {
        val report = CompletionReport(
            id = id, intent = intent.id, request = request, plan = plan.steps,
            status = CommandStatus.FAILED, durationMs = System.currentTimeMillis() - started,
            message = message, verificationPassed = false,
        )
        persist(id, request, intent, plan, subsystem, report.status, report.durationMs, message, perms, false)
        _reports.tryEmit(report)
        return report
    }

    private suspend fun persist(
        id: String, request: String, intent: Intent, plan: ExecutionPlan,
        subsystem: String, status: CommandStatus, durationMs: Long,
        message: String?, perms: Boolean, verificationPassed: Boolean,
    ) {
        runCatching {
            logDao.insert(
                CommandLogEntity(
                    id = id, createdAt = System.currentTimeMillis(),
                    intent = intent.id, request = request,
                    plan = json.encodeToString(ExecutionPlan.serializer(), plan),
                    status = status.name.lowercase(), durationMs = durationMs,
                    permissionGranted = perms, errorMessage = message,
                    subsystem = subsystem, verificationPassed = verificationPassed,
                )
            )
        }
    }
}

data class CompletionReport(
    val id: String,
    val intent: String,
    val request: String,
    val plan: List<String>,
    val status: CommandStatus,
    val durationMs: Long,
    val message: String?,
    val verificationPassed: Boolean,
)
