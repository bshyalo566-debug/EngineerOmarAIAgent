package com.engineeromar.aiagent.core.storage

import android.content.Context
import com.engineeromar.aiagent.core.logging.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single source of truth for the app's organised local storage layout.
 *
 * Projects/   — managed project trees
 * Knowledge/  — imported docs (PDF/MD/TXT/DOCX)
 * Templates/  — project & snippet templates
 * Logs/       — rotating log files
 * Backups/    — encrypted DB + settings exports
 * Downloads/  — agent-generated artifacts (code, docs)
 * Cache/      — transient, cleared on low-memory
 * Exports/    — share-ready exports
 *
 * Everything lives under app-private external storage (no broad permission
 * needed) + scoped cache, preserving user privacy by default.
 */
@Singleton
class StorageDirectories @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    val root: File = context.getExternalFilesDir(null) ?: context.filesDir

    val projectsDir = File(root, "Projects").apply { mkdirs() }
    val knowledgeDir = File(root, "Knowledge").apply { mkdirs() }
    val templatesDir = File(root, "Templates").apply { mkdirs() }
    val logsDir = File(context.filesDir, "Logs").apply { mkdirs() }   // private
    val backupsDir = File(root, "Backups").apply { mkdirs() }
    val downloadsDir = File(root, "Downloads").apply { mkdirs() }
    val cacheDir = File(context.cacheDir, "EngineerOmar").apply { mkdirs() }
    val exportsDir = File(root, "Exports").apply { mkdirs() }

    init {
        Logger.d("Storage") { "Root: ${root.absolutePath}" }
    }
}
