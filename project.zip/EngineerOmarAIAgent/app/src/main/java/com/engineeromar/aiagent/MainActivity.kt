package com.engineeromar.aiagent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.engineeromar.aiagent.core.config.ThemeMode
import com.engineeromar.aiagent.ui.MainScaffold
import com.engineeromar.aiagent.ui.MainViewModel
import com.engineeromar.aiagent.ui.theme.EngineerOmarTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single-activity entry point. Resolves the configured theme (dark / light /
 * system) before composing the [MainScaffold]; everything else is owned by
 * the scaffold + NavHost.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
            ),
        )
        setContent {
            val vm: MainViewModel = hiltViewModel()
            val config by vm.config.collectAsStateWithLifecycle(initialValue = null)

            val dark = when (config?.theme) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                else -> isSystemInDarkTheme()
            }

            EngineerOmarTheme(darkTheme = dark) {
                MainScaffold()
            }
        }
    }
}
