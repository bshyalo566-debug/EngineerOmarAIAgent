package com.engineeromar.aiagent.feature.editor.format

import com.engineeromar.aiagent.feature.editor.highlight.CodeLanguage

/**
 * A pragmatic, dependency-free code formatter for the editor. It normalises
 * indentation (consistent indent width, no mixed tabs), trims trailing
 * whitespace, collapses 3+ blank lines, and ensures a trailing newline. It
 * deliberately does NOT reflow argument lists (opinionated reformatting is
 * the domain of a language-specific tool wired via the Plugin SDK).
 */
class CodeFormatter(private val indentSize: Int = 4) {

    fun format(source: String, language: CodeLanguage): String {
        val useTabs = false
        val indent = if (useTabs) "\t" else " ".repeat(indentSize)
        val lines = source.replace("\r\n", "\n").split("\n")
        val out = ArrayList<String>(lines.size)
        var depth = 0
        var blankRun = 0

        for (raw in lines) {
            val trimmed = raw.trim()
            if (trimmed.isEmpty()) {
                blankRun++
                if (blankRun <= 2) out.add("")
                continue
            }
            blankRun = 0
            val closesOnStart = trimmed.firstOrNull() in ")]}"
            val effectiveDepth = (depth - (if (closesOnStart) 1 else 0)).coerceAtLeast(0)
            out.add(indent.repeat(effectiveDepth) + trimmed)

            val opens = count(trimmed, '(') + count(trimmed, '[') + count(trimmed, '{')
            val closes = count(trimmed, ')') + count(trimmed, ']') + count(trimmed, '}')
            // String-aware net delta is approximate; sufficient for display formatting.
            val net = opens - closes - (if (closesOnStart) 0 else 0)
            depth = (depth + net).coerceAtLeast(0)
        }
        var joined = out.joinToString("\n").trimEnd('\n')
        if (joined.isNotEmpty()) joined += "\n"
        return joined
    }

    private fun count(s: String, ch: Char): Int {
        var c = 0
        var inStr: Char? = null
        var esc = false
        for (x in s) {
            when {
                esc -> esc = false
                x == '\\' -> esc = true
                inStr != null && x == inStr -> inStr = null
                inStr == null && (x == '"' || x == '\'' || x == '`') -> inStr = x
                inStr == null && x == ch -> c++
            }
        }
        return c
    }
}
