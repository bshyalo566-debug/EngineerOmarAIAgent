package com.engineeromar.aiagent.feature.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BubbleChart
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.School
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.engineeromar.aiagent.ui.navigation.Destination

private data class Tile(val icon: ImageVector, val title: String, val route: Destination)

@Composable
fun DashboardScreen(onNavigate: (Destination) -> Unit) {
    val tiles = listOf(
        Tile(Icons.Outlined.BubbleChart, "AI Agent", Destination.Agent),
        Tile(Icons.Outlined.Folder, "Projects", Destination.Projects),
        Tile(Icons.Outlined.Code, "Code Editor", Destination.Editor),
        Tile(Icons.Outlined.School, "Knowledge", Destination.Knowledge),
        Tile(Icons.Outlined.Description, "Files", Destination.Files),
        Tile(Icons.Outlined.Code, "Git", Destination.Git),
        Tile(Icons.Outlined.Code, "GitHub", Destination.GitHub),
        Tile(Icons.Outlined.GraphicEq, "Voice", Destination.Voice),
    )

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Box(
            Modifier.fillMaxWidth().height(140.dp).clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.CenterStart,
        ) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
                Column(Modifier.padding(start = 14.dp)) {
                    Text("Engineer Omar", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("Your Android AI engineering platform", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
        Spacer(Modifier.size(16.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(tiles) { tile -> DashboardTile(tile, onClick = { onNavigate(tile.route) }) }
        }
    }
}

@Composable
private fun DashboardTile(tile: Tile, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface).clickable(onClick = onClick)
            .padding(16.dp),
    ) {
        Column(Modifier.align(Alignment.CenterStart)) {
            Icon(tile.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            Spacer(Modifier.size(10.dp))
            Text(tile.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
