package com.engineeromar.aiagent.feature.voice

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.engineeromar.aiagent.domain.model.VoiceLanguage

@Composable
fun VoiceScreen(vm: VoiceViewModel = hiltViewModel()) {
    val listening by vm.listening.collectAsStateWithLifecycle()
    val partial by vm.partial.collectAsStateWithLifecycle()
    val transcript by vm.transcript.collectAsStateWithLifecycle()
    val reply by vm.reply.collectAsStateWithLifecycle()
    val speaking by vm.speaking.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val language by vm.language.collectAsStateWithLifecycle()

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) vm.startListening() }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Voice Assistant", style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(24.dp))

        // Language toggle
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            VoiceLanguage.SUPPORTED.forEach { lang ->
                Button(
                    onClick = { vm.setLanguage(lang) },
                    enabled = lang != language,
                ) { Text(lang.display) }
            }
        }

        Spacer(Modifier.height(32.dp))

        // Mic button
        val color by animateColorAsState(
            if (listening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
            label = "mic",
        )
        Box(
            Modifier.size(140.dp).clip(CircleShape).background(color),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (listening) Icons.Outlined.GraphicEq else Icons.Outlined.Mic,
                contentDescription = "Microphone",
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(56.dp),
            )
        }

        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            if (!vm.startListening()) {
                permLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
            }
        }) { Text(if (listening) "Listening…" else "Tap to speak") }

        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        }

        Spacer(Modifier.height(16.dp))
        if (partial.isNotEmpty()) {
            Text("… $partial", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (transcript.isNotEmpty()) {
            Text("You: $transcript", color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(top = 8.dp))
        }
        if (reply.isNotEmpty()) {
            Text("Omar: $reply", color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp))
        }
        if (speaking) {
            Text("🔊 speaking…", color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp))
        }
    }
}
