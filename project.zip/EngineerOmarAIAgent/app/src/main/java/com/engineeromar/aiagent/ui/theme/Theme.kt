package com.engineeromar.aiagent.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColors = darkColorScheme(
    primary = Gold,
    onPrimary = Obsidian,
    primaryContainer = Slate,
    onPrimaryContainer = GoldSoft,
    secondary = GoldSoft,
    onSecondary = Obsidian,
    background = Obsidian,
    onBackground = TextPrimary,
    surface = Onyx,
    onSurface = TextPrimary,
    surfaceVariant = Graphite,
    onSurfaceVariant = TextSecondary,
    outline = Outline,
    error = Danger,
    onError = Obsidian,
)

private val LightColors = lightColorScheme(
    primary = GoldDeep,
    onPrimary = Paper,
    primaryContainer = PaperAlt,
    onPrimaryContainer = Ink,
    background = Paper,
    onBackground = Ink,
    surface = Paper,
    onSurface = Ink,
    surfaceVariant = PaperAlt,
    onSurfaceVariant = TextMuted,
    outline = Outline,
    error = Danger,
    onError = Paper,
)

/** Exposes brand colors not covered by MD3 tokens (e.g. custom chart palette). */
data class ExtendedColors(
    val gold: androidx.compose.ui.graphics.Color = Gold,
    val success: androidx.compose.ui.graphics.Color = Success,
    val warning: androidx.compose.ui.graphics.Color = Warning,
    val danger: androidx.compose.ui.graphics.Color = Danger,
)
val LocalExtendedColors = staticCompositionLocalOf { ExtendedColors() }

@Composable
fun EngineerOmarTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as android.app.Activity).window
            window.statusBarColor = colors.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }
    CompositionLocalProvider(LocalExtendedColors provides ExtendedColors()) {
        MaterialTheme(colorScheme = colors, typography = Typography, content = content)
    }
}
