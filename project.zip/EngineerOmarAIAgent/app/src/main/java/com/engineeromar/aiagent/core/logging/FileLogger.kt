package com.engineeromar.aiagent.core.logging

import com.engineeromar.aiagent.core.storage.StorageDirectories
import timber.log.Timber
import java.io.File
import java.io.PrintWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Persistent, rotating file logger. Writes one file per day under the app's
 * private Logs/ directory, rotates automatically by date, and trims history
 * beyond [MAX_HISTORY_DAYS]. Exposed as a Timber tree so the whole app logs
 * through one API.
 *
 * NOTE: The Logs/ dir lives inside the encrypted app-private storage; for
 * further hardening it can be wrapped with EncryptedFile (see Security module).
 */
@Singleton
class FileLogger @Inject constructor(
    private val storage: StorageDirectories,
) {
    fun timberTree(): Timber.Tree = object : Timber.Tree() {
        override fun log(priority: Int, tag: String?, message: String, t: Throwable?) {
            try {
                val line = formatLine(priority, tag, message, t)
                currentLogFile().appendText("$line\n")
            } catch (_: Throwable) {
                // Logging must never crash the app.
            }
        }
    }

    /** Searchable access for the in-app Logs viewer. */
    fun readRecent(maxBytes: Int = 256 * 1024): String = runCatching {
        currentLogFile().readText()
            .takeLast(maxBytes)
    }.getOrDefault("")

    fun listLogFiles(): List<File> = storage.logsDir.listFiles { f -> f.extension == "log" }
        ?.sortedByDescending { it.lastModified() } ?: emptyList()

    private fun currentLogFile(): File {
        prune()
        return File(storage.logsDir, "${dateFormatter.format(Date())}.log").apply { createIfMissing() }
    }

    private fun prune() {
        runCatching {
            val cutoff = System.currentTimeMillis() - MAX_HISTORY_DAYS * 24L * 3_600_000L
            storage.logsDir.listFiles { f -> f.extension == "log" && f.lastModified() < cutoff }
                ?.forEach { it.delete() }
        }
    }

    private fun formatLine(p: Int, tag: String?, msg: String, t: Throwable?): String {
        val level = when (p) {
            android.util.Log.VERBOSE -> "V"
            android.util.Log.DEBUG -> "D"
            android.util.Log.INFO -> "I"
            android.util.Log.WARN -> "W"
            android.util.Log.ERROR -> "E"
            else -> "?"
        }
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
        val base = "$ts [$level] ${tag ?: "-"}: $msg"
        if (t == null) return base
        val sw = java.io.StringWriter()
        t.printStackTrace(PrintWriter(sw))
        return "$base\n$sw"
    }

    private fun File.createIfMissing() { if (!exists()) { parentFile?.mkdirs(); createNewFile() } }

    companion object {
        private const val MAX_HISTORY_DAYS = 14
        private val dateFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    }
}
