package com.engineeromar.aiagent

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.engineeromar.aiagent.core.error.GlobalErrorHandler
import com.engineeromar.aiagent.core.lifecycle.AppLifecycleObserver
import com.engineeromar.aiagent.core.logging.FileLogger
import com.engineeromar.aiagent.core.logging.Logger
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber
import javax.inject.Inject

/**
 * Application root.
 *
 * Owns: DI graph bootstrapping, global logging, crash handling, WorkManager
 * configuration, and app-lifecycle observation. Kept intentionally thin —
 * all behaviour is delegated to single-responsibility collaborators (SOLID).
 */
@HiltAndroidApp
class EngineerOmarApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var fileLogger: FileLogger
    @Inject lateinit var errorHandler: GlobalErrorHandler
    @Inject lateinit var lifecycleObserver: AppLifecycleObserver

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()

    override fun onCreate() {
        super.onCreate()

        initLogging()
        errorHandler.install()             // global crash + uncaught-exception capture
        registerActivityLifecycleCallbacks(lifecycleObserver)
        lifecycleObserver.register(this)   // ProcessLifecycleOwner wiring
    }

    private fun initLogging() {
        // Debug builds → verbose Timber logging tree.
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        // All builds → persistent, searchable, rotating file logs (encrypted at rest on disk).
        Timber.plant(fileLogger.timberTree())
        Logger.i("Application") { "Engineer Omar AI Agent started — v${BuildConfig.VERSION_NAME}" }
    }
}
