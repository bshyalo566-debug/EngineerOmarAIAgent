package com.engineeromar.aiagent.feature.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.engineeromar.aiagent.core.storage.StorageDirectories
import com.engineeromar.aiagent.domain.usecase.file.ReadFileUseCase
import com.engineeromar.aiagent.domain.usecase.file.WriteFileUseCase
import com.engineeromar.aiagent.feature.editor.autocomplete.AutocompleteSource
import com.engineeromar.aiagent.feature.editor.autocomplete.Completion
import com.engineeromar.aiagent.feature.editor.diagnostics.Diagnostic
import com.engineeromar.aiagent.feature.editor.diagnostics.DiagnosticsEngine
import com.engineeromar.aiagent.feature.editor.format.CodeFormatter
import com.engineeromar.aiagent.feature.editor.highlight.CodeLanguage
import com.engineeromar.aiagent.feature.editor.highlight.EditorTheme
import com.engineeromar.aiagent.feature.editor.highlight.EditorThemes
import com.engineeromar.aiagent.feature.editor.search.FindMatch
import com.engineeromar.aiagent.feature.editor.search.FindReplaceEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import java.io.File
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@HiltViewModel
class CodeEditorViewModel @Inject constructor(
    private val readFile: ReadFileUseCase,
    private val writeFile: WriteFileUseCase,
    private val storage: StorageDirectories,
) : ViewModel() {

    private val diagnosticsEngine = DiagnosticsEngine()
    private val formatter = CodeFormatter()
    private val autocomplete = AutocompleteSource()
    private val findReplace = FindReplaceEngine()

    private val _tabs = MutableStateFlow<List<EditorTab>>(emptyList())
    val tabs: StateFlow<List<EditorTab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow<String?>(null)
    val activeTabId: StateFlow<String?> = _activeTabId.asStateFlow()

    private val _diagnostics = MutableStateFlow<List<Diagnostic>>(emptyList())
    val diagnostics: StateFlow<List<Diagnostic>> = _diagnostics.asStateFlow()

    private val _findMatches = MutableStateFlow<List<FindMatch>>(emptyList())
    val findMatches: StateFlow<List<FindMatch>> = _findMatches.asStateFlow()

    private val _findQuery = MutableStateFlow("")
    val findQuery: StateFlow<String> = _findQuery.asStateFlow()

    private val _theme = MutableStateFlow(EditorThemes.OmarDark)
    val theme: StateFlow<EditorTheme> = _theme.asStateFlow()

    private val _isDark = MutableStateFlow(true)
    val isDark: StateFlow<Boolean> = _isDark.asStateFlow()

    /** Debounce handles so a new keystroke cancels the in-flight heavy pass. */
    private var diagnosticsJob: Job? = null
    private var findJob: Job? = null

    val activeTab: EditorTab? get() = _tabs.value.firstOrNull { it.id == _activeTabId.value }

    fun openFile(path: String) {
        viewModelScope.launch {
            val file = File(path)
            if (!file.exists() || !file.isFile) return@launch
            _tabs.value.firstOrNull { it.path == path }?.let {
                _activeTabId.value = it.id; return@launch
            }
            val content = readFile(path)
            val language = CodeLanguage.forExtension(file.extension)
            val tab = EditorTab(
                id = path, name = file.name, path = path, language = language,
                content = content, originalContent = content, isDirty = false,
            )
            _tabs.update { it + tab }
            _activeTabId.value = tab.id
            scheduleDiagnostics(tab, delayMs = 0)
        }
    }

    fun newFile(name: String = "Untitled.kt") {
        val tab = EditorTab(
            id = "new-${System.nanoTime()}", name = name, path = "",
            language = CodeLanguage.forExtension(File(name).extension),
            content = "", originalContent = "", isDirty = false,
        )
        _tabs.update { it + tab }
        _activeTabId.value = tab.id
    }

    fun selectTab(id: String) { _activeTabId.value = id }

    fun closeTab(id: String) {
        val remaining = _tabs.value.filterNot { it.id == id }
        _tabs.value = remaining
        if (_activeTabId.value == id) _activeTabId.value = remaining.firstOrNull()?.id
    }

    fun onContentChange(content: String) {
        val tab = activeTab ?: return
        val updated = tab.copy(content = content, isDirty = content != tab.originalContent)
        _tabs.update { tabs -> tabs.map { if (it.id == tab.id) updated else it } }
        scheduleDiagnostics(updated, delayMs = DEBOUNCE_MS)
        scheduleFind(content)
    }

    fun saveActive() {
        val tab = activeTab ?: return
        val path = tab.path.ifBlank { File(storage.projectsDir, tab.name).absolutePath }
        viewModelScope.launch {
            writeFile(path, tab.content)
            val saved = tab.copy(path = path, originalContent = tab.content, isDirty = false)
            _tabs.update { tabs -> tabs.map { if (it.id == saved.id) saved else it } }
        }
    }

    fun formatActive() {
        val tab = activeTab ?: return
        viewModelScope.launch {
            val formatted = withContext(Dispatchers.Default) {
                formatter.format(tab.content, tab.language)
            }
            onContentChange(formatted)
        }
    }

    fun setTheme(dark: Boolean) {
        _isDark.value = dark
        _theme.value = EditorThemes.forDark(dark)
    }

    fun setFindQuery(q: String) {
        _findQuery.value = q
        scheduleFind(activeTab?.content.orEmpty())
    }

    fun replaceAll(replacement: String) {
        val tab = activeTab ?: return
        val q = _findQuery.value
        if (q.isEmpty()) return
        val next = findReplace.replaceAll(
            tab.content, q, replacement, ignoreCase = true, wholeWord = false, regex = false,
        )
        onContentChange(next)
    }

    fun completionsFor(prefix: String): List<Completion> {
        if (prefix.isEmpty()) return emptyList()
        val tab = activeTab ?: return emptyList()
        val ids = extractIdentifiers(tab.content)
        return autocomplete.completionsFor(prefix, tab.language, ids)
    }

    /** Debounced, off-main-thread diagnostics so typing stays smooth. */
    private fun scheduleDiagnostics(tab: EditorTab, delayMs: Long) {
        diagnosticsJob?.cancel()
        diagnosticsJob = viewModelScope.launch(Dispatchers.Default) {
            if (delayMs > 0) delay(delayMs)
            _diagnostics.value = diagnosticsEngine.analyze(tab.content, tab.language)
        }
    }

    /** Debounced find so each keystroke does not re-scan large buffers on the UI. */
    private fun scheduleFind(content: String) {
        findJob?.cancel()
        findJob = viewModelScope.launch(Dispatchers.Default) {
            delay(FIND_DEBOUNCE_MS)
            val q = _findQuery.value
            _findMatches.value = if (q.isEmpty()) emptyList()
                else findReplace.find(content, q, ignoreCase = true)
        }
    }

    private fun extractIdentifiers(source: String): Set<String> {
        val out = LinkedHashSet<String>()
        Regex("[A-Za-z_$][A-Za-z0-9_$]{2,}").findAll(source).forEach { out.add(it.value) }
        return out
    }

    private companion object {
        const val DEBOUNCE_MS = 350L
        const val FIND_DEBOUNCE_MS = 200L
    }
}

data class EditorTab(
    val id: String,
    val name: String,
    val path: String,
    val language: CodeLanguage,
    val content: String,
    val originalContent: String,
    val isDirty: Boolean,
)
