package com.engineeromar.aiagent.ai.engine.executors

import android.content.Context
import com.engineeromar.aiagent.ai.engine.ExecutionPlan
import com.engineeromar.aiagent.ai.engine.ExecutionResult
import com.engineeromar.aiagent.ai.engine.Executor
import com.engineeromar.aiagent.ai.engine.IntentKey
import com.engineeromar.aiagent.core.automation.AndroidAutomation
import com.engineeromar.aiagent.domain.repository.FileRepository
import com.engineeromar.aiagent.domain.repository.GitRepository
import com.engineeromar.aiagent.domain.repository.KnowledgeRepository
import com.engineeromar.aiagent.domain.util.Result
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Automation + integration executors. Each handles exactly one intent id and
 * uses only official Android intents ([AndroidAutomation]) or domain
 * repository interfaces — never Impl classes, never root, never accessibility
 * input injection. Wired into the Command Engine via [ExecutorModule].
 */

class OpenUrlExecutor @Inject constructor(
    private val automation: AndroidAutomation,
) : Executor {
    override val handledIntent = com.engineeromar.aiagent.ai.engine.Intents.OPEN_URL
    override suspend fun execute(plan: ExecutionPlan): ExecutionResult {
        val url = plan.params["url"] ?: plan.steps.lastOrNull() ?: ""
        val ok = automation.openUrl(url)
        return ExecutionResult(ok, if (ok) "Opened $url" else "Failed to open URL")
    }
}

class OpenAppExecutor @Inject constructor(
    @ApplicationContext private val context: Context,
    private val automation: AndroidAutomation,
) : Executor {
    override val handledIntent = com.engineeromar.aiagent.ai.engine.Intents.OPEN_APP
    override suspend fun execute(plan: ExecutionPlan): ExecutionResult {
        val pkg = plan.params["package"] ?: ""
        if (pkg.isBlank()) return ExecutionResult(false, "No package specified")
        val installed = runCatching {
            context.packageManager.getPackageInfo(pkg, 0); true
        }.getOrDefault(false)
        if (!installed) return ExecutionResult(false, "$pkg is not installed")
        val ok = automation.openApp(pkg)
        return ExecutionResult(ok, if (ok) "Launched $pkg" else "Launch failed")
    }
}

class ShareExecutor @Inject constructor(
    private val automation: AndroidAutomation,
) : Executor {
    override val handledIntent = com.engineeromar.aiagent.ai.engine.Intents.SHARE
    override suspend fun execute(plan: ExecutionPlan): ExecutionResult {
        val text = plan.params["text"] ?: plan.steps.joinToString(" ")
        val ok = automation.shareText(text)
        return ExecutionResult(ok, if (ok) "Shared via system sheet" else "Share failed")
    }
}

class GitCommitExecutor @Inject constructor(
    private val git: GitRepository,
) : Executor {
    override val handledIntent = com.engineeromar.aiagent.ai.engine.Intents.GIT_COMMIT
    override suspend fun execute(plan: ExecutionPlan): ExecutionResult {
        val repo = plan.params["repo"] ?: return ExecutionResult(false, "No repository path")
        val message = plan.params["message"] ?: "Automated commit via Engineer Omar"
        return when (val add = git.add(repo, emptyList())) {
            is Result.Failure -> ExecutionResult(false, "Staging failed: ${add.error.message}")
            is Result.Success<*> -> when (val commit = git.commit(repo, message)) {
                is Result.Success -> ExecutionResult(true, "Committed ${commit.data.shortHash} — $message",
                    listOf(commit.data.hash))
                is Result.Failure -> ExecutionResult(false, commit.error.message)
            }
        }
    }
}

class GitPushExecutor @Inject constructor(
    private val git: GitRepository,
) : Executor {
    override val handledIntent = com.engineeromar.aiagent.ai.engine.Intents.GIT_PUSH
    override suspend fun execute(plan: ExecutionPlan): ExecutionResult {
        val repo = plan.params["repo"] ?: return ExecutionResult(false, "No repository path")
        return when (val r = git.push(repo)) {
            is Result.Success -> ExecutionResult(true, "Pushed to origin")
            is Result.Failure -> ExecutionResult(false, r.error.message)
        }
    }
}

class FileCreateExecutor @Inject constructor(
    private val files: FileRepository,
) : Executor {
    override val handledIntent = com.engineeromar.aiagent.ai.engine.Intents.FILE_CREATE
    override suspend fun execute(plan: ExecutionPlan): ExecutionResult {
        val path = plan.params["path"] ?: return ExecutionResult(false, "No file path")
        val content = plan.params["content"] ?: ""
        val res = files.writeText(path, content)
        return ExecutionResult(res.success, res.message, res.affected)
    }
}

class FileSearchExecutor @Inject constructor(
    private val files: FileRepository,
) : Executor {
    override val handledIntent = com.engineeromar.aiagent.ai.engine.Intents.FILE_SEARCH
    override suspend fun execute(plan: ExecutionPlan): ExecutionResult {
        val root = plan.params["root"] ?: ""
        val query = plan.params["query"] ?: ""
        val hits = files.search(root, query)
        return ExecutionResult(true, "${hits.size} files", hits.map { it.path })
    }
}

class KnowledgeSearchExecutor @Inject constructor(
    private val knowledge: KnowledgeRepository,
) : Executor {
    override val handledIntent = com.engineeromar.aiagent.ai.engine.Intents.KNOWLEDGE_SEARCH
    override suspend fun execute(plan: ExecutionPlan): ExecutionResult {
        val q = plan.params["query"] ?: plan.steps.firstOrNull() ?: ""
        val hits = knowledge.semanticSearch(q)
        return ExecutionResult(true, "${hits.size} matches", hits.map { it.title })
    }
}

/**
 * Wires every executor into the Command Engine via Dagger multibinding keyed
 * by intent id. Adding a capability = add one entry here; the engine and
 * registry stay untouched (Open/Closed).
 */
@Module
@InstallIn(SingletonComponent::class)
object ExecutorModule {

    @Provides @IntoMap @IntentKey("automation.open_url")
    @Singleton fun openUrl(e: OpenUrlExecutor): Executor = e

    @Provides @IntoMap @IntentKey("automation.open_app")
    @Singleton fun openApp(e: OpenAppExecutor): Executor = e

    @Provides @IntoMap @IntentKey("automation.share")
    @Singleton fun share(e: ShareExecutor): Executor = e

    @Provides @IntoMap @IntentKey("git.commit")
    @Singleton fun gitCommit(e: GitCommitExecutor): Executor = e

    @Provides @IntoMap @IntentKey("git.push")
    @Singleton fun gitPush(e: GitPushExecutor): Executor = e

    @Provides @IntoMap @IntentKey("file.create")
    @Singleton fun fileCreate(e: FileCreateExecutor): Executor = e

    @Provides @IntoMap @IntentKey("file.search")
    @Singleton fun fileSearch(e: FileSearchExecutor): Executor = e

    @Provides @IntoMap @IntentKey("knowledge.search")
    @Singleton fun knowledgeSearch(e: KnowledgeSearchExecutor): Executor = e

    @Provides @IntoMap @IntentKey("code.generate")
    @Singleton fun codeGenerate(e: CodeGenerationExecutor): Executor = e
}
