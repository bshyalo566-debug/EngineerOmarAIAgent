package com.engineeromar.aiagent.data.repository

import com.engineeromar.aiagent.core.logging.Logger
import com.engineeromar.aiagent.data.local.dao.FileItemDao
import com.engineeromar.aiagent.data.mapper.toDomain
import com.engineeromar.aiagent.data.mapper.toEntity
import com.engineeromar.aiagent.domain.model.FileItem
import com.engineeromar.aiagent.domain.model.FileOperationResult
import com.engineeromar.aiagent.domain.model.SortOrder
import com.engineeromar.aiagent.domain.repository.FileRepository
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/**
 * Filesystem-backed [FileRepository]. All disk I/O runs on [Dispatchers.IO].
 *
 * Uses java.nio.file for copy/move (atomic where supported) and java.util.zip
 * for archive operations — no third-party file libraries. Favorite / recent
 * metadata is persisted via [FileItemDao] so it survives rescans.
 */
@Singleton
class FileRepositoryImpl @Inject constructor(
    private val dao: FileItemDao,
) : FileRepository {

    override suspend fun list(directoryPath: String, sortOrder: SortOrder): List<FileItem> =
        withContext(Dispatchers.IO) {
            val dir = File(directoryPath)
            if (!dir.exists() || !dir.isDirectory) return@withContext emptyList()
            val children = dir.listFiles()?.map { it.toDomain() } ?: emptyList()
            children.sortedWith(comparator(sortOrder))
        }

    override suspend fun readText(path: String, maxBytes: Int): String = withContext(Dispatchers.IO) {
        val file = File(path)
        if (!file.exists() || !file.isFile) return@withContext ""
        if (file.length() > maxBytes) {
            file.bufferedReader().use { it.readText().substring(0, maxBytes) }
        } else {
            file.readText()
        }
    }

    override suspend fun writeText(path: String, content: String): FileOperationResult =
        withContext(Dispatchers.IO) {
            runCatching {
                File(path).apply { parentFile?.mkdirs() }.writeText(content)
                touchRecent(path)
            }.toResult(path)
        }

    override suspend fun createDirectory(path: String): FileOperationResult = withContext(Dispatchers.IO) {
        runCatching { File(path).mkdirs() }.toResult(path)
    }

    override suspend fun rename(from: String, toName: String): FileOperationResult =
        withContext(Dispatchers.IO) {
            val src = File(from)
            val dest = File(src.parentFile, toName)
            runCatching { src.renameTo(dest) }.toResult(listOf(from, dest.absolutePath))
        }

    override suspend fun copy(from: String, to: String): FileOperationResult = withContext(Dispatchers.IO) {
        runCatching {
            val src = File(from); val dest = File(to)
            if (src.isDirectory) copyTree(src, dest) else Files.copy(src.toPath(), dest.toPath())
        }.toResult(listOf(from, to))
    }

    override suspend fun move(from: String, to: String): FileOperationResult = withContext(Dispatchers.IO) {
        runCatching {
            val src = File(from); val dest = File(to)
            Files.move(src.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }.toResult(listOf(from, to))
    }

    override suspend fun delete(path: String): FileOperationResult = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(path)
            if (file.isDirectory) file.deleteRecursively() else file.delete()
            dao.deleteByPath(path)
        }.toResult(path)
    }

    override suspend fun compress(paths: List<String>, destinationZip: String): FileOperationResult =
        withContext(Dispatchers.IO) {
            runCatching {
                val out = File(destinationZip).apply { parentFile?.mkdirs() }
                ZipOutputStream(FileOutputStream(out)).use { zos ->
                    paths.forEach { p ->
                        val file = File(p)
                        if (file.isDirectory) addDirToZip(file, file.parentFile?.absolutePath ?: "", zos)
                        else addFileToZip(file, "", zos)
                    }
                }
            }.toResult(destinationZip)
        }

    override suspend fun extract(zipPath: String, destinationDir: String): FileOperationResult =
        withContext(Dispatchers.IO) {
            runCatching {
                val dest = File(destinationDir).apply { mkdirs() }
                ZipInputStream(FileInputStream(zipPath)).use { zis ->
                    var entry: ZipEntry? = zis.nextEntry
                    while (entry != null) {
                        val target = File(dest, entry.name)
                        // Guard against zip-slip path traversal.
                        if (!target.canonicalPath.startsWith(dest.canonicalPath + File.separator) &&
                            target.canonicalPath != dest.canonicalPath) {
                            throw SecurityException("Zip entry escapes target dir: ${entry.name}")
                        }
                        if (entry.isDirectory) target.mkdirs() else {
                            target.parentFile?.mkdirs()
                            FileOutputStream(target).use { zis.copyTo(it) }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }.toResult(destinationDir)
        }

    override suspend fun search(root: String, query: String, maxResults: Int): List<FileItem> =
        withContext(Dispatchers.IO) {
            val q = query.trim().lowercase()
            if (q.isEmpty()) return@withContext emptyList()
            val results = ArrayList<FileItem>()
            walk(File(root)) { file ->
                if (results.size >= maxResults) return@walk
                if (file.name.lowercase().contains(q)) {
                    results.add(file.toDomain())
                }
            }
            results
        }

    override fun observeFavorites(): Flow<List<FileItem>> =
        dao.observeFavorites().map { rows -> rows.map { it.toDomain() } }

    override fun observeRecent(limit: Int): Flow<List<FileItem>> =
        dao.observeRecent().map { rows -> rows.map { it.toDomain() } }

    override suspend fun toggleFavorite(path: String): FileOperationResult = withContext(Dispatchers.IO) {
        runCatching {
            val existing = dao.search(path).firstOrNull()
            if (existing == null) {
                dao.upsert(File(path).toDomain(favorite = true).toEntity())
            } else {
                dao.setFavorite(existing.id, !existing.isFavorite)
            }
        }.toResult(path)
    }

    override suspend fun touchRecent(path: String): FileOperationResult = withContext(Dispatchers.IO) {
        runCatching {
            val item = File(path).toDomain(lastOpenedAt = java.util.Date())
            dao.upsert(item.toEntity())
            dao.touch(item.path, System.currentTimeMillis())
        }.toResult(path)
    }

    // ── helpers ──────────────────────────────────────────────────────────

    private fun comparator(order: SortOrder): Comparator<FileItem> = when (order) {
        SortOrder.NAME_ASC -> compareBy({ !it.isDirectory }, { it.name.lowercase() })
        SortOrder.NAME_DESC -> compareByDescending<FileItem> { it.isDirectory }
            .thenByDescending { it.name.lowercase() }
        SortOrder.SIZE_ASC -> compareBy({ !it.isDirectory }, { it.sizeBytes })
        SortOrder.SIZE_DESC -> compareBy({ !it.isDirectory }, { -it.sizeBytes })
        SortOrder.MODIFIED_ASC -> compareBy({ !it.isDirectory }, { it.lastModified })
        SortOrder.MODIFIED_DESC -> compareBy({ !it.isDirectory }, { -it.lastModified.time })
    }

    private fun copyTree(src: File, dest: File) {
        if (src.isDirectory) {
            dest.mkdirs()
            src.listFiles()?.forEach { child -> copyTree(child, File(dest, child.name)) }
        } else {
            Files.copy(src.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }

    private fun addDirToZip(folder: File, base: String, zos: ZipOutputStream) {
        val files = folder.listFiles() ?: return
        for (file in files) {
            if (file.isDirectory) {
                addDirToZip(file, base, zos)
            } else {
                addFileToZip(file, base, zos)
            }
        }
    }

    private fun addFileToZip(file: File, base: String, zos: ZipOutputStream) {
        val entryName = if (base.isEmpty()) file.name else File(file.absolutePath).relativeTo(File(base)).path
        zos.putNextEntry(ZipEntry(entryName.replace(File.separatorChar, '/')))
        FileInputStream(file).use { it.copyTo(zos) }
        zos.closeEntry()
    }

    private fun walk(root: File, visit: (File) -> Unit) {
        if (!root.exists()) return
        if (root.isFile) { visit(root); return }
        root.listFiles()?.forEach { child ->
            visit(child)
            if (child.isDirectory && !child.name.startsWith(".")) walk(child, visit)
        }
    }

    private fun <T> kotlin.Result<T>.toOperationResult(affected: List<String>): FileOperationResult =
        if (isSuccess) FileOperationResult(true, "OK", affected)
        else FileOperationResult(false, exceptionOrNull()?.message ?: "File operation failed", affected)

    /** Convenience overload for a single affected path. */
    private fun <T> kotlin.Result<T>.toResult(affected: Any): FileOperationResult {
        val paths = (affected as? List<*>)?.map { it.toString() } ?: listOf(affected.toString())
        return toOperationResult(paths)
    }
}
