package com.engineeromar.aiagent.feature.github

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.engineeromar.aiagent.domain.model.CreateRepositoryInput
import com.engineeromar.aiagent.domain.model.GitHubRepository
import com.engineeromar.aiagent.domain.model.GitHubUser
import com.engineeromar.aiagent.domain.usecase.github.CreateRepoUseCase
import com.engineeromar.aiagent.domain.usecase.github.GetCurrentUserUseCase
import com.engineeromar.aiagent.domain.usecase.github.ListReposUseCase
import com.engineeromar.aiagent.domain.usecase.github.ValidateGitHubTokenUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class GitHubViewModel @Inject constructor(
    private val getCurrentUser: GetCurrentUserUseCase,
    private val listRepos: ListReposUseCase,
    private val createRepo: CreateRepoUseCase,
    private val validateToken: ValidateGitHubTokenUseCase,
) : ViewModel() {

    private val _user = MutableStateFlow<GitHubUser?>(null)
    val user: StateFlow<GitHubUser?> = _user.asStateFlow()

    private val _repos = MutableStateFlow<List<GitHubRepository>>(emptyList())
    val repos: StateFlow<List<GitHubRepository>> = _repos.asStateFlow()

    private val _tokenValid = MutableStateFlow<Boolean?>(null)
    val tokenValid: StateFlow<Boolean?> = _tokenValid.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun checkToken() = viewModelScope.launch {
        _busy.value = true
        when (val r = validateToken()) {
            is com.engineeromar.aiagent.domain.util.Result.Success -> _tokenValid.value = r.data
            is com.engineeromar.aiagent.domain.util.Result.Failure -> {
                _tokenValid.value = false; _message.value = r.error.message
            }
        }
        _busy.value = false
    }

    fun loadProfile() = viewModelScope.launch {
        _busy.value = true
        when (val r = getCurrentUser()) {
            is com.engineeromar.aiagent.domain.util.Result.Success -> {
                _user.value = r.data; loadRepos(1)
            }
            is com.engineeromar.aiagent.domain.util.Result.Failure -> _message.value = r.error.message
        }
        _busy.value = false
    }

    fun loadRepos(page: Int) = viewModelScope.launch {
        when (val r = listRepos(page)) {
            is com.engineeromar.aiagent.domain.util.Result.Success -> _repos.value = r.data
            is com.engineeromar.aiagent.domain.util.Result.Failure -> _message.value = r.error.message
        }
    }

    fun create(name: String, description: String, isPrivate: Boolean) = viewModelScope.launch {
        _busy.value = true
        when (val r = createRepo(CreateRepositoryInput(name, description.ifBlank { null }, isPrivate))) {
            is com.engineeromar.aiagent.domain.util.Result.Success -> {
                _message.value = "Created ${r.data.fullName}"; loadRepos(1)
            }
            is com.engineeromar.aiagent.domain.util.Result.Failure -> _message.value = r.error.message
        }
        _busy.value = false
    }
}
