package com.engineeromar.aiagent.core.error

/**
 * Domain-level, type-safe error hierarchy. The entire app maps failures into
 * [AppError] so the UI never deals with raw exceptions and can render
 * consistent, localized, actionable messages.
 *
 * Following the Either/Result pattern — see [com.engineeromar.aiagent.domain.util.Result].
 */
sealed class AppError(open val message: String, open val cause: Throwable? = null) {
    data class Network(override val message: String, override val cause: Throwable? = null) : AppError(message, cause)
    data class Database(override val message: String, override val cause: Throwable? = null) : AppError(message, cause)
    data class Storage(override val message: String, override val cause: Throwable? = null) : AppError(message, cause)
    data class AiProvider(override val message: String, val code: String? = null, override val cause: Throwable? = null) : AppError(message, cause)
    data class Permission(val permissions: List<String>, override val message: String) : AppError(message)
    data class Validation(val field: String, override val message: String) : AppError(message)
    data class Security(override val message: String, override val cause: Throwable? = null) : AppError(message, cause)
    data class Unknown(override val message: String = "Unexpected error", override val cause: Throwable? = null) : AppError(message, cause)
}

/** Convenience mapper for `try { } catch (e) { e.toAppError() }`. */
fun Throwable.toAppError(): AppError = when (this) {
    is AppError -> this
    is java.net.UnknownHostException,
    is java.io.IOException,
    is java.net.SocketTimeoutException -> AppError.Network("Network unavailable", this)
    is android.database.sqlite.SQLiteException -> AppError.Database("Local database error", this)
    is SecurityException -> AppError.Security("Security policy violation", this)
    else -> AppError.Unknown(message ?: "Unexpected error", this)
}
