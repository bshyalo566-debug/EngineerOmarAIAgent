package com.engineeromar.aiagent.core.update

import com.engineeromar.aiagent.BuildConfig
import com.engineeromar.aiagent.core.logging.Logger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * In-app update coordinator. In production wires to Play In-App Updates /
 * a self-hosted manifest. Kept as a thin façade here so the UI never depends
 * on a specific update channel.
 */
@Singleton
class UpdateManager @Inject constructor() {

    private val _state = MutableStateFlow(UpdateState(currentVersion = BuildConfig.VERSION_NAME))
    val state: StateFlow<UpdateState> = _state

    suspend fun checkForUpdate() {
        Logger.i("Update") { "Checking for updates (v${BuildConfig.VERSION_NAME})" }
        // Implementation: fetch manifest, compare semver, set _state.value.
    }
}

data class UpdateState(
    val currentVersion: String,
    val latestVersion: String? = null,
    val updateAvailable: Boolean = false,
    val changelog: String? = null,
    val mandatory: Boolean = false,
)
