package com.engineeromar.aiagent.ui.floating

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.engineeromar.aiagent.ai.agent.EngineeringAgent
import com.engineeromar.aiagent.core.automation.AndroidAutomation
import com.engineeromar.aiagent.core.voice.TextToSpeechEngine
import com.engineeromar.aiagent.domain.model.ConversationScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Backs the floating assistant overlay panel. Holds a compact conversation,
 * exposes quick actions, and speaks replies via TTS when enabled.
 *
 * The same [EngineeringAgent] used by the full-screen chat is reused here so
 * the floating bubble shares memory, provider, and command-engine state with
 * the rest of the app — one agent, multiple surfaces.
 */
@HiltViewModel
class FloatingAssistantViewModel @Inject constructor(
    private val agent: EngineeringAgent,
    private val tts: TextToSpeechEngine,
    private val automation: AndroidAutomation,
) : ViewModel() {

    data class Line(val text: String, val fromUser: Boolean)

    private val _lines = MutableStateFlow<List<Line>>(emptyList())
    val lines: StateFlow<List<Line>> = _lines.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _speakReplies = MutableStateFlow(true)
    val speakReplies: StateFlow<Boolean> = _speakReplies.asStateFlow()

    fun setSpeakReplies(enabled: Boolean) { _speakReplies.value = enabled }

    /** Quick actions surfaced as chips above the input. */
    val quickActions: List<QuickAction> = QuickAction.defaults

    fun send(text: String) {
        if (text.isBlank() || _busy.value) return
        _lines.value = _lines.value + Line(text, fromUser = true)
        _busy.value = true
        viewModelScope.launch {
            val reply = agent.ask(
                history = emptyList(),
                userInput = text,
                scope = ConversationScope.GENERAL,
            )
            _lines.value = _lines.value + Line(reply, fromUser = false)
            _busy.value = false
            if (_speakReplies.value) {
                tts.speak(reply)
            }
        }
    }

    fun runCommand(request: String) = viewModelScope.launch {
        _busy.value = true
        val report = agent.run(request)
        _lines.value = _lines.value + Line(
            text = "⚡ ${report.intent}: ${report.message ?: "done"}",
            fromUser = false,
        )
        _busy.value = false
    }

    fun shareLastReply() {
        _lines.value.lastOrNull { !it.fromUser }?.let { automation.shareText(it.text) }
    }

    fun clear() { _lines.value = emptyList() }
}

/** One-tap command shortcuts shown in the floating panel. */
data class QuickAction(val label: String, val request: String) {
    companion object {
        val defaults = listOf(
            QuickAction("Explain", "explain the selected code"),
            QuickAction("Review", "review my code"),
            QuickAction("Commit", "commit my changes"),
            QuickAction("Format", "format my code"),
        )
    }
}
