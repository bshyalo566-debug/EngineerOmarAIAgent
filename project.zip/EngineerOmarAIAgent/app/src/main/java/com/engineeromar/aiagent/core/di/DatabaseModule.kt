package com.engineeromar.aiagent.core.di

import android.content.Context
import androidx.room.Room
import com.engineeromar.aiagent.data.local.dao.CommandLogDao
import com.engineeromar.aiagent.data.local.dao.ConversationDao
import com.engineeromar.aiagent.data.local.dao.FileItemDao
import com.engineeromar.aiagent.data.local.dao.KnowledgeDao
import com.engineeromar.aiagent.data.local.dao.KnowledgeFtsDao
import com.engineeromar.aiagent.data.local.dao.MemoryDao
import com.engineeromar.aiagent.data.local.dao.MessageDao
import com.engineeromar.aiagent.data.local.dao.ProjectDao
import com.engineeromar.aiagent.data.local.db.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, AppDatabase.NAME)
            .fallbackToDestructiveMigrationOnDowngrade()
            .build()

    @Provides fun projectDao(db: AppDatabase): ProjectDao = db.projectDao()
    @Provides fun conversationDao(db: AppDatabase): ConversationDao = db.conversationDao()
    @Provides fun messageDao(db: AppDatabase): MessageDao = db.messageDao()
    @Provides fun knowledgeDao(db: AppDatabase): KnowledgeDao = db.knowledgeDao()
    @Provides fun knowledgeFtsDao(db: AppDatabase): KnowledgeFtsDao = db.knowledgeFtsDao()
    @Provides fun commandLogDao(db: AppDatabase): CommandLogDao = db.commandLogDao()
    @Provides fun memoryDao(db: AppDatabase): MemoryDao = db.memoryDao()
    @Provides fun fileItemDao(db: AppDatabase): FileItemDao = db.fileItemDao()
}
