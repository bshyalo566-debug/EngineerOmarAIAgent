package com.engineeromar.aiagent.domain.model

data class Memory(
    val id: String,
    val scope: MemoryScope,
    val category: MemoryCategory,
    val content: String,
    val importance: Int,
    val createdAt: Long,
    val lastAccessedAt: Long,
    val accessCount: Int,
)

data class MemoryScope(val raw: String) {
    companion object {
        val GLOBAL = MemoryScope("global")
        val USER = MemoryScope("user")
        fun project(id: String) = MemoryScope("project:$id")
    }
}

enum class MemoryCategory { PREFERENCE, FACT, PATTERN, COMMAND, CONTEXT }
