package com.engineeromar.aiagent.core.config

/** Immutable snapshot of user-tunable app configuration. */
data class AppConfig(
    val language: Language = Language.ENGLISH,
    val theme: ThemeMode = ThemeMode.DARK,
    val dynamicColor: Boolean = false,
    val aiProvider: AiProviderType = AiProviderType.OPENAI,
    val biometricLock: Boolean = false,
    val pinEnabled: Boolean = false,
    val performanceMode: PerformanceMode = PerformanceMode.BALANCED,
    val appVersion: String = "1.0.0",
)

enum class Language(val code: String, val display: String) {
    ENGLISH("en", "English"),
    ARABIC("ar", "العربية"),
}

enum class ThemeMode { LIGHT, DARK, SYSTEM }

enum class AiProviderType { OPENAI, ANTHROPIC, GEMINI, LOCAL }

/** Tunes background work, search indexing depth, and UI animation budget. */
enum class PerformanceMode { POWER_SAVER, BALANCED, MAX_PERFORMANCE }
