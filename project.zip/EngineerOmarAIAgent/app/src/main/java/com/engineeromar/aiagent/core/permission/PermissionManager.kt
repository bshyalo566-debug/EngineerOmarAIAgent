package com.engineeromar.aiagent.core.permission

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.engineeromar.aiagent.core.error.AppError
import com.engineeromar.aiagent.domain.util.Result
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single gatekeeper for all runtime + special permissions.
 * The Command Engine consults this before executing any privileged action.
 *
 * Design: every capability declares the permissions it needs and requests
 * them lazily, in context, never upfront — Privacy by Design.
 */
@Singleton
class PermissionManager @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    fun isGranted(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun allGranted(permissions: Collection<String>): Boolean = permissions.all { isGranted(it) }

    /** Overlays (SYSTEM_ALERT_WINDOW) cannot be requested like normal perms. */
    fun canDrawOverlays(): Boolean = Settings.canDrawOverlays(context)
    fun overlaySettingsUri(): Uri = Uri.parse("package:${context.packageName}").let {
        Uri.parse("android.settings.APPLICATION_DETAILS_SETTINGS").buildUpon().appendQueryParameter("package", context.packageName).build()
    }

    /**
     * Validates a capability's required permissions; returns [Result.Failure]
     * with [AppError.Permission] listing missing perms — never throws.
     */
    fun validate(required: List<String>): Result<Unit> =
        required.filterNot { isGranted(it) }.let { missing ->
            if (missing.isEmpty()) Result.Success(Unit)
            else Result.Failure(AppError.Permission(missing, "Missing permissions: ${missing.joinToString()}"))
        }

    companion object {
        val VOICE = listOf(Manifest.permission.RECORD_AUDIO)
        val MEDIA = listOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO,
        )
        val NOTIFICATION = listOf(Manifest.permission.POST_NOTIFICATIONS)
    }
}
