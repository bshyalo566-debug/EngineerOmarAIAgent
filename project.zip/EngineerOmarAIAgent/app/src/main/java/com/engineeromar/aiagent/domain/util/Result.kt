package com.engineeromar.aiagent.domain.util

import com.engineeromar.aiagent.core.error.AppError

/**
 * Railway-oriented Result type. Domain + data layers return [Result]; the
 * UI maps [Failure] to user-facing messages via [AppError]. Keeps error
 * handling explicit, type-safe, and testable — no exception-driven control
 * flow. Throwables are mapped to [AppError] via [com.engineeromar.aiagent.core.error.toAppError].
 */
sealed interface Result<out T> {
    data class Success<T>(val data: T) : Result<T>
    data class Failure(val error: AppError) : Result<Nothing>

    fun isSuccess(): Boolean = this is Success
    fun isFailure(): Boolean = this is Failure
    fun getOrNull(): T? = (this as? Success)?.data
    fun errorOrNull(): AppError? = (this as? Failure)?.error

    inline fun <R> map(transform: (T) -> R): Result<R> = when (this) {
        is Success -> Success(transform(data))
        is Failure -> this
    }

    inline fun <R> flatMap(transform: (T) -> Result<R>): Result<R> = when (this) {
        is Success -> transform(data)
        is Failure -> this
    }
}
