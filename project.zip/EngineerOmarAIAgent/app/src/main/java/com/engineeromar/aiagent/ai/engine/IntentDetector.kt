package com.engineeromar.aiagent.ai.engine

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Lightweight, deterministic intent detection. Rule-based first (fast, offline,
 * zero-token), with an optional AI escalation path. Rules are the source of
 * truth for stable commands; fuzzy intent can defer to the AI agent.
 */
@Singleton
class IntentDetector @Inject constructor() {

    private val rules: List<Pair<Regex, Intent>> = listOf(
        "commit|save changes".toRegex(RegexOption.IGNORE_CASE) to Intents.GIT_COMMIT,
        "push|upload to (github|remote)".toRegex(RegexOption.IGNORE_CASE) to Intents.GIT_PUSH,
        "create (a )?(file|class|function|component)".toRegex(RegexOption.IGNORE_CASE) to Intents.FILE_CREATE,
        "search files?".toRegex(RegexOption.IGNORE_CASE) to Intents.FILE_SEARCH,
        "(explain|what does) .* (do|mean)".toRegex(RegexOption.IGNORE_CASE) to Intents.EXPLAIN_CODE,
        "review (my )?(code|pr|pull request)".toRegex(RegexOption.IGNORE_CASE) to Intents.REVIEW_CODE,
        "refactor".toRegex(RegexOption.IGNORE_CASE) to Intents.REFACTOR_CODE,
        "(generate|write|create) (a )?code|write (a |an )?(function|class|api|screen)".toRegex(RegexOption.IGNORE_CASE) to Intents.GENERATE_CODE,
        "search (the )?(knowledge|docs?|book)".toRegex(RegexOption.IGNORE_CASE) to Intents.KNOWLEDGE_SEARCH,
        "open (the )?url|go to http".toRegex(RegexOption.IGNORE_CASE) to Intents.OPEN_URL,
        "open .* app|launch .* app".toRegex(RegexOption.IGNORE_CASE) to Intents.OPEN_APP,
        "share".toRegex(RegexOption.IGNORE_CASE) to Intents.SHARE,
        "search (the )?web|google".toRegex(RegexOption.IGNORE_CASE) to Intents.SEARCH_WEB,
    )

    fun detect(request: String): Intent =
        rules.firstOrNull { (pattern, _) -> pattern.containsMatchIn(request) }?.second
            ?: Intents.ANSWER_QUESTION
}
