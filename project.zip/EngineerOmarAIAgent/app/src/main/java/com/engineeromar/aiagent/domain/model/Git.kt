package com.engineeromar.aiagent.domain.model

import java.util.Date

/**
 * Domain models for the Git engine. These mirror the subset of Git concepts
 * the UI surfaces; the data layer translates between JGit's object graph and
 * these immutable types so the domain stays JGit-free and testable.
 */

data class GitRepository(
    val rootPath: String,
    val branch: String,
    val remoteUrl: String?,
    val isClean: Boolean,
    val aheadCount: Int,
    val behindCount: Int,
    val uncommittedChanges: Int,
)

data class GitBranch(
    val name: String,
    val isCurrent: Boolean,
    val isRemote: Boolean,
    val trackingBranch: String?,
    val lastCommitSummary: String,
    val lastCommitDate: Date,
)

data class GitCommit(
    val hash: String,
    val shortHash: String,
    val author: String,
    val authorEmail: String,
    val date: Date,
    val message: String,
    val parents: List<String>,
)

data class GitDiffEntry(
    val path: String,
    val changeType: ChangeType,
    val insertions: Int,
    val deletions: Int,
)

enum class ChangeType { ADDED, MODIFIED, DELETED, RENAMED, COPIED, UNTRACKED }

data class GitStatus(
    val staged: List<GitDiffEntry>,
    val unstaged: List<GitDiffEntry>,
    val untracked: List<String>,
    val branch: String,
    val isClean: Boolean,
)

data class GitCloneResult(
    val success: Boolean,
    val targetPath: String,
    val commitCount: Int,
    val message: String,
)
