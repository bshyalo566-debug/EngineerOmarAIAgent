package com.engineeromar.aiagent.feature.filemanager

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.engineeromar.aiagent.domain.model.FileItem

@Composable
fun FileManagerScreen(vm: FileManagerViewModel = hiltViewModel()) {
    val current by vm.current.collectAsStateWithLifecycle()
    val items by vm.items.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    val list = if (query.isBlank()) items else results

    var showNewFolder by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<FileItem?>(null) }

    Column(Modifier.fillMaxSize().padding(8.dp)) {
        // Toolbar
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::up) { Icon(Icons.Outlined.ArrowBack, "Up") }
            Text(
                java.io.File(current).name.ifBlank { "Storage" },
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = { showNewFolder = true }) { Icon(Icons.Outlined.CreateNewFolder, "New folder") }
        }
        // Breadcrumb
        Text(
            current,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontFamily = FontFamily.Monospace,
            maxLines = 1,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
        )
        // Search
        OutlinedTextField(
            value = query, onValueChange = vm::onQueryChange,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            placeholder = { Text("Search this folder…") },
            leadingIcon = { Icon(Icons.Outlined.Search, null) },
            singleLine = true,
        )
        // List
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            items(list, key = { it.path }) { item ->
                FileRow(
                    item = item,
                    onClick = {
                        if (item.isDirectory) vm.navigateTo(item.path)
                    },
                    onRename = { renameTarget = item },
                    onDelete = { vm.delete(item) },
                    onFavorite = { vm.toggleFavorite(item) },
                )
            }
        }
    }

    if (showNewFolder) {
        PromptDialog(
            title = "New folder",
            confirm = "Create",
            onConfirm = { name -> if (name.isNotBlank()) vm.createDirectory(name); showNewFolder = false },
            onDismiss = { showNewFolder = false },
        )
    }
    renameTarget?.let { item ->
        PromptDialog(
            title = "Rename ${item.name}",
            initial = item.name,
            confirm = "Rename",
            onConfirm = { name -> if (name.isNotBlank()) vm.rename(item, name); renameTarget = null },
            onDismiss = { renameTarget = null },
        )
    }
}

@Composable
private fun FileRow(
    item: FileItem,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onFavorite: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(36.dp).clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (item.isDirectory) Icons.Outlined.Folder else Icons.Outlined.InsertDriveFile,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
            )
        }
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, color = MaterialTheme.colorScheme.onBackground, fontSize = 14.sp)
            Text(
                "${item.formattedSize}${if (item.isDirectory) "" else " · ${item.extension.uppercase()}"}",
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp,
            )
        }
        IconButton(onClick = onFavorite) {
            Icon(
                if (item.isFavorite) Icons.Outlined.Star else Icons.Outlined.StarBorder,
                "Favorite", tint = MaterialTheme.colorScheme.primary,
            )
        }
        IconButton(onClick = onRename) { Icon(Icons.Outlined.CreateNewFolder, "Rename") }
        IconButton(onClick = onDelete) { Icon(Icons.Outlined.Delete, "Delete") }
    }
}

@Composable
private fun PromptDialog(
    title: String,
    initial: String = "",
    confirm: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            TextField(value = text, onValueChange = { text = it }, singleLine = true)
        },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
