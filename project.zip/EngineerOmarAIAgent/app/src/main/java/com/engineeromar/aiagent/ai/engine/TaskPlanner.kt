package com.engineeromar.aiagent.ai.engine

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Translates an [Intent] + raw request into a concrete, ordered [ExecutionPlan].
 * For trivial intents the plan is deterministic; for complex ones it defers
 * to the AI agent to decompose the task (pluggable).
 */
@Singleton
class TaskPlanner @Inject constructor() {

    fun plan(intent: Intent, request: String): ExecutionPlan = when (intent) {
        Intents.GENERATE_CODE -> ExecutionPlan(
            intent,
            steps = listOf(
                "Parse target language/file from request",
                "Draft module structure",
                "Generate code with error handling",
                "Return code + target path",
            ),
        )
        Intents.REVIEW_CODE -> ExecutionPlan(
            intent, listOf("Locate target files", "Run static checks", "Summarise issues + fixes")
        )
        Intents.GIT_COMMIT -> ExecutionPlan(
            intent, listOf("Detect repo root", "Stage changes", "Compose commit message", "git commit")
        )
        Intents.KNOWLEDGE_SEARCH -> ExecutionPlan(intent, listOf("Tokenise query", "Search index", "Rank results"))
        else -> ExecutionPlan(intent, listOf("Delegate to AI agent for: $request"))
    }
}
