package com.engineeromar.aiagent.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.engineeromar.aiagent.data.local.Converters
import com.engineeromar.aiagent.data.local.dao.CommandLogDao
import com.engineeromar.aiagent.data.local.dao.ConversationDao
import com.engineeromar.aiagent.data.local.dao.FileItemDao
import com.engineeromar.aiagent.data.local.dao.KnowledgeDao
import com.engineeromar.aiagent.data.local.dao.KnowledgeFtsDao
import com.engineeromar.aiagent.data.local.dao.MemoryDao
import com.engineeromar.aiagent.data.local.dao.MessageDao
import com.engineeromar.aiagent.data.local.dao.ProjectDao
import com.engineeromar.aiagent.data.local.entity.CommandLogEntity
import com.engineeromar.aiagent.data.local.entity.ConversationEntity
import com.engineeromar.aiagent.data.local.entity.FileItemEntity
import com.engineeromar.aiagent.data.local.entity.KnowledgeEntity
import com.engineeromar.aiagent.data.local.entity.KnowledgeFtsEntity
import com.engineeromar.aiagent.data.local.entity.MemoryEntity
import com.engineeromar.aiagent.data.local.entity.MessageEntity
import com.engineeromar.aiagent.data.local.entity.ProjectEntity

/**
 * Single offline-first Room database for the whole app.
 *
 * The DB file lives in app-private storage; for at-rest encryption wrap it
 * with SQLCipher in production (see Security module + docs). Schema is
 * exported to /schemas for migrations + documentation.
 *
 * Bump [VERSION] on every schema change and supply a Migration in DatabaseModule.
 */
@Database(
    entities = [
        ProjectEntity::class,
        ConversationEntity::class,
        MessageEntity::class,
        KnowledgeEntity::class,
        KnowledgeFtsEntity::class,
        CommandLogEntity::class,
        MemoryEntity::class,
        FileItemEntity::class,
    ],
    version = AppDatabase.VERSION,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun knowledgeDao(): KnowledgeDao
    abstract fun knowledgeFtsDao(): KnowledgeFtsDao
    abstract fun commandLogDao(): CommandLogDao
    abstract fun memoryDao(): MemoryDao
    abstract fun fileItemDao(): FileItemDao

    companion object {
        const val VERSION = 2
        const val NAME = "engineer_omar.db"
    }
}
