package com.engineeromar.aiagent.core.di

import com.engineeromar.aiagent.data.repository.FileRepositoryImpl
import com.engineeromar.aiagent.data.repository.GitHubRepositoryImpl
import com.engineeromar.aiagent.data.repository.GitRepositoryImpl
import com.engineeromar.aiagent.data.repository.KnowledgeRepositoryImpl
import com.engineeromar.aiagent.data.repository.ProjectRepositoryImpl
import com.engineeromar.aiagent.domain.repository.FileRepository
import com.engineeromar.aiagent.domain.repository.GitHubRepository
import com.engineeromar.aiagent.domain.repository.GitRepository
import com.engineeromar.aiagent.domain.repository.KnowledgeRepository
import com.engineeromar.aiagent.domain.repository.ProjectRepository
import com.engineeromar.aiagent.domain.search.SemanticIndex
import com.engineeromar.aiagent.domain.search.TfIdfIndex
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Binds repository interfaces to their implementations. Each `@Binds` is the
 * seam that lets feature/domain code depend on abstractions (Dependency
 * Inversion). Swap any impl (e.g. remote-backed repo) without touching callers.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds @Singleton
    abstract fun bindProjectRepository(impl: ProjectRepositoryImpl): ProjectRepository

    @Binds @Singleton
    abstract fun bindFileRepository(impl: FileRepositoryImpl): FileRepository

    @Binds @Singleton
    abstract fun bindGitRepository(impl: GitRepositoryImpl): GitRepository

    @Binds @Singleton
    abstract fun bindGitHubRepository(impl: GitHubRepositoryImpl): GitHubRepository

    @Binds @Singleton
    abstract fun bindKnowledgeRepository(impl: KnowledgeRepositoryImpl): KnowledgeRepository

    @Binds @Singleton
    abstract fun bindSemanticIndex(impl: TfIdfIndex): SemanticIndex
}
