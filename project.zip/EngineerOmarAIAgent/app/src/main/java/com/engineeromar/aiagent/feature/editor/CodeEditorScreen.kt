package com.engineeromar.aiagent.feature.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.FormatAlignLeft
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.engineeromar.aiagent.feature.editor.diagnostics.Diagnostic
import com.engineeromar.aiagent.feature.editor.diagnostics.Severity
import com.engineeromar.aiagent.feature.editor.highlight.CodeLanguage
import com.engineeromar.aiagent.feature.editor.highlight.EditorTheme
import com.engineeromar.aiagent.feature.editor.highlight.SyntaxHighlighter
import com.engineeromar.aiagent.feature.editor.highlight.TokenType

@Composable
fun CodeEditorScreen(vm: CodeEditorViewModel = hiltViewModel()) {
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeId by vm.activeTabId.collectAsStateWithLifecycle()
    val theme by vm.theme.collectAsStateWithLifecycle()
    val diagnostics by vm.diagnostics.collectAsStateWithLifecycle()
    val findMatches by vm.findMatches.collectAsStateWithLifecycle()
    val findQuery by vm.findQuery.collectAsStateWithLifecycle()
    val active = tabs.firstOrNull { it.id == activeId }

    Column(Modifier.fillMaxSize().background(theme.background)) {
        EditorToolbar(onNew = vm::newFile, onSave = vm::saveActive, onFormat = vm::formatActive)

        if (tabs.isNotEmpty()) {
            TabBar(tabs = tabs, activeId = activeId, theme = theme,
                onSelect = vm::selectTab, onClose = vm::closeTab)
        }

        if (findMatches.isNotEmpty() || findQuery.isNotEmpty()) {
            FindBar(query = findQuery, count = findMatches.size, theme = theme,
                onQuery = vm::setFindQuery, onReplace = vm::replaceAll)
        }

        when {
            active == null -> EmptyEditor(theme)
            else -> Row(Modifier.fillMaxSize().background(theme.background)) {
                EditorPane(
                    content = active.content,
                    language = active.language,
                    theme = theme,
                    onChange = vm::onContentChange,
                    modifier = Modifier.weight(1f),
                )
                Minimap(lineCount = active.content.count { it == '\n' } + 1,
                    theme = theme, modifier = Modifier.width(48.dp).fillMaxHeight())
            }
        }

        if (diagnostics.isNotEmpty()) {
            DiagnosticBar(diagnostics = diagnostics.take(3), theme = theme)
        }
    }
}

@Composable
private fun EditorToolbar(onNew: () -> Unit, onSave: () -> Unit, onFormat: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(44.dp)
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Editor", color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 8.dp))
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onNew) { Icon(Icons.Outlined.Add, contentDescription = "New file") }
        IconButton(onClick = onSave) { Icon(Icons.Outlined.Save, contentDescription = "Save") }
        IconButton(onClick = onFormat) { Icon(Icons.Outlined.FormatAlignLeft, contentDescription = "Format") }
    }
}

@Composable
private fun TabBar(
    tabs: List<EditorTab>, activeId: String?, theme: EditorTheme,
    onSelect: (String) -> Unit, onClose: (String) -> Unit,
) {
    LazyRow(
        Modifier.fillMaxWidth().height(36.dp).background(theme.background.copy(alpha = 0.6f)),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        items(tabs, key = { it.id }) { tab ->
            val isActive = tab.id == activeId
            val dirtyColor = theme.colorFor(TokenType.KEYWORD)
            Row(
                Modifier.height(36.dp)
                    .background(if (isActive) theme.background else theme.background.copy(alpha = 0.4f))
                    .clip(RoundedCornerShape(6.dp))
                    .clickable { onSelect(tab.id) }
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(6.dp).clip(RoundedCornerShape(3.dp))
                    .background(if (tab.isDirty) dirtyColor else Color.Transparent))
                Spacer(Modifier.width(6.dp))
                Text(tab.name, color = if (isActive) theme.foreground else theme.foreground.copy(alpha = 0.6f),
                    fontSize = 12.sp)
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Outlined.Close, contentDescription = "Close",
                    tint = theme.foreground.copy(alpha = 0.6f),
                    modifier = Modifier.size(14.dp).clickable { onClose(tab.id) })
            }
        }
    }
}

@Composable
private fun FindBar(
    query: String, count: Int, theme: EditorTheme,
    onQuery: (String) -> Unit, onReplace: (String) -> Unit,
) {
    var replacement by remember { mutableStateOf("") }
    Row(
        Modifier.fillMaxWidth().background(theme.background.copy(alpha = 0.7f)).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        OutlinedTextField(
            value = query, onValueChange = onQuery,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Find", color = theme.foreground.copy(alpha = 0.4f), fontSize = 13.sp) },
            singleLine = true,
            textStyle = TextStyle(color = theme.foreground, fontSize = 13.sp),
        )
        Spacer(Modifier.width(8.dp))
        Text("$count", color = theme.foreground.copy(alpha = 0.6f), fontSize = 12.sp)
        Spacer(Modifier.width(8.dp))
        OutlinedTextField(
            value = replacement, onValueChange = { replacement = it },
            modifier = Modifier.weight(1f),
            placeholder = { Text("Replace", color = theme.foreground.copy(alpha = 0.4f), fontSize = 13.sp) },
            singleLine = true,
            textStyle = TextStyle(color = theme.foreground, fontSize = 13.sp),
        )
        Spacer(Modifier.width(6.dp))
        IconButton(onClick = { onReplace(replacement) }) {
            Icon(Icons.Outlined.Save, contentDescription = "Replace all", tint = theme.foreground)
        }
    }
}

@Composable
private fun EditorPane(
    content: String,
    language: CodeLanguage,
    theme: EditorTheme,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val highlighter = remember { SyntaxHighlighter() }
    val transformation = remember(language, theme) {
        SyntaxHighlightTransformation(language, theme, highlighter)
    }
    val gutterState = rememberLazyListState()
    val fontSize = 13.sp
    val cursorColor = theme.colorFor(TokenType.KEYWORD)

    Row(modifier) {
        // Gutter — LazyColumn so 10k-line files don't compose every line number.
        androidx.compose.foundation.lazy.LazyColumn(
            state = gutterState,
            modifier = Modifier
                .width(42.dp)
                .fillMaxHeight()
                .background(theme.background.copy(alpha = 0.6f))
                .padding(top = 10.dp, end = 4.dp),
            horizontalAlignment = Alignment.End,
        ) {
            val lineCount = content.count { it == '\n' } + 1
            items(lineCount) { i ->
                Text("${i + 1}", color = theme.lineNumber, fontSize = 11.sp,
                    modifier = Modifier.padding(vertical = 1.dp))
            }
        }
        // Code area — a plain BasicTextField handles its own vertical scrolling
        // for multi-line editing. The VisualTransformation paints syntax colours.
        Box(
            Modifier.fillMaxSize().padding(8.dp),
        ) {
            BasicTextField(
                value = content,
                onValueChange = onChange,
                modifier = Modifier.fillMaxWidth(),
                textStyle = TextStyle(
                    color = theme.foreground, fontSize = fontSize, lineHeight = fontSize * 1.35f,
                ),
                cursorBrush = SolidColor(cursorColor),
                visualTransformation = transformation,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    capitalization = KeyboardCapitalization.None,
                    keyboardType = KeyboardType.Text,
                ),
                decorationBox = { innerTextField ->
                    if (content.isEmpty()) {
                        Text("// Start typing…", color = theme.foreground.copy(alpha = 0.3f),
                            fontSize = fontSize)
                    }
                    innerTextField()
                },
            )
        }
    }
}

/**
 * Lightweight minimap: renders one thin bar per line via a LazyColumn so even
 * huge files stay cheap (only visible bars compose). Density encodes length.
 */
@Composable
private fun Minimap(lineCount: Int, theme: EditorTheme, modifier: Modifier = Modifier) {
    androidx.compose.foundation.lazy.LazyColumn(
        modifier.background(theme.background.copy(alpha = 0.4f)).padding(2.dp),
    ) {
        items(minOf(lineCount, 400)) { idx ->
            // Alternating widths give a code-shape silhouette without parsing.
            val widthFraction = listOf(0.6f, 0.85f, 0.45f, 0.95f, 0.7f)[idx % 5]
            Box(
                Modifier
                    .fillMaxWidth(widthFraction)
                    .height(1.5.dp)
                    .padding(vertical = 0.5.dp)
                    .background(theme.foreground.copy(alpha = 0.18f))
            )
        }
    }
}

@Composable
private fun DiagnosticBar(diagnostics: List<Diagnostic>, theme: EditorTheme) {
    Row(
        Modifier.fillMaxWidth().background(theme.background.copy(alpha = 0.8f)).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        diagnostics.forEach { d ->
            val color = when (d.severity) {
                Severity.ERROR -> Color(0xFFFF6B6B)
                Severity.WARNING -> Color(0xFFFFB547)
                Severity.INFO -> Color(0xFF4DB6FF)
            }
            Text("● ${d.rule} L${d.line}", color = color, fontSize = 11.sp,
                modifier = Modifier.padding(end = 8.dp))
        }
    }
}

@Composable
private fun EmptyEditor(theme: EditorTheme) {
    Box(Modifier.fillMaxSize().background(theme.background), contentAlignment = Alignment.Center) {
        Text("Open a file from the Project Explorer",
            color = theme.foreground.copy(alpha = 0.4f))
    }
}
