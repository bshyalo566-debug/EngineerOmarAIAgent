package com.engineeromar.aiagent.domain.repository

import com.engineeromar.aiagent.domain.model.GitBranch
import com.engineeromar.aiagent.domain.model.GitCloneResult
import com.engineeromar.aiagent.domain.model.GitCommit
import com.engineeromar.aiagent.domain.model.GitDiffEntry
import com.engineeromar.aiagent.domain.model.GitRepository
import com.engineeromar.aiagent.domain.model.GitStatus

/**
 * Git engine contract. Operates on a working-directory path; remote
 * operations are authenticated via credentials supplied per call (the
 * implementation resolves them from SecureStorage + a credential callback).
 *
 * No method throws — every failure is a typed error in the Result wrapper.
 */
interface GitRepository {

    suspend fun init(repositoryPath: String): Result<String>
    suspend fun clone(remoteUrl: String, destinationDir: String): Result<GitCloneResult>
    suspend fun status(repositoryPath: String): Result<GitStatus>
    suspend fun add(repositoryPath: String, paths: List<String>): Result<Unit>
    suspend fun commit(repositoryPath: String, message: String, amend: Boolean = false): Result<GitCommit>
    suspend fun push(repositoryPath: String, remote: String = "origin"): Result<Unit>
    suspend fun pull(repositoryPath: String, remote: String = "origin"): Result<Unit>
    suspend fun fetch(repositoryPath: String, remote: String = "origin"): Result<Unit>
    suspend fun checkout(repositoryPath: String, ref: String, createBranch: Boolean = false): Result<Unit>
    suspend fun merge(repositoryPath: String, branch: String): Result<Unit>
    suspend fun branches(repositoryPath: String): Result<List<GitBranch>>
    suspend fun log(repositoryPath: String, limit: Int = 100): Result<List<GitCommit>>
    suspend fun diff(repositoryPath: String): Result<List<GitDiffEntry>>
    suspend fun summary(repositoryPath: String): Result<GitRepository>
}
