package com.engineeromar.aiagent.domain.model

data class KnowledgeDocument(
    val id: String,
    val title: String,
    val filePath: String,
    val fileType: KnowledgeFileType,
    val category: KnowledgeCategory,
    val sizeBytes: Long,
    val pageCount: Int,
    val createdAt: Long,
    val lastOpenedAt: Long?,
    val tags: List<String>,
)

enum class KnowledgeFileType(val ext: String) { PDF("pdf"), MARKDOWN("md"), TEXT("txt"), DOCX("docx") }
enum class KnowledgeCategory { BOOKS, API_DOCS, FRAMEWORK_DOCS, NOTES, GENERAL }
