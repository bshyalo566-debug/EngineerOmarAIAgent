package com.engineeromar.aiagent.data.remote.github

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Error body returned by GitHub (message + documentation_url). */
@Serializable
data class GitHubErrorDto(
    val message: String,
    @SerialName("documentation_url") val documentationUrl: String? = null,
)
