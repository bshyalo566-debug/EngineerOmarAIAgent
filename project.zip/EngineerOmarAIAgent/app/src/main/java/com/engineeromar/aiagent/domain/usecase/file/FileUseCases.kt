package com.engineeromar.aiagent.domain.usecase.file

import com.engineeromar.aiagent.domain.model.FileItem
import com.engineeromar.aiagent.domain.model.FileOperationResult
import com.engineeromar.aiagent.domain.model.SortOrder
import com.engineeromar.aiagent.domain.repository.FileRepository
import javax.inject.Inject

class ListDirectoryUseCase @Inject constructor(private val repo: FileRepository) {
    suspend operator fun invoke(path: String, sort: SortOrder = SortOrder.NAME_ASC): List<FileItem> =
        repo.list(path, sort)
}

class ReadFileUseCase @Inject constructor(private val repo: FileRepository) {
    suspend operator fun invoke(path: String): String = repo.readText(path)
}

class WriteFileUseCase @Inject constructor(private val repo: FileRepository) {
    suspend operator fun invoke(path: String, content: String): FileOperationResult =
        repo.writeText(path, content)
}

class CreateDirectoryUseCase @Inject constructor(private val repo: FileRepository) {
    suspend operator fun invoke(path: String) = repo.createDirectory(path)
}

class RenameFileUseCase @Inject constructor(private val repo: FileRepository) {
    suspend operator fun invoke(path: String, newName: String) = repo.rename(path, newName)
}

class CopyFileUseCase @Inject constructor(private val repo: FileRepository) {
    suspend operator fun invoke(from: String, to: String) = repo.copy(from, to)
}

class MoveFileUseCase @Inject constructor(private val repo: FileRepository) {
    suspend operator fun invoke(from: String, to: String) = repo.move(from, to)
}

class DeleteFileUseCase @Inject constructor(private val repo: FileRepository) {
    suspend operator fun invoke(path: String) = repo.delete(path)
}

class CompressUseCase @Inject constructor(private val repo: FileRepository) {
    suspend operator fun invoke(paths: List<String>, destinationZip: String) =
        repo.compress(paths, destinationZip)
}

class ExtractUseCase @Inject constructor(private val repo: FileRepository) {
    suspend operator fun invoke(zipPath: String, destinationDir: String) =
        repo.extract(zipPath, destinationDir)
}

class SearchFilesUseCase @Inject constructor(private val repo: FileRepository) {
    suspend operator fun invoke(root: String, query: String): List<FileItem> =
        repo.search(root, query)
}

class ToggleFavoriteUseCase @Inject constructor(private val repo: FileRepository) {
    suspend operator fun invoke(path: String) = repo.toggleFavorite(path)
}
