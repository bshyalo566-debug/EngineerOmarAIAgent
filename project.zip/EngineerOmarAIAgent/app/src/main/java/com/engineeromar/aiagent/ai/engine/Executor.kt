package com.engineeromar.aiagent.ai.engine

import javax.inject.Inject
import javax.inject.Singleton

/** Outcome of running a single plan through an [Executor]. */
data class ExecutionResult(
    val success: Boolean,
    val message: String,
    val artifacts: List<String> = emptyList(),
)

/** Strategy contract: one per [Intent] family. Plugins add new implementations. */
interface Executor {
    val handledIntent: Intent
    suspend fun execute(plan: ExecutionPlan): ExecutionResult
}

/**
 * Registry that resolves an [Intent] to its [Executor] via Dagger multibinding.
 * Executors self-register through [IntentKey]; the registry is therefore
 * closed for modification but open for extension (OCP).
 */
@Singleton
class ExecutorRegistry @Inject constructor(
    private val executors: Map<String, @JvmSuppressWildcards Executor>,
) {
    fun executorFor(intent: Intent): Executor? = executors[intent.id]

    fun all(): Collection<Executor> = executors.values
}
