package com.engineeromar.aiagent.plugin

import com.engineeromar.aiagent.ai.engine.ExecutionPlan
import com.engineeromar.aiagent.ai.engine.ExecutionResult
import com.engineeromar.aiagent.core.logging.Logger
import com.engineeromar.aiagent.domain.model.PluginInfo
import com.engineeromar.aiagent.domain.model.PluginManifest
import com.engineeromar.aiagent.domain.model.PluginState
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Central registry for loaded plugins. Plugins register their factories; the
 * registry instantiates them, builds a permission-scoped [PluginContext], and
 * drives the lifecycle. Command dispatch consults the registry in priority
 * order before falling back to the default agent path.
 *
 * Thread-safe; safe to add/remove plugins while commands are running.
 */
@Singleton
class PluginRegistry @Inject constructor(
    private val contextFactory: PluginContextFactory,
) {

    private val plugins = ConcurrentHashMap<String, PluginEntry>()

    /** Registers and loads a plugin built from [factory]. */
    suspend fun register(manifest: PluginManifest, factory: () -> Plugin): PluginState {
        if (plugins.containsKey(manifest.id)) {
            Logger.w("Plugin") { "${manifest.id} already registered" }
            return PluginState.LOADED
        }
        val started = System.currentTimeMillis()
        val plugin = factory()
        return try {
            val ok = plugin.onLoad(contextFactory.create(manifest.permissions.toSet()))
            val duration = System.currentTimeMillis() - started
            if (ok) {
                plugins[manifest.id] = PluginEntry(plugin, manifest, PluginState.ENABLED)
                Logger.i("Plugin") { "Loaded ${manifest.id} v${manifest.version} in ${duration}ms" }
                PluginState.ENABLED
            } else {
                Logger.w("Plugin") { "${manifest.id} refused to load" }
                PluginState.ERRORED
            }
        } catch (t: Throwable) {
            Logger.e("Plugin") { "Failed to load ${manifest.id}: ${t.message}" }
            plugins[manifest.id] = PluginEntry(plugin, manifest, PluginState.ERRORED, t.message)
            PluginState.ERRORED
        }
    }

    suspend fun enable(id: String) {
        val entry = plugins[id] ?: return
        runCatching { entry.plugin.onEnable() }.onFailure {
            Logger.e("Plugin") { "${id} enable failed: ${it.message}" }
        }
        plugins[id] = entry.copy(state = PluginState.ENABLED)
    }

    suspend fun disable(id: String) {
        val entry = plugins[id] ?: return
        runCatching { entry.plugin.onDisable() }.onFailure {
            Logger.e("Plugin") { "${id} disable failed: ${it.message}" }
        }
        plugins[id] = entry.copy(state = PluginState.DISABLED)
    }

    fun unregister(id: String) {
        plugins.remove(id)?.plugin?.runCatching { onUnload() }
    }

    suspend fun dispatch(request: String, plan: ExecutionPlan): ExecutionResult? {
        for ((_, entry) in plugins) {
            if (entry.state != PluginState.ENABLED) continue
            val result = runCatching { entry.plugin.handle(request, plan) }
                .getOrElse {
                    Logger.w("Plugin") { "${entry.manifest.id} handle error: ${it.message}" }
                    null
                }
            if (result != null) return result
        }
        return null
    }

    fun list(): List<PluginInfo> = plugins.values.map {
        PluginInfo(it.manifest, it.state, 0, it.errorMessage)
    }

    private data class PluginEntry(
        val plugin: Plugin,
        val manifest: PluginManifest,
        val state: PluginState,
        val errorMessage: String? = null,
    )
}
