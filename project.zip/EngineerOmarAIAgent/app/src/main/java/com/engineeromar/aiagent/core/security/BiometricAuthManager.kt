package com.engineeromar.aiagent.core.security

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import com.engineeromar.aiagent.core.logging.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Wraps BiometricPrompt for a clean suspend API. Caller is any FragmentActivity.
 * Used to gate app launch, secret access, and destructive operations.
 */
@Singleton
class BiometricAuthManager @Inject constructor(
    @ApplicationContext private val context: android.content.Context,
) {
    enum class Status { AVAILABLE, NO_HARDWARE, NOT_ENROLLED, UNAVAILABLE }

    fun availability(): Status {
        val bm = BiometricManager.from(context)
        return when (bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)) {
            BiometricManager.BIOMETRIC_SUCCESS -> Status.AVAILABLE
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> Status.NO_HARDWARE
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> Status.NOT_ENROLLED
            else -> Status.UNAVAILABLE
        }
    }

    suspend fun authenticate(activity: FragmentActivity, title: String): Boolean = suspendCoroutine { cont ->
        val executor = androidx.core.content.ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                Logger.i("Biometric") { "Authentication succeeded" }; cont.resume(true)
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                Logger.w("Biometric") { "Error $errorCode: $errString" }; cont.resume(false)
            }
            override fun onAuthenticationFailed() { /* keep prompt alive */ }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()
        prompt.authenticate(info)
    }
}
