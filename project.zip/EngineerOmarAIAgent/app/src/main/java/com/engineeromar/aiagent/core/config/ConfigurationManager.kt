package com.engineeromar.aiagent.core.config

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.engineeromar.aiagent.BuildConfig
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.configDataStore: DataStore<Preferences> by preferencesDataStore(name = "app_config")

/**
 * Centralised, reactive configuration. Backs user-tunable settings (theme,
 * language, AI provider, privacy flags) on top of encrypted DataStore.
 *
 * Secrets (API keys, tokens) do NOT live here — those go through [SecureStorage].
 */
@Singleton
class ConfigurationManager @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    val config: Flow<AppConfig> = context.configDataStore.data.map { it.toConfig() }

    suspend fun update(transform: (AppConfig) -> AppConfig) {
        context.configDataStore.edit { prefs ->
            val current = prefs.toConfig()
            val next = transform(current)
            prefs[KEY_LANGUAGE] = next.language.code
            prefs[KEY_THEME] = next.theme.name
            prefs[KEY_DYNAMIC_COLOR] = next.dynamicColor
            prefs[KEY_AI_PROVIDER] = next.aiProvider.name
            prefs[KEY_BIOMETRIC] = next.biometricLock
            prefs[KEY_PIN_ENABLED] = next.pinEnabled
            prefs[KEY_PERF_MODE] = next.performanceMode.name
        }
    }

    private fun Preferences.toConfig() = AppConfig(
        language = Language.entries.firstOrNull { it.code == this[KEY_LANGUAGE] } ?: Language.ENGLISH,
        theme = ThemeMode.entries.firstOrNull { it.name == this[KEY_THEME] } ?: ThemeMode.DARK,
        dynamicColor = this[KEY_DYNAMIC_COLOR] ?: false,
        aiProvider = AiProviderType.entries.firstOrNull { it.name == this[KEY_AI_PROVIDER] } ?: AiProviderType.OPENAI,
        biometricLock = this[KEY_BIOMETRIC] ?: false,
        pinEnabled = this[KEY_PIN_ENABLED] ?: false,
        performanceMode = PerformanceMode.entries.firstOrNull { it.name == this[KEY_PERF_MODE] } ?: PerformanceMode.BALANCED,
        appVersion = BuildConfig.VERSION_NAME,
    )

    private companion object {
        val KEY_LANGUAGE = stringPreferencesKey("language")
        val KEY_THEME = stringPreferencesKey("theme")
        val KEY_DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val KEY_AI_PROVIDER = stringPreferencesKey("ai_provider")
        val KEY_BIOMETRIC = booleanPreferencesKey("biometric_lock")
        val KEY_PIN_ENABLED = booleanPreferencesKey("pin_enabled")
        val KEY_PERF_MODE = stringPreferencesKey("performance_mode")
    }
}
