package com.engineeromar.aiagent.data.local.entity

import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.PrimaryKey

/**
 * Standalone full-text-search virtual table for the Knowledge Base.
 *
 * We avoid FTS4's `contentEntity` binding because [KnowledgeEntity] uses a
 * String primary key (UUID) and FTS rowids must be integers. Instead this is a
 * self-contained table synced explicitly by the repository on insert/delete,
 * keyed by [docId] (text) so it joins cleanly to [KnowledgeEntity.id].
 *
 * `title` is boosted by being duplicated into the body field during indexing
 * so term frequency reflects document importance.
 */
@Entity(tableName = "knowledge_fts")
@Fts4
data class KnowledgeFtsEntity(
    @PrimaryKey val rowid: Long = 0,
    val docId: String,
    val title: String,
    val body: String,
)
