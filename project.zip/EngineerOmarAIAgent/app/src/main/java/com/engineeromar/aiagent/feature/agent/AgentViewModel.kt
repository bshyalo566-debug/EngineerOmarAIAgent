package com.engineeromar.aiagent.feature.agent

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.engineeromar.aiagent.ai.agent.EngineeringAgent
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChatLine(val text: String, val fromUser: Boolean)

@HiltViewModel
class AgentViewModel @Inject constructor(
    private val agent: EngineeringAgent,
) : ViewModel() {

    private val _messages = MutableStateFlow<List<ChatLine>>(emptyList())
    val messages: StateFlow<List<ChatLine>> = _messages.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    fun send(text: String) {
        _messages.value = _messages.value + ChatLine(text, fromUser = true)
        _busy.value = true
        viewModelScope.launch {
            val reply = agent.ask(history = emptyList(), userInput = text, scope = com.engineeromar.aiagent.domain.model.ConversationScope.GENERAL)
            _messages.value = _messages.value + ChatLine(reply, fromUser = false)
            _busy.value = false
        }
    }
}
