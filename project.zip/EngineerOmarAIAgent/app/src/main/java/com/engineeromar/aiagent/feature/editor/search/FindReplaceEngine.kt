package com.engineeromar.aiagent.feature.editor.search

/**
 * Find/replace engine with optional case-sensitivity, whole-word, and regex
 * modes. Returns zero-based match offsets so the editor can scroll to and
 * highlight every occurrence; replaceAll produces the transformed text.
 */
data class FindMatch(val start: Int, val end: Int, val line: Int, val column: Int)

class FindReplaceEngine {

    fun find(
        source: String, query: String,
        ignoreCase: Boolean = true, wholeWord: Boolean = false, regex: Boolean = false,
    ): List<FindMatch> {
        if (query.isEmpty()) return emptyList()
        val matches = ArrayList<FindMatch>()
        if (regex) {
            val pattern = runCatching { Regex(query, if (ignoreCase) setOf(RegexOption.IGNORE_CASE) else emptySet()) }
                .getOrElse { return emptyList() }
            pattern.findAll(source).forEach { m ->
                matches.add(m.range.toMatch(source))
            }
        } else {
            var idx = 0
            while (true) {
                val pos = source.indexOf(query, idx, ignoreCase = ignoreCase)
                if (pos < 0) break
                if (!wholeWord || isWordBoundary(source, pos, pos + query.length)) {
                    matches.add(IntRange(pos, pos + query.length - 1).toMatch(source))
                }
                idx = pos + query.length
            }
        }
        return matches
    }

    fun replaceAll(
        source: String, query: String, replacement: String,
        ignoreCase: Boolean, wholeWord: Boolean, regex: Boolean,
    ): String = if (regex) {
        runCatching {
            source.replace(
                Regex(query, if (ignoreCase) setOf(RegexOption.IGNORE_CASE) else emptySet()),
                replacement,
            )
        }.getOrDefault(source)
    } else {
        source.replace(query, replacement, ignoreCase)
    }

    private fun IntRange.toMatch(source: String): FindMatch {
        val lineNo = source.substring(0, first).count { it == '\n' } + 1
        val lineStart = source.lastIndexOf('\n', first).let { if (it == -1) 0 else it + 1 }
        val col = first - lineStart + 1
        return FindMatch(start = first, end = last + 1, line = lineNo, column = col)
    }

    private fun isWordBoundary(src: String, start: Int, end: Int): Boolean {
        val before = src.getOrNull(start - 1)?.isLetterOrDigit() == true
        val after = src.getOrNull(end)?.isLetterOrDigit() == true
        return !before && !after
    }
}
