package com.engineeromar.aiagent.ai.provider

import com.engineeromar.aiagent.core.config.AiProviderType
import javax.inject.Inject
import javax.inject.Provider
import javax.inject.Singleton

/**
 * Resolves the active [AiProvider] by configured type. Uses Dagger's
 * multi-binding-friendly [Provider] map so adding a provider = adding one entry.
 */
@Singleton
class AiProviderFactory @Inject constructor(
    private val openAiProvider: OpenAiProvider,
    private val localProvider: LocalAiProvider,
) {
    fun forType(type: AiProviderType): AiProvider = when (type) {
        AiProviderType.OPENAI -> openAiProvider
        AiProviderType.ANTHROPIC -> openAiProvider // swap with AnthropicProvider
        AiProviderType.GEMINI -> openAiProvider    // swap with GeminiProvider
        AiProviderType.LOCAL -> localProvider
    }

    /** Convenience: returns the on-device provider directly (used as fallback). */
    fun local(): AiProvider = localProvider
}
