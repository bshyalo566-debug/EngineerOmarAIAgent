package com.engineeromar.aiagent.core.cache

import android.util.LruCache
import com.engineeromar.aiagent.core.storage.StorageDirectories
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Two-tier cache for hot, reuse-prone data: AI completions, parsed documents,
 * tokenised buffers, search results.
 *
 *  - **Memory tier:** a byte-sized [LruCache] capped at 1/8 of the available
 *    Java heap. `sizeOf` overrides the default (entry-count) so the cap is
 *    measured in bytes — preventing large blobs from evicting many small ones.
 *  - **Disk tier:** the app Cache/ directory, pruned of entries older than one
 *    week when the app is backgrounded.
 *
 * All operations are `@Synchronized` via the underlying [LruCache] monitor.
 */
@Singleton
class CacheManager @Inject constructor(
    private val storage: StorageDirectories,
) {
    private val maxBytes = (Runtime.getRuntime().maxMemory() / 8).toInt().coerceAtLeast(1024 * 1024)

    private val memory: LruCache<String, Any> = object : LruCache<String, Any>(maxBytes) {
        override fun sizeOf(key: String, value: Any): Int = estimateBytes(value)
    }

    @Suppress("UNCHECKED_CAST")
    fun <T> get(key: String): T? = synchronized(memory) { memory.get(key) as? T }

    fun put(key: String, value: Any) {
        synchronized(memory) { memory.put(key, value) }
    }

    fun evict(key: String) {
        synchronized(memory) { memory.remove(key) }
    }

    /** Called when the app is backgrounded — free transient heap + aged files. */
    fun prune() {
        synchronized(memory) { memory.evictAll() }
        val cutoff = System.currentTimeMillis() - WEEK_MS
        storage.cacheDir.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
    }

    private fun estimateBytes(value: Any): Int = when (value) {
        is String -> value.length * 2           // UTF-16 chars
        is ByteArray -> value.size
        is List<*> -> value.size * 64
        is Map<*, *> -> value.size * 64
        else -> 256
    }.coerceAtLeast(1)

    private companion object {
        const val WEEK_MS = 7L * 86_400_000L
    }
}
