package com.engineeromar.aiagent.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.engineeromar.aiagent.R
import com.engineeromar.aiagent.ui.navigation.AppNavigation
import com.engineeromar.aiagent.ui.navigation.Destination
import com.engineeromar.aiagent.ui.navigation.bottomNav

@Composable
fun MainScaffold() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("Engineer Omar", style = MaterialTheme.typography.titleLarge)
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                actions = {
                    IconButton(onClick = { nav.navigate(Destination.Settings.route) }) {
                        Icon(Icons.Outlined.Settings, contentDescription = "Settings")
                    }
                },
            )
        },
        bottomBar = {
            if (current?.route in bottomNav.map { it.route }) {
                NavigationBar {
                    bottomNav.forEach { dest ->
                        val selected = current?.hierarchy?.any { it.route == dest.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                nav.navigate(dest.route) {
                                    popUpTo(nav.graph.startDestinationId) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(dest.icon, contentDescription = null) },
                            label = { Text(stringResource(id = titleRes(dest))) },
                        )
                    }
                }
            }
        },
    ) { inner ->
        Box(Modifier.padding(inner)) {
            AppNavigation()
        }
    }
}

/** Exhaustive over the bottom-nav destinations so a new tab can't silently break. */
private fun titleRes(dest: Destination): Int = when (dest) {
    Destination.Dashboard -> R.string.nav_dashboard
    Destination.Agent -> R.string.nav_agent
    Destination.Projects -> R.string.nav_projects
    Destination.Editor -> R.string.nav_editor
    Destination.Knowledge -> R.string.nav_knowledge
    Destination.Files -> R.string.nav_files
    // Destinations reachable but not shown in the bottom bar.
    Destination.Git,
    Destination.GitHub,
    Destination.Voice,
    Destination.Settings -> R.string.nav_dashboard
}
