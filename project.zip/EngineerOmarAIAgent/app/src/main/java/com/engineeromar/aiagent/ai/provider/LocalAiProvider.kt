package com.engineeromar.aiagent.ai.provider

import com.engineeromar.aiagent.ai.local.LocalCompletionEngine
import com.engineeromar.aiagent.domain.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Fully on-device [AiProvider] backed by [LocalCompletionEngine]. Zero network,
 * zero API key, zero cost. Used when the user selects AI Provider = LOCAL, or
 * automatically as a fallback when no provider key is configured / reachable.
 *
 * To upgrade to a neural backend without changing any caller, replace the
 * engine call below with a llama.cpp / MLC / ONNX inference call against a
 * .gguf / .onnx model file present under Knowledge/ or Downloads/.
 */
@Singleton
class LocalAiProvider @Inject constructor(
    private val engine: LocalCompletionEngine,
) : AiProvider {

    override val id = "local"
    override val displayName = "On-device (offline)"

    override suspend fun complete(request: CompletionRequest): CompletionResponse {
        val prompt = buildPrompt(request)
        val started = System.currentTimeMillis()
        val content = engine.complete(prompt, request.maxTokens)
        val approxTokens = (content.length / 4).coerceAtLeast(1)
        return CompletionResponse(
            content = content,
            model = "eo-local-1",
            tokensIn = (prompt.length / 4).coerceAtLeast(1),
            tokensOut = approxTokens,
            finishReason = "stop",
        )
    }

    override fun stream(request: CompletionRequest): Flow<String> = flow {
        // Emit the completion word-by-word for a typing effect in the chat UI.
        val content = complete(request).content
        content.split(" ").forEach { word ->
            emit(if (word == content.split(" ").first()) word else " $word")
            kotlinx.coroutines.delay(12)
        }
    }.flowOn(Dispatchers.Default)

    private fun buildPrompt(request: CompletionRequest): String {
        val sb = StringBuilder()
        request.systemPrompt?.let { sb.append(it).append("\n\n") }
        request.messages.takeLast(8).forEach { msg ->
            sb.append(msg.role.name.lowercase()).append(": ").append(msg.content).append('\n')
        }
        sb.append("assistant: ")
        return sb.toString()
    }
}
