package com.engineeromar.aiagent.feature.editor

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import com.engineeromar.aiagent.feature.editor.highlight.CodeLanguage
import com.engineeromar.aiagent.feature.editor.highlight.EditorTheme
import com.engineeromar.aiagent.feature.editor.highlight.SyntaxHighlighter

/**
 * Applies syntax highlighting to a BasicTextField by tokenising the buffer
 * on every transform. OffsetMapping is identity because we never change the
 * text length — only its styling — so the cursor/selection stay aligned.
 */
class SyntaxHighlightTransformation(
    private val language: CodeLanguage,
    private val theme: EditorTheme,
    private val highlighter: SyntaxHighlighter,
) : VisualTransformation {

    override fun filter(text: AnnotatedString): TransformedText {
        val source = text.text
        val tokens = highlighter.tokenize(source, language)
        val annotated = buildAnnotatedString {
            for (token in tokens) {
                pushStyle(SpanStyle(color = theme.colorFor(token.type)))
                append(token.text)
                pop()
            }
        }
        return TransformedText(annotated, OffsetMapping.Identity)
    }
}
