package com.engineeromar.aiagent.data.knowledge

import com.engineeromar.aiagent.core.logging.Logger
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext

/**
 * Extracts text from PDF documents using PDFBox-Android (pure-Java port that
 * runs on-device without native code). Initialises the font resources lazily
 * on first use and caches the readiness flag.
 */
@Singleton
class PdfTextExtractor @Inject constructor(
    @ApplicationContext private val context: Context,
) : DocumentTextExtractor {

    @Volatile private var initialised = false

    override fun extract(file: File): String {
        if (!file.exists()) return ""
        ensureInitialised()
        return runCatching {
            PDDocument.load(file).use { doc ->
                if (doc.isEncrypted) {
                    Logger.w("PdfExtractor") { "${file.name} is encrypted — skipping" }
                    return@use ""
                }
                PDFTextStripper().getText(doc)
            }
        }.getOrElse {
            Logger.w("PdfExtractor") { "Failed to parse ${file.name}: ${it.message}" }
            ""
        }
    }

    private fun ensureInitialised() {
        if (initialised) return
        synchronized(this) {
            if (initialised) return
            runCatching {
                PDFBoxResourceLoader.init(context)
                initialised = true
            }.onFailure { Logger.w("PdfExtractor") { "PDFBox init failed: ${it.message}" } }
        }
    }
}
