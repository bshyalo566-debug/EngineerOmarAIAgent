package com.engineeromar.aiagent.domain.model

data class CommandLog(
    val id: String,
    val createdAt: Long,
    val intent: String,
    val request: String,
    val plan: List<String>,
    val status: CommandStatus,
    val durationMs: Long,
    val subsystem: String,
    val permissionGranted: Boolean,
    val verificationPassed: Boolean,
    val errorMessage: String?,
)

enum class CommandStatus { QUEUED, RUNNING, SUCCESS, FAILED, CANCELLED }
