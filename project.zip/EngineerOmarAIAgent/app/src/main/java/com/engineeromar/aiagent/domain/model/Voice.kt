package com.engineeromar.aiagent.domain.model

/** Voice subsystem domain events surfaced to the UI. */
sealed class VoiceEvent {
    data class Listening(val partialTranscript: String) : VoiceEvent()
    data class Recognized(val text: String, val confidence: Float) : VoiceEvent()
    data class Error(val code: Int, val message: String) : VoiceEvent()
    data class SpeakingStarted(val utteranceId: String) : VoiceEvent()
    data class SpeakingDone(val utteranceId: String) : VoiceEvent()
    object Ready : VoiceEvent()
}

data class VoiceLanguage(val tag: String, val display: String) {
    companion object {
        val ENGLISH = VoiceLanguage("en-US", "English (US)")
        val ARABIC = VoiceLanguage("ar-SA", "العربية")
        val ENGLISH_GB = VoiceLanguage("en-GB", "English (UK)")
        val SUPPORTED = listOf(ENGLISH, ARABIC, ENGLISH_GB)
    }
}
