package com.engineeromar.aiagent.feature.editor.autocomplete

import com.engineeromar.aiagent.feature.editor.highlight.CodeLanguage
import com.engineeromar.aiagent.feature.editor.highlight.LanguageDefinitions

/**
 * Suggestion source for the editor. Combines per-language keyword/builtin
 * completions with identifiers extracted from the current buffer (so symbols
 * the user already typed are offered). Snippets are simple text templates.
 */
data class Completion(
    val label: String,
    val detail: String,
    val insertText: String,
    val kind: CompletionKind,
)

enum class CompletionKind { KEYWORD, FUNCTION, TYPE, SNIPPET, IDENTIFIER, PROPERTY }

class AutocompleteSource {

    fun completionsFor(
        prefix: String,
        language: CodeLanguage,
        bufferIdentifiers: Set<String>,
    ): List<Completion> {
        if (prefix.isEmpty()) return emptyList()
        val p = prefix.lowercase()
        val results = ArrayList<Completion>()

        LanguageDefinitions.keywordsFor(language)
            .filter { it.startsWith(prefix) || it.lowercase().startsWith(p) }
            .forEach { results.add(Completion(it, "keyword", it, CompletionKind.KEYWORD)) }

        LanguageDefinitions.builtinsFor(language)
            .filter { it.startsWith(prefix) || it.lowercase().startsWith(p) }
            .forEach { results.add(Completion(it, "builtin", it, CompletionKind.FUNCTION)) }

        bufferIdentifiers
            .filter { it.startsWith(prefix) && it.length > prefix.length }
            .take(40)
            .forEach { results.add(Completion(it, "identifier", it, CompletionKind.IDENTIFIER)) }

        snippets(language)
            .filter { it.label.startsWith(prefix) || it.insertText.startsWith(prefix) }
            .forEach(results::add)

        return results.distinctBy { it.label }.take(50)
    }

    private fun snippets(language: CodeLanguage): List<Completion> = when (language) {
        CodeLanguage.KOTLIN -> listOf(
            Completion("fun", "function", "fun name(): Unit {\n    \n}", CompletionKind.SNIPPET),
            Completion("class", "class", "class Name {\n    \n}", CompletionKind.SNIPPET),
            Completion("vms", "ViewModel state", "private val _state = MutableStateFlow()", CompletionKind.SNIPPET),
        )
        CodeLanguage.JAVA -> listOf(
            Completion("psvm", "main", "public static void main(String[] args) {\n    \n}", CompletionKind.SNIPPET),
            Completion("sout", "print", "System.out.println();", CompletionKind.SNIPPET),
        )
        CodeLanguage.PYTHON -> listOf(
            Completion("def", "function", "def name():\n    ", CompletionKind.SNIPPET),
            Completion("class", "class", "class Name:\n    ", CompletionKind.SNIPPET),
        )
        CodeLanguage.JAVASCRIPT, CodeLanguage.TYPESCRIPT -> listOf(
            Completion("cl", "console.log", "console.log()", CompletionKind.SNIPPET),
            Completion("afn", "arrow function", "const name = () => {\n    \n}", CompletionKind.SNIPPET),
        )
        else -> emptyList()
    }
}
