package com.engineeromar.aiagent.ai.engine.executors

import com.engineeromar.aiagent.ai.engine.ExecutionPlan
import com.engineeromar.aiagent.ai.engine.ExecutionResult
import com.engineeromar.aiagent.ai.engine.Executor
import com.engineeromar.aiagent.ai.provider.AiProvider
import com.engineeromar.aiagent.ai.provider.AiProviderFactory
import com.engineeromar.aiagent.ai.provider.CompletionRequest
import com.engineeromar.aiagent.ai.provider.EngineeringSystemPrompt
import com.engineeromar.aiagent.core.config.ConfigurationManager
import com.engineeromar.aiagent.domain.model.ChatMessage
import com.engineeromar.aiagent.domain.model.MessageRole
import javax.inject.Inject
import kotlinx.coroutines.flow.first

/**
 * Delegates code-generation requests to the active AI provider, resolved at
 * call time from the user's configuration. Falls back to the on-device
 * provider if the configured one is unavailable (offline / no key). Registered
 * under the `code.generate` intent key in [ExecutorModule].
 */
class CodeGenerationExecutor @Inject constructor(
    private val factory: AiProviderFactory,
    private val config: ConfigurationManager,
) : Executor {

    override val handledIntent = com.engineeromar.aiagent.ai.engine.Intents.GENERATE_CODE

    override suspend fun execute(plan: ExecutionPlan): ExecutionResult {
        val prompt = plan.params["request"] ?: plan.steps.joinToString(separator = ". ")
        val provider: AiProvider = resolveProvider()
        val resp = provider.complete(
            CompletionRequest(
                model = "eo-active",
                systemPrompt = EngineeringSystemPrompt.TEXT,
                messages = listOf(
                    ChatMessage("x", "x", MessageRole.USER, prompt, 0, null, emptyList()),
                ),
            ),
        )
        return ExecutionResult(
            success = resp.finishReason != "config_missing",
            message = if (resp.finishReason == "config_missing")
                resp.content
            else
                "Generated code (${resp.tokensOut} tokens via ${provider.displayName})",
            artifacts = listOf(resp.content),
        )
    }

    private suspend fun resolveProvider(): AiProvider = runCatching {
        factory.forType(config.config.first().aiProvider)
    }.getOrDefault(factory.local())
}
