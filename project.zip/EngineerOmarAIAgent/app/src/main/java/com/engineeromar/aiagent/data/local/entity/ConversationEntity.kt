package com.engineeromar.aiagent.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** A long-running AI conversation thread (the Agent's long-term memory surface). */
@Entity(
    tableName = "conversations",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.SET_NULL,
        )
    ],
    indices = [Index("projectId"), Index("updatedAt")],
)
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val projectId: String?,
    val scope: String,          // general | project | knowledge | code
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean = false,
    val tokenCount: Int = 0,
)
