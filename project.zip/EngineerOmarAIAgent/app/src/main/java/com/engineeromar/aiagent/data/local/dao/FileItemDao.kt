package com.engineeromar.aiagent.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.engineeromar.aiagent.data.local.entity.FileItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FileItemDao {
    @Query("SELECT * FROM file_items WHERE projectId = :projectId ORDER BY name")
    fun observeForProject(projectId: String): Flow<List<FileItemEntity>>

    @Query("SELECT * FROM file_items WHERE isFavorite = 1 ORDER BY name")
    fun observeFavorites(): Flow<List<FileItemEntity>>

    @Query("SELECT * FROM file_items WHERE lastOpenedAt IS NOT NULL ORDER BY lastOpenedAt DESC LIMIT 50")
    fun observeRecent(): Flow<List<FileItemEntity>>

    @Query("SELECT * FROM file_items WHERE name LIKE '%' || :q || '%' ORDER BY name")
    suspend fun search(q: String): List<FileItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: FileItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<FileItemEntity>)

    @Query("DELETE FROM file_items WHERE path = :path")
    suspend fun deleteByPath(path: String)

    @Query("UPDATE file_items SET isFavorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: String, fav: Boolean)

    @Query("UPDATE file_items SET lastOpenedAt = :ts WHERE id = :id")
    suspend fun touch(id: String, ts: Long)
}
