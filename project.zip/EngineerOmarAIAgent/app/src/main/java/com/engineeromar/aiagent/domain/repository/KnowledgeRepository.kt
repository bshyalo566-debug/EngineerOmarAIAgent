package com.engineeromar.aiagent.domain.repository

import com.engineeromar.aiagent.domain.model.KnowledgeCategory
import com.engineeromar.aiagent.domain.model.KnowledgeDocument
import com.engineeromar.aiagent.domain.model.SearchResult
import kotlinx.coroutines.flow.Flow

/**
 * Knowledge Base contract. Documents are imported from disk, parsed to plain
 * text, chunked, and indexed for both FTS keyword search and an offline
 * TF-IDF "semantic" cosine search — all running on-device, fully offline.
 */
interface KnowledgeRepository {

    fun observeDocuments(): Flow<List<KnowledgeDocument>>
    fun observeByCategory(category: KnowledgeCategory): Flow<List<KnowledgeDocument>>

    suspend fun importDocument(filePath: String, category: KnowledgeCategory): Result<KnowledgeDocument>
    suspend fun deleteDocument(id: String): Result<Unit>
    suspend fun rebuildIndex(): Result<Int>

    /** Keyword (FTS) search. */
    suspend fun search(query: String, limit: Int = 20): List<SearchResult>

    /** Offline semantic search (TF-IDF cosine over indexed chunks). */
    suspend fun semanticSearch(query: String, limit: Int = 10): List<SearchResult>

    suspend fun getDocument(id: String): Result<KnowledgeDocument>
    suspend fun documentText(id: String): Result<String>
}
