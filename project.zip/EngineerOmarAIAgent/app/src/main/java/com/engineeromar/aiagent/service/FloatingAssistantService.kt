package com.engineeromar.aiagent.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.engineeromar.aiagent.R
import com.engineeromar.aiagent.ui.floating.FloatingAssistantPanel
import com.engineeromar.aiagent.ui.floating.FloatingAssistantViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlin.math.abs

/**
 * The Floating AI Assistant — a draggable bubble that expands into a Compose
 * panel over any app.
 *
 * Implementation (official APIs only):
 *  - SYSTEM_ALERT_WINDOW overlay via WindowManager (TYPE_APPLICATION_OVERLAY).
 *  - Foreground service of type `specialUse` keeps the bubble alive.
 *  - The expanded panel is a [ComposeView] attached with a lifecycle +
 *    saved-state registry owner so Compose state survives hide/show cycles.
 *  - Drag vs tap is distinguished using the platform [ViewConfiguration]
 *    touch-slop; no input is ever injected into other apps.
 *
 * No root, no accessibility abuse, no exploits.
 */
@AndroidEntryPoint
class FloatingAssistantService : Service(), SavedStateRegistryOwner, LifecycleOwner {

    @Inject lateinit var vm: FloatingAssistantViewModel

    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var panel: ComposeView? = null
    private var panelShown = false
    private val touchSlop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        startForeground(NOTIF_ID, buildNotification())
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun showBubble() {
        val params = bubbleParams().apply { x = 16; y = 600 }
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_floating_bubble)
            val pad = (18 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }
        attachDrag(view, params) { togglePanel() }
        bubble = view
        runCatching { windowManager.addView(view, params) }
    }

    private fun togglePanel() {
        if (panelShown) hidePanel() else showPanel()
    }

    private fun showPanel() {
        if (panel != null) { panelShown = true; return }
        val compose = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingAssistantService)
            setViewTreeSavedStateRegistryOwner(this@FloatingAssistantService)
            setContent {
                MaterialTheme {
                    FloatingAssistantPanel(viewModel = vm, onClose = { hidePanel() })
                }
            }
        }
        val params = panelParams()
        runCatching {
            windowManager.addView(compose, params)
            panel = compose
            panelShown = true
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        }
    }

    private fun hidePanel() {
        panel?.let {
            runCatching { windowManager.removeView(it) }
            it.disposeComposition()
        }
        panel = null
        panelShown = false
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
    }

    private fun attachDrag(view: View, params: WindowManager.LayoutParams, onTap: () -> Unit) {
        var initialX = 0; var initialY = 0; var touchX = 0f; var touchY = 0f
        var moved = false
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    touchX = e.rawX; touchY = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX; val dy = e.rawY - touchY
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) moved = true
                    params.x = initialX + dx.toInt(); params.y = initialY + dy.toInt()
                    runCatching { windowManager.updateViewLayout(view, params) }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap()
            }
            true
        }
    }

    /** Small, non-focusable overlay window for the bubble itself. */
    private fun bubbleParams() = baseParams(WindowManager.LayoutParams.WRAP_CONTENT).apply {
        gravity = Gravity.TOP or Gravity.START
    }

    /** Full-width, focusable window for the expanded panel (so the IME works). */
    private fun panelParams() = baseParams(ViewGroup.LayoutParams.MATCH_PARENT).apply {
        height = WindowManager.LayoutParams.WRAP_CONTENT
        gravity = Gravity.BOTTOM
        flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
    }

    private fun baseParams(width: Int) = WindowManager.LayoutParams(
        width,
        WindowManager.LayoutParams.WRAP_CONTENT,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT,
    )

    override fun onDestroy() {
        hidePanel()
        bubble?.let { runCatching { windowManager.removeView(it) } }
        bubble = null
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Floating Assistant", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_floating_title))
            .setContentText(getString(R.string.notif_floating_text))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIF_ID = 4201
        private const val CHANNEL_ID = "eo_floating"
    }
}
