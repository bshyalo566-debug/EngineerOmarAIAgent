package com.engineeromar.aiagent.plugin

import com.engineeromar.aiagent.domain.model.PluginPermission

/** Network capability for plugins that declared [PluginPermission.NETWORK]. */
interface PluginNetwork {
    suspend fun get(url: String): String
    suspend fun post(url: String, body: String, contentType: String): String
}

/** File access for plugins that declared FILE_READ / FILE_WRITE. */
interface PluginFileAccess {
    fun read(path: String): String
    fun write(path: String, content: String)
    fun list(directory: String): List<String>
}

/** Database access for plugins that declared DATABASE. */
interface PluginDatabase {
    suspend fun query(sql: String, vararg args: Any): List<Map<String, Any?>>
}

/** AI capability for plugins that declared AI_PROVIDER. */
interface PluginAi {
    suspend fun complete(prompt: String, maxTokens: Int = 1024): String
}

/** Clipboard for plugins that declared CLIPBOARD. */
interface PluginClipboard {
    fun copy(text: String)
    fun paste(): String
}

/** Notifications for plugins that declared NOTIFICATIONS. */
interface PluginNotifications {
    fun show(title: String, body: String)
}
