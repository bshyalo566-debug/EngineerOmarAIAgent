package com.engineeromar.aiagent.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.engineeromar.aiagent.core.config.AiProviderType
import com.engineeromar.aiagent.core.config.Language
import com.engineeromar.aiagent.core.config.PerformanceMode
import com.engineeromar.aiagent.core.config.ThemeMode
import com.engineeromar.aiagent.core.security.SecureStorage

@Composable
fun SettingsScreen(vm: SettingsViewModel = hiltViewModel()) {
    val config by vm.config.collectAsStateWithLifecycle()
    val scroll = rememberScrollState()

    Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.size(8.dp))

        SectionCard("Language") {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                Language.entries.forEachIndexed { i, lang ->
                    SegmentedButton(
                        selected = config?.language == lang,
                        onClick = { vm.setLanguage(lang) },
                        shape = SegmentedButtonDefaults.itemShape(i, Language.entries.size),
                    ) { Text(lang.display) }
                }
            }
        }

        SectionCard("Theme") {
            ThemeMode.entries.forEach { mode ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Switch(
                        checked = config?.theme == mode,
                        onCheckedChange = { if (it) vm.setTheme(mode) },
                    )
                    Spacer(Modifier.size(8.dp)); Text(mode.name.lowercase().replaceFirstChar { it.uppercase() })
                }
            }
        }

        SectionCard("AI Provider") {
            AiProviderType.entries.forEach { provider ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Switch(
                        checked = config?.aiProvider == provider,
                        onCheckedChange = { if (it) vm.setAiProvider(provider) },
                    )
                    Spacer(Modifier.size(8.dp)); Text(provider.displayName())
                }
            }
            Spacer(Modifier.size(8.dp))
            ApiKeyField("OpenAI API key", SecureStorage.KEY_OPENAI_API_KEY, vm)
            ApiKeyField("Anthropic API key", SecureStorage.KEY_ANTHROPIC_API_KEY, vm)
            ApiKeyField("Gemini API key", SecureStorage.KEY_GEMINI_API_KEY, vm)
            ApiKeyField("GitHub PAT", SecureStorage.KEY_GITHUB_PAT, vm)
        }

        SectionCard("Security") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = config?.biometricLock == true,
                    onCheckedChange = vm::setBiometric,
                )
                Spacer(Modifier.size(8.dp)); Text("Biometric / device lock on launch")
            }
            Spacer(Modifier.size(8.dp))
            OutlinedButton(onClick = vm::clearAllSecrets) { Text("Clear all stored secrets") }
        }

        SectionCard("Performance") {
            PerformanceMode.entries.forEach { mode ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Switch(
                        checked = config?.performanceMode == mode,
                        onCheckedChange = { if (it) vm.setPerformance(mode) },
                    )
                    Spacer(Modifier.size(8.dp)); Text(mode.name.lowercase().replace('_', ' ')
                        .replaceFirstChar { it.uppercase() })
                }
            }
        }

        SectionCard("About") {
            Text("Version ${config?.appVersion ?: "1.0.0"}",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Engineer Omar AI Agent — offline-first Android engineering platform.",
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.size(8.dp)); content()
        }
    }
}

@Composable
private fun ApiKeyField(label: String, key: String, vm: SettingsViewModel) {
    var value by remember { mutableStateOf(vm.apiKey(key)) }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        OutlinedTextField(
            value = value, onValueChange = { value = it; vm.saveApiKey(key, it) },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(label) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
        )
    }
}

private fun AiProviderType.displayName(): String = when (this) {
    AiProviderType.OPENAI -> "OpenAI"
    AiProviderType.ANTHROPIC -> "Anthropic"
    AiProviderType.GEMINI -> "Google Gemini"
    AiProviderType.LOCAL -> "On-device (offline)"
}
