package com.engineeromar.aiagent.domain.repository

import com.engineeromar.aiagent.domain.model.FileItem
import com.engineeromar.aiagent.domain.model.FileOperationResult
import com.engineeromar.aiagent.domain.model.SortOrder
import kotlinx.coroutines.flow.Flow

/**
 * File Manager repository contract. Every operation is suspendable and returns
 * a typed [FileOperationResult]; failures are explicit (never thrown) so the
 * ViewModel renders consistent messages.
 *
 * All paths are absolute, app-scoped (no SAF tree URIs at this layer — the
 * implementation maps SAF to absolute paths where required).
 */
interface FileRepository {

    suspend fun list(directoryPath: String, sortOrder: SortOrder): List<FileItem>
    suspend fun readText(path: String, maxBytes: Int = 1_048_576): String
    suspend fun writeText(path: String, content: String): FileOperationResult
    suspend fun createDirectory(path: String): FileOperationResult
    suspend fun rename(from: String, toName: String): FileOperationResult
    suspend fun copy(from: String, to: String): FileOperationResult
    suspend fun move(from: String, to: String): FileOperationResult
    suspend fun delete(path: String): FileOperationResult
    suspend fun compress(paths: List<String>, destinationZip: String): FileOperationResult
    suspend fun extract(zipPath: String, destinationDir: String): FileOperationResult
    suspend fun search(root: String, query: String, maxResults: Int = 200): List<FileItem>

    fun observeFavorites(): Flow<List<FileItem>>
    fun observeRecent(limit: Int = 50): Flow<List<FileItem>>
    suspend fun toggleFavorite(path: String): FileOperationResult
    suspend fun touchRecent(path: String): FileOperationResult
}
