package com.engineeromar.aiagent.feature.editor.highlight

/**
 * Per-language keyword/builtin tables. Keeping these as plain sets lets the
 * tokenizer stay language-agnostic; adding a language is a single entry here.
 */
object LanguageDefinitions {

    val keywords: Map<CodeLanguage, Set<String>> = mapOf(
        CodeLanguage.KOTLIN to setOf(
            "as", "break", "class", "continue", "do", "else", "false", "for", "fun", "if",
            "in", "interface", "is", "null", "object", "package", "return", "super", "this",
            "throw", "true", "try", "typealias", "typeof", "val", "var", "when", "while",
            "by", "catch", "constructor", "delegate", "dynamic", "field", "file", "finally",
            "get", "import", "init", "param", "property", "receiver", "set", "setparam",
            "value", "where", "internal", "private", "public", "protected", "abstract",
            "actual", "annotation", "companion", "const", "crossinline", "data", "enum",
            "expect", "external", "final", "infix", "inline", "inner", "lateinit", "noinline",
            "open", "operator", "out", "override", "reified", "sealed", "suspend", "tailrec",
            "vararg", "suspend",
        ),
        CodeLanguage.JAVA to setOf(
            "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char",
            "class", "const", "continue", "default", "do", "double", "else", "enum", "extends",
            "final", "finally", "float", "for", "goto", "if", "implements", "import",
            "instanceof", "int", "interface", "long", "native", "new", "package", "private",
            "protected", "public", "return", "short", "static", "strictfp", "super", "switch",
            "synchronized", "this", "throw", "throws", "transient", "try", "void", "volatile",
            "while", "var", "yield", "record", "sealed", "permits", "non-sealed",
        ),
        CodeLanguage.JAVASCRIPT to setOf(
            "break", "case", "catch", "class", "const", "continue", "debugger", "default",
            "delete", "do", "else", "export", "extends", "finally", "for", "function", "if",
            "import", "in", "instanceof", "new", "return", "super", "switch", "this", "throw",
            "try", "typeof", "var", "void", "while", "with", "yield", "let", "async", "await",
            "of", "true", "false", "null", "undefined",
        ),
        CodeLanguage.TYPESCRIPT to setOf(
            "break", "case", "catch", "class", "const", "continue", "debugger", "default",
            "delete", "do", "else", "export", "extends", "finally", "for", "function", "if",
            "import", "in", "instanceof", "new", "return", "super", "switch", "this", "throw",
            "try", "typeof", "var", "void", "while", "with", "yield", "let", "async", "await",
            "of", "true", "false", "null", "undefined", "type", "interface", "enum", "namespace",
            "implements", "private", "protected", "public", "readonly", "abstract", "as", "is",
            "keyof", "infer", "never", "unknown", "any", "string", "number", "boolean", "symbol",
            "bigint", "object", "void",
        ),
        CodeLanguage.PYTHON to setOf(
            "False", "None", "True", "and", "as", "assert", "async", "await", "break", "class",
            "continue", "def", "del", "elif", "else", "except", "finally", "for", "from",
            "global", "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass",
            "raise", "return", "try", "while", "with", "yield", "self", "cls",
        ),
        CodeLanguage.SHELL to setOf(
            "if", "then", "else", "elif", "fi", "case", "esac", "for", "while", "do", "done",
            "function", "in", "return", "export", "echo", "local", "set", "unset",
        ),
        CodeLanguage.YAML to setOf(
            "true", "false", "null", "yes", "no", "on", "off",
        ),
    )

    val builtins: Map<CodeLanguage, Set<String>> = mapOf(
        CodeLanguage.KOTLIN to setOf(
            "println", "print", "arrayOf", "listOf", "setOf", "mapOf", "mutableListOf",
            "mutableSetOf", "mutableMapOf", "sequenceOf", "rangeTo", "until", "downTo", "step",
            "Pair", "Triple", "Result", "Unit", "Any", "Nothing", "String", "Int", "Long",
            "Short", "Byte", "Float", "Double", "Boolean", "Char", "List", "Set", "Map",
            "Sequence", "Collection", "Iterable", "Array", "Throwable", "Exception", "Error",
        ),
        CodeLanguage.JAVASCRIPT to setOf(
            "console", "Math", "JSON", "Object", "Array", "String", "Number", "Boolean",
            "Promise", "Map", "Set", "Symbol", "Date", "RegExp", "Error", "window", "document",
            "fetch", "require", "module", "exports", "process",
        ),
        CodeLanguage.PYTHON to setOf(
            "print", "len", "range", "str", "int", "float", "list", "dict", "set", "tuple",
            "bool", "type", "isinstance", "open", "enumerate", "zip", "map", "filter", "sorted",
            "abs", "min", "max", "sum", "round", "input",
        ),
    )

    fun keywordsFor(language: CodeLanguage): Set<String> = keywords[language] ?: emptySet()
    fun builtinsFor(language: CodeLanguage): Set<String> = builtins[language] ?: emptySet()
}
