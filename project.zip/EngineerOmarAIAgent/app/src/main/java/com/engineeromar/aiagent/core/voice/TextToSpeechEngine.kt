package com.engineeromar.aiagent.core.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.engineeromar.aiagent.domain.model.VoiceEvent
import com.engineeromar.aiagent.domain.model.VoiceLanguage
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Wraps [TextToSpeech] behind a coroutine [Flow]. Emits start/done events per
 * utterance so the UI can drive speaking animations and chain utterances.
 * Engine + locale are configured lazily and rebound when the language changes.
 */
@Singleton
class TextToSpeechEngine @Inject constructor(
    @ApplicationContext private val context: Context,
) {

    @Volatile private var tts: TextToSpeech? = null
    @Volatile private var ready = false

    fun speak(text: String, language: VoiceLanguage = VoiceLanguage.ENGLISH): Flow<VoiceEvent> =
        callbackFlow {
            val utteranceId = UUID.randomUUID().toString()
            val engine = obtain(language) {
                val result = it.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
                if (result != TextToSpeech.SUCCESS) {
                    trySend(VoiceEvent.Error(-1, "TTS speak failed"))
                    close()
                }
            }
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { trySend(VoiceEvent.SpeakingStarted(id ?: "")) }
                override fun onDone(id: String?) {
                    trySend(VoiceEvent.SpeakingDone(id ?: "")); close()
                }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { trySend(VoiceEvent.Error(-1, "TTS error")); close() }
                override fun onError(utteranceId: String?, errorCode: Int) {
                    trySend(VoiceEvent.Error(errorCode, "TTS error $errorCode")); close()
                }
            })
            awaitClose {
                // Keep the engine alive for reuse; do not shutdown here.
            }
        }

    fun stop() { tts?.stop() }

    fun shutdown() {
        tts?.stop(); tts?.shutdown(); tts = null; ready = false
    }

    private fun obtain(language: VoiceLanguage, onReady: (TextToSpeech) -> Unit): TextToSpeech {
        tts?.let { if (ready) onReady(it); return it }
        val engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.forLanguageTag(language.tag)
                ready = true
                tts?.let(onReady)
            }
        }
        tts = engine
        return engine
    }
}
