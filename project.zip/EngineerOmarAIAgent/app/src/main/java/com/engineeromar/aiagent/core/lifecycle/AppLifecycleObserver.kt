package com.engineeromar.aiagent.core.lifecycle

import android.app.Application
import android.os.Bundle
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.engineeromar.aiagent.core.cache.CacheManager
import com.engineeromar.aiagent.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Observes app + activity lifecycle to drive cross-cutting behaviour:
 *  - foreground/background telemetry,
 *  - cache eviction when the app goes to background,
 *  - hook points for the Memory / Task-Scheduler subsystems.
 */
@Singleton
class AppLifecycleObserver @Inject constructor(
    private val cacheManager: CacheManager,
) : DefaultLifecycleObserver, android.app.Application.ActivityLifecycleCallbacks {

    fun register(app: Application) {
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }

    override fun onStart(owner: LifecycleOwner) {
        Logger.i("Lifecycle") { "App foregrounded" }
    }

    override fun onStop(owner: LifecycleOwner) {
        Logger.i("Lifecycle") { "App backgrounded — pruning cache" }
        cacheManager.prune()
    }

    // --- ActivityLifecycleCallbacks (kept minimal; can power session analytics) ---
    override fun onActivityCreated(a: android.app.Activity, b: Bundle?) {}
    override fun onActivityStarted(a: android.app.Activity) {}
    override fun onActivityResumed(a: android.app.Activity) {}
    override fun onActivityPaused(a: android.app.Activity) {}
    override fun onActivityStopped(a: android.app.Activity) {}
    override fun onActivitySaveInstanceState(a: android.app.Activity, b: Bundle) {}
    override fun onActivityDestroyed(a: android.app.Activity) {}
}
