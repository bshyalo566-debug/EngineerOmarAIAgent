package com.engineeromar.aiagent.ui.theme

import androidx.compose.ui.graphics.Color

// ─────────────────────────────────────────────────────────────
// Signature palette: Luxury Black base + Gold accent (MD3 tokens)
// ─────────────────────────────────────────────────────────────

// Brand
val Gold = Color(0xFFD4AF37)          // primary accent
val GoldSoft = Color(0xFFE6C66B)
val GoldDeep = Color(0xFFB8902A)

// Dark surfaces
val Obsidian = Color(0xFF0B0B0D)
val Onyx = Color(0xFF121317)
val Graphite = Color(0xFF1C1D22)
val Slate = Color(0xFF26282F)
val Outline = Color(0xFF34363F)

// On-surface
val TextPrimary = Color(0xFFF4F2EC)
val TextSecondary = Color(0xFFB8B6AE)
val TextMuted = Color(0xFF7A7A77)

// Semantic
val Success = Color(0xFF3DD68C)
val Warning = Color(0xFFFFB547)
val Danger = Color(0xFFFF6B6B)
val Info = Color(0xFF4DB6FF)

// Light theme companion (for light mode)
val Paper = Color(0xFFF7F5EF)
val PaperAlt = Color(0xFFEFEBE0)
val Ink = Color(0xFF1A1A1A)
