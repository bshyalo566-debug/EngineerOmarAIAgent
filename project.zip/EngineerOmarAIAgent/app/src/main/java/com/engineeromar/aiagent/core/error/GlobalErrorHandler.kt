package com.engineeromar.aiagent.core.error

import com.engineeromar.aiagent.core.logging.Logger
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Global error handler. Installs a JVM uncaught-exception handler that:
 *  - logs the full stack trace to file,
 *  - re-delegates to the default Android handler (so normal crash dialogs still fire).
 *
 * App-level expected errors should flow through [Result] / [AppError] and never
 * reach here — this is the safety net for programmer errors.
 */
@Singleton
class GlobalErrorHandler @Inject constructor() {

    fun install() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Logger.e("Crash") { "Uncaught on ${thread.name}: ${throwable.message}" }
            // Delegate so the OS still reports the crash.
            previous?.uncaughtException(thread, throwable)
        }
        Logger.i("ErrorHandler") { "Global crash handler installed" }
    }
}
