package com.engineeromar.aiagent.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Long-term memory unit. The Agent stores facts, preferences, and recurring
 * patterns here, scoped per [scope] so retrieval is fast and relevant.
 */
@Entity(
    tableName = "memories",
    indices = [Index("scope"), Index("createdAt"), Index("importance")],
)
data class MemoryEntity(
    @PrimaryKey val id: String,
    val scope: String,              // global | project:<id> | user
    val category: String,           // preference | fact | pattern | command
    val content: String,
    val importance: Int,            // 1..5 (decay/relevance ranking)
    val embedding: ByteArray? = null,
    val createdAt: Long,
    val lastAccessedAt: Long,
    val accessCount: Int = 0,
) {
    override fun equals(other: Any?): Boolean = other is MemoryEntity && other.id == id
    override fun hashCode(): Int = id.hashCode()
}
