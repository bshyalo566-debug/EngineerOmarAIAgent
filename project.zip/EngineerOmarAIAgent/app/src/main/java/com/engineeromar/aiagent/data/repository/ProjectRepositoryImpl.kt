package com.engineeromar.aiagent.data.repository

import com.engineeromar.aiagent.core.logging.Logger
import com.engineeromar.aiagent.data.local.dao.ProjectDao
import com.engineeromar.aiagent.data.mapper.toDomain
import com.engineeromar.aiagent.data.mapper.toEntity
import com.engineeromar.aiagent.domain.model.Project
import com.engineeromar.aiagent.domain.model.ProjectStatus
import com.engineeromar.aiagent.domain.repository.ProjectRepository
import com.engineeromar.aiagent.domain.util.Result
import com.engineeromar.aiagent.domain.util.result
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Singleton
class ProjectRepositoryImpl @Inject constructor(
    private val dao: ProjectDao,
) : ProjectRepository {

    override fun observeProjects(): Flow<List<Project>> =
        dao.observeAll().map { rows -> rows.map { it.toDomain() } }

    override suspend fun getProject(id: String): Project? = dao.getById(id)?.toDomain()

    override suspend fun search(query: String): List<Project> =
        dao.search(query).map { it.toDomain() }

    override suspend fun create(project: Project): Project {
        dao.upsert(project.toEntity())
        Logger.i("ProjectRepo") { "Created project ${project.name} (${project.id})" }
        return project
    }

    override suspend fun update(project: Project) {
        dao.update(project.copy(updatedAt = System.currentTimeMillis()).toEntity())
    }

    override suspend fun setStatus(id: String, status: ProjectStatus) {
        dao.setStatus(id, status.name.lowercase(), System.currentTimeMillis())
    }

    override suspend fun delete(project: Project) {
        dao.delete(project.toEntity())
        Logger.w("ProjectRepo") { "Deleted project ${project.name}" }
    }
}
