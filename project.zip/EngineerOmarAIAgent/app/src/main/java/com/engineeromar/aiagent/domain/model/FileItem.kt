package com.engineeromar.aiagent.domain.model

import java.util.Date

/**
 * Pure domain representation of a filesystem entry surfaced by the File Manager.
 * Decoupled from [java.io.File] so the domain layer stays Android-free and
 * unit-testable. Directory children are not stored here — the repository
 * resolves them on demand to keep memory bounded.
 */
data class FileItem(
    val path: String,
    val name: String,
    val extension: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModified: Date,
    val isHidden: Boolean,
    val mimeType: String,
    val isFavorite: Boolean = false,
    val lastOpenedAt: Date? = null,
) {
    /** Human-readable size (B / KB / MB / GB). */
    val formattedSize: String
        get() = when {
            sizeBytes < 1024 -> "$sizeBytes B"
            sizeBytes < 1024 * 1024 -> "%.1f KB".format(sizeBytes / 1024.0)
            sizeBytes < 1024 * 1024 * 1024 -> "%.1f MB".format(sizeBytes / (1024.0 * 1024))
            else -> "%.2f GB".format(sizeBytes / (1024.0 * 1024 * 1024))
        }
}

/** Operation result with the affected paths so the UI can refresh precisely. */
data class FileOperationResult(
    val success: Boolean,
    val message: String,
    val affected: List<String> = emptyList(),
)

enum class SortOrder { NAME_ASC, NAME_DESC, SIZE_ASC, SIZE_DESC, MODIFIED_DESC, MODIFIED_ASC }
enum class FileViewMode { LIST, GRID, COMPACT }

/** Supported archive formats for compress / extract. */
enum class ArchiveFormat(val mime: String, val vararg extensions: String) {
    ZIP("application/zip", "zip");
}
