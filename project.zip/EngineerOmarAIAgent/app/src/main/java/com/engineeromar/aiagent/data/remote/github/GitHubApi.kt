package com.engineeromar.aiagent.data.remote.github

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.POST
import retrofit2.http.Query

interface GitHubApi {

    @GET("user")
    suspend fun currentUser(): Response<UserDto>

    @GET("user/repos")
    suspend fun listRepos(
        @Query("page") page: Int = 1,
        @Query("per_page") perPage: Int = 30,
        @Query("sort") sort: String = "updated",
    ): Response<List<RepoDto>>

    @POST("user/repos")
    suspend fun createRepo(@Body body: CreateRepoDto): Response<RepoDto>

    @GET("repos/{owner}/{repo}")
    suspend fun getRepo(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
    ): Response<RepoDto>

    @GET("repos/{owner}/{repo}/commits")
    suspend fun listCommits(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("sha") sha: String? = null,
    ): Response<List<CommitDto>>

    @GET("repos/{owner}/{repo}/pulls")
    suspend fun listPulls(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("state") state: String = "open",
    ): Response<List<PullDto>>

    @GET("repos/{owner}/{repo}/issues")
    suspend fun listIssues(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("state") state: String = "open",
    ): Response<List<IssueDto>>

    @GET("repos/{owner}/{repo}/releases")
    suspend fun listReleases(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
    ): Response<List<ReleaseDto>>
}

// ── DTOs (mirror the GitHub REST schema; mapped to domain in the repo) ──────

@Serializable
data class UserDto(
    val login: String,
    val id: Long,
    @SerialName("avatar_url") val avatarUrl: String,
    @SerialName("html_url") val htmlUrl: String,
    val name: String? = null,
    val bio: String? = null,
    @SerialName("public_repos") val publicRepos: Int = 0,
    val followers: Int = 0,
)

@Serializable
data class RepoDto(
    val id: Long,
    val name: String,
    @SerialName("full_name") val fullName: String,
    val owner: OwnerDto,
    val description: String? = null,
    @SerialName("html_url") val htmlUrl: String,
    @SerialName("clone_url") val cloneUrl: String,
    val `private`: Boolean = false,
    val fork: Boolean = false,
    @SerialName("default_branch") val defaultBranch: String = "main",
    @SerialName("stargazers_count") val stars: Int = 0,
    @SerialName("forks_count") val forks: Int = 0,
    val language: String? = null,
    @SerialName("updated_at") val updatedAt: String,
)

@Serializable
data class OwnerDto(val login: String, @SerialName("avatar_url") val avatarUrl: String? = null)

@Serializable
data class CommitDto(
    val sha: String,
    val commit: CommitInfoDto,
    @SerialName("html_url") val htmlUrl: String,
) {
    @Serializable
    data class CommitInfoDto(
        val message: String,
        val author: AuthorDto,
    )
    @Serializable
    data class AuthorDto(val name: String, val date: String)
}

@Serializable
data class PullDto(
    val number: Int,
    val title: String,
    val state: String,
    val draft: Boolean = false,
    val user: OwnerDto? = null,
    val head: RefDto,
    val base: RefDto,
    @SerialName("html_url") val htmlUrl: String,
    @SerialName("updated_at") val updatedAt: String,
) {
    @Serializable data class RefDto(val ref: String)
}

@Serializable
data class IssueDto(
    val number: Int,
    val title: String,
    val state: String,
    val body: String? = null,
    val user: OwnerDto? = null,
    val labels: List<LabelDto> = emptyList(),
    @SerialName("html_url") val htmlUrl: String,
    @SerialName("updated_at") val updatedAt: String,
) {
    @Serializable data class LabelDto(val name: String)
}

@Serializable
data class ReleaseDto(
    val id: Long,
    @SerialName("tag_name") val tagName: String,
    val name: String? = null,
    val body: String? = null,
    val prerelease: Boolean = false,
    val draft: Boolean = false,
    @SerialName("html_url") val htmlUrl: String,
    @SerialName("published_at") val publishedAt: String? = null,
    val assets: List<AssetDto> = emptyList(),
) {
    @Serializable
    data class AssetDto(
        val id: Long,
        val name: String,
        @SerialName("browser_download_url") val downloadUrl: String,
        val size: Long,
        @SerialName("download_count") val downloadCount: Int = 0,
    )
}

@Serializable
data class CreateRepoDto(
    val name: String,
    val description: String? = null,
    val `private`: Boolean = false,
    @SerialName("auto_init") val autoInit: Boolean = true,
    @SerialName("gitignore_template") val gitignoreTemplate: String? = null,
)
