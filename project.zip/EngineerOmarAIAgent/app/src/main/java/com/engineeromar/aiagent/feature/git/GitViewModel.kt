package com.engineeromar.aiagent.feature.git

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.engineeromar.aiagent.core.storage.StorageDirectories
import com.engineeromar.aiagent.domain.model.GitBranch
import com.engineeromar.aiagent.domain.model.GitCommit
import com.engineeromar.aiagent.domain.model.GitRepository
import com.engineeromar.aiagent.domain.model.GitStatus
import com.engineeromar.aiagent.domain.usecase.git.GitBranchesUseCase
import com.engineeromar.aiagent.domain.usecase.git.GitCloneUseCase
import com.engineeromar.aiagent.domain.usecase.git.GitCommitUseCase
import com.engineeromar.aiagent.domain.usecase.git.GitInitUseCase
import com.engineeromar.aiagent.domain.usecase.git.GitLogUseCase
import com.engineeromar.aiagent.domain.usecase.git.GitPullUseCase
import com.engineeromar.aiagent.domain.usecase.git.GitPushUseCase
import com.engineeromar.aiagent.domain.usecase.git.GitStatusUseCase
import com.engineeromar.aiagent.domain.usecase.git.GitSummaryUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class GitViewModel @Inject constructor(
    private val storage: StorageDirectories,
    private val init: GitInitUseCase,
    private val clone: GitCloneUseCase,
    private val status: GitStatusUseCase,
    private val commit: GitCommitUseCase,
    private val push: GitPushUseCase,
    private val pull: GitPullUseCase,
    private val branches: GitBranchesUseCase,
    private val log: GitLogUseCase,
    private val summary: GitSummaryUseCase,
) : ViewModel() {

    private val _repoPath = MutableStateFlow<String?>(null)
    val repoPath: StateFlow<String?> = _repoPath.asStateFlow()

    private val _status = MutableStateFlow<GitStatus?>(null)
    val status: StateFlow<GitStatus?> = _status.asStateFlow()

    private val _summary = MutableStateFlow<GitRepository?>(null)
    val summary: StateFlow<GitRepository?> = _summary.asStateFlow()

    private val _branches = MutableStateFlow<List<GitBranch>>(emptyList())
    val branches: StateFlow<List<GitBranch>> = _branches.asStateFlow()

    private val _log = MutableStateFlow<List<GitCommit>>(emptyList())
    val logFlow: StateFlow<List<GitCommit>> = _log.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    fun openRepository(path: String) {
        _repoPath.value = path
        refreshAll()
    }

    fun initHere(name: String) = viewModelScope.launch {
        _busy.value = true
        val dir = java.io.File(storage.projectsDir, name).apply { mkdirs() }
        val res = init(dir.absolutePath)
        _message.value = (res as? com.engineeromar.aiagent.domain.util.Result.Success)?.data
            ?: "Init failed"
        if (res is com.engineeromar.aiagent.domain.util.Result.Success) openRepository(dir.absolutePath)
        _busy.value = false
    }

    fun cloneRepo(url: String, name: String) = viewModelScope.launch {
        _busy.value = true
        val dest = java.io.File(storage.projectsDir, name).absolutePath
        val res = clone(url, dest)
        _message.value = when (res) {
            is com.engineeromar.aiagent.domain.util.Result.Success -> "Cloned ${res.data.commitCount} commits"
            is com.engineeromar.aiagent.domain.util.Result.Failure -> res.error.message
        }
        if (res is com.engineeromar.aiagent.domain.util.Result.Success) openRepository(dest)
        _busy.value = false
    }

    fun commitAll(message: String) = viewModelScope.launch {
        val path = _repoPath.value ?: return@launch
        _busy.value = true
        val res = commit(path, message)
        _message.value = when (res) {
            is com.engineeromar.aiagent.domain.util.Result.Success -> "Committed ${res.data.shortHash}"
            is com.engineeromar.aiagent.domain.util.Result.Failure -> res.error.message
        }
        refreshAll(); _busy.value = false
    }

    fun push() = viewModelScope.launch {
        val path = _repoPath.value ?: return@launch
        _busy.value = true
        val res = push(path)
        _message.value = when (res) {
            is com.engineeromar.aiagent.domain.util.Result.Success -> "Pushed to origin"
            is com.engineeromar.aiagent.domain.util.Result.Failure -> res.error.message
        }
        _busy.value = false
    }

    fun pull() = viewModelScope.launch {
        val path = _repoPath.value ?: return@launch
        _busy.value = true
        val res = pull(path)
        _message.value = when (res) {
            is com.engineeromar.aiagent.domain.util.Result.Success -> "Pulled"
            is com.engineeromar.aiagent.domain.util.Result.Failure -> res.error.message
        }
        refreshAll(); _busy.value = false
    }

    private fun refreshAll() = viewModelScope.launch {
        val path = _repoPath.value ?: return@launch
        status(path).let { r -> if (r is com.engineeromar.aiagent.domain.util.Result.Success) _status.value = r.data }
        summary(path).let { r -> if (r is com.engineeromar.aiagent.domain.util.Result.Success) _summary.value = r.data }
        branches(path).let { r -> if (r is com.engineeromar.aiagent.domain.util.Result.Success) _branches.value = r.data }
        log(path).let { r -> if (r is com.engineeromar.aiagent.domain.util.Result.Success) _log.value = r.data }
    }
}
