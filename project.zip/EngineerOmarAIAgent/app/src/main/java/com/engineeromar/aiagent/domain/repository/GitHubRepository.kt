package com.engineeromar.aiagent.domain.repository

import com.engineeromar.aiagent.domain.model.CreateRepositoryInput
import com.engineeromar.aiagent.domain.model.GitHubCommit
import com.engineeromar.aiagent.domain.model.GitHubIssue
import com.engineeromar.aiagent.domain.model.GitHubPullRequest
import com.engineeromar.aiagent.domain.model.GitHubRelease
import com.engineeromar.aiagent.domain.model.GitHubRepository
import com.engineeromar.aiagent.domain.model.GitHubUser
import com.engineeromar.aiagent.domain.util.Result

/**
 * GitHub REST API contract. Authentication is a Personal Access Token stored
 * in SecureStorage; the implementation attaches it via an OkHttp interceptor.
 * All calls return typed [Result]s — network/HTTP errors map to AppError.Network.
 */
interface GitHubRepository {

    suspend fun currentUser(): Result<GitHubUser>
    suspend fun listRepositories(page: Int = 1, perPage: Int = 30): Result<List<GitHubRepository>>
    suspend fun createRepository(input: CreateRepositoryInput): Result<GitHubRepository>
    suspend fun getRepository(owner: String, repo: String): Result<GitHubRepository>
    suspend fun listCommits(owner: String, repo: String, branch: String? = null): Result<List<GitHubCommit>>
    suspend fun listPullRequests(owner: String, repo: String, state: String = "open"): Result<List<GitHubPullRequest>>
    suspend fun listIssues(owner: String, repo: String, state: String = "open"): Result<List<GitHubIssue>>
    suspend fun listReleases(owner: String, repo: String): Result<List<GitHubRelease>>
    suspend fun isTokenValid(): Result<Boolean>
}
