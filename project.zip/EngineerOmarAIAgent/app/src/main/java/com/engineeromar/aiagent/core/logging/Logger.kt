package com.engineeromar.aiagent.core.logging

/**
 * Thin semantic logger façade backed by Timber. All subsystems log through
 * this — never [android.util.Log] directly — so we own the contract and can
 * route logs to file/network/remote-crashpad uniformly.
 */
object Logger {

    fun v(tag: String, t: Throwable? = null, msg: () -> String) {
        if (t != null) timber.log.Timber.tag(tag).v(t, msg()) else timber.log.Timber.tag(tag).v(msg())
    }
    fun d(tag: String, t: Throwable? = null, msg: () -> String) {
        if (t != null) timber.log.Timber.tag(tag).d(t, msg()) else timber.log.Timber.tag(tag).d(msg())
    }
    fun i(tag: String, t: Throwable? = null, msg: () -> String) {
        if (t != null) timber.log.Timber.tag(tag).i(t, msg()) else timber.log.Timber.tag(tag).i(msg())
    }
    fun w(tag: String, t: Throwable? = null, msg: () -> String) {
        if (t != null) timber.log.Timber.tag(tag).w(t, msg()) else timber.log.Timber.tag(tag).w(msg())
    }
    fun e(tag: String, t: Throwable? = null, msg: () -> String) {
        if (t != null) timber.log.Timber.tag(tag).e(t, msg()) else timber.log.Timber.tag(tag).e(msg())
    }
}
