package com.engineeromar.aiagent.domain.usecase.project

import com.engineeromar.aiagent.domain.model.Project
import com.engineeromar.aiagent.domain.model.ProjectStatus
import com.engineeromar.aiagent.domain.repository.ProjectRepository
import java.util.UUID
import javax.inject.Inject

/**
 * Use cases are the single entry point the ViewModels use to talk to the domain.
 * Each does one thing, is injectable, and is independently unit-testable
 * (SRP + testability). Below: project lifecycle use cases.
 */

class ObserveProjectsUseCase @Inject constructor(private val repo: ProjectRepository) {
    operator fun invoke() = repo.observeProjects()
}

class GetProjectUseCase @Inject constructor(private val repo: ProjectRepository) {
    suspend operator fun invoke(id: String) = repo.getProject(id)
}

class SearchProjectsUseCase @Inject constructor(private val repo: ProjectRepository) {
    suspend operator fun invoke(query: String) = repo.search(query)
}

class CreateProjectUseCase @Inject constructor(private val repo: ProjectRepository) {
    suspend operator fun invoke(input: CreateProjectInput): Project {
        val now = System.currentTimeMillis()
        val project = Project(
            id = UUID.randomUUID().toString(),
            name = input.name.trim(),
            description = input.description.trim(),
            rootPath = input.rootPath,
            techStack = input.techStack,
            language = input.language,
            status = ProjectStatus.ACTIVE,
            repoUrl = input.repoUrl,
            createdAt = now,
            updatedAt = now,
            pinned = false,
            color = input.color,
        )
        return repo.create(project)
    }
}

class UpdateProjectUseCase @Inject constructor(private val repo: ProjectRepository) {
    suspend operator fun invoke(project: Project) = repo.update(project)
}

class ArchiveProjectUseCase @Inject constructor(private val repo: ProjectRepository) {
    suspend operator fun invoke(id: String) = repo.setStatus(id, ProjectStatus.ARCHIVED)
}

class DeleteProjectUseCase @Inject constructor(private val repo: ProjectRepository) {
    suspend operator fun invoke(project: Project) = repo.delete(project)
}

data class CreateProjectInput(
    val name: String,
    val description: String,
    val rootPath: String,
    val techStack: List<String>,
    val language: String,
    val repoUrl: String?,
    val color: Long,
)
