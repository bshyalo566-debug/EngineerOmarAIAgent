package com.engineeromar.aiagent.ai.local

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class LocalCompletionEngineTest {

    private val engine = LocalCompletionEngine()

    @Test
    fun `untrained continue returns a graceful fallback`() {
        val out = engine.complete("write some code", maxTokens = 32)
        assertThat(out).isNotEmpty()
    }

    @Test
    fun `explain produces analysis output`() {
        val out = engine.complete("explain\nfun foo() { val x = 1 }")
        assertThat(out).contains("Local analysis")
        assertThat(out).contains("Functions: 1")
    }

    @Test
    fun `review flags todo markers`() {
        val out = engine.complete("review\nval x = 1 // TODO fix this")
        assertThat(out).contains("TODO")
    }

    @Test
    fun `review flags broad exception catch`() {
        val out = engine.complete("review\ntry { } catch (e: Exception) { }")
        assertThat(out).contains("Broad exception catch")
    }

    @Test
    fun `review flags printStackTrace`() {
        val out = engine.complete("review\ne.printStackTrace()")
        assertThat(out).contains("printStackTrace")
    }

    @Test
    fun `review on clean code reports no issues`() {
        val out = engine.complete("review\nval x = 1")
        assertThat(out).contains("no obvious issues")
    }

    @Test
    fun `code completion emits a scaffold for kotlin`() {
        val out = engine.complete("fun myFunc")
        assertThat(out).contains("Generated scaffold")
    }

    @Test
    fun `training then continue produces token-based output`() {
        engine.train("the quick brown fox jumps over the lazy dog and the fox runs fast")
        val out = engine.complete("the quick", maxTokens = 10)
        assertThat(out).isNotEmpty()
    }

    @Test
    fun `explain with empty code returns nothing message`() {
        val out = engine.complete("explain")
        assertThat(out).contains("Nothing to explain")
    }
}
