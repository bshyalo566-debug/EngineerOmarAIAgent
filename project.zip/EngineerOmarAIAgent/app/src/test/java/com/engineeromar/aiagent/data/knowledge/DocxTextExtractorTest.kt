package com.engineeromar.aiagent.data.knowledge

import com.google.common.truth.Truth.assertThat
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class DocxTextExtractorTest {

    @get:Rule val tmp = TemporaryFolder()

    private val extractor = DocxTextExtractor()

    @Test
    fun `missing file returns empty`() {
        assertThat(extractor.extract(File(tmp.root, "nope.docx"))).isEmpty()
    }

    @Test
    fun `paragraph text runs are extracted with newlines`() {
        val docx = createDocx(
            "<w:p><w:r><w:t>Hello</w:t></w:r></w:p>" +
                "<w:p><w:r><w:t>World</w:t></w:r></w:p>",
        )
        val text = extractor.extract(docx)
        assertThat(text).contains("Hello")
        assertThat(text).contains("World")
        assertThat(text.split("\n").size).isAtLeast(2)
    }

    @Test
    fun `non-docx zip without document xml returns empty`() {
        val zip = File(tmp.root, "empty.docx")
        ZipOutputStream(zip.outputStream()).use { it.putNextEntry(ZipEntry("not/document.xml")); it.closeEntry() }
        assertThat(extractor.extract(zip)).isEmpty()
    }

    @Test
    fun `split text runs in same paragraph concatenate`() {
        val docx = createDocx(
            "<w:p><w:r><w:t>Eng</w:t></w:r><w:r><w:t>ineer</w:t></w:r></w:p>",
        )
        val text = extractor.extract(docx)
        assertThat(text).contains("Engineer")
    }

    private fun createDocx(documentXml: String): File {
        val zip = File(tmp.root, "test.docx")
        ZipOutputStream(zip.outputStream()).use { zos ->
            zos.putNextEntry(ZipEntry("word/document.xml"))
            zos.write(documentXml.toByteArray())
            zos.closeEntry()
        }
        return zip
    }
}
