package com.engineeromar.aiagent.ai.engine

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class IntentDetectorTest {

    private val detector = IntentDetector()

    @Test fun `commit maps to git commit`() {
        assertThat(detector.detect("please commit my changes")).isEqualTo(Intents.GIT_COMMIT)
    }

    @Test fun `generate maps to code generate`() {
        assertThat(detector.detect("write a function to parse json")).isEqualTo(Intents.GENERATE_CODE)
    }

    @Test fun `unknown defaults to qa answer`() {
        assertThat(detector.detect("what is clean architecture?")).isEqualTo(Intents.ANSWER_QUESTION)
    }

    @Test fun `open url maps correctly`() {
        assertThat(detector.detect("open the url google.com")).isEqualTo(Intents.OPEN_URL)
    }
}
