package com.engineeromar.aiagent.data.repository

import com.engineeromar.aiagent.data.knowledge.TextExtractionPipeline
import com.engineeromar.aiagent.data.local.dao.KnowledgeDao
import com.engineeromar.aiagent.data.local.dao.KnowledgeFtsDao
import com.engineeromar.aiagent.data.local.entity.KnowledgeEntity
import com.engineeromar.aiagent.domain.model.KnowledgeCategory
import com.engineeromar.aiagent.domain.model.KnowledgeFileType
import com.engineeromar.aiagent.domain.search.SemanticIndex
import com.google.common.truth.Truth.assertThat
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import java.io.File
import kotlinx.coroutines.test.runTest
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class KnowledgeRepositoryImplTest {

    @get:Rule val tmp = TemporaryFolder()

    private val dao = mockk<KnowledgeDao>(relaxed = true)
    private val ftsDao = mockk<KnowledgeFtsDao>(relaxed = true)
    private val pipeline = mockk<TextExtractionPipeline>()
    private val semantic = mockk<SemanticIndex>(relaxed = true)
    private val repo = KnowledgeRepositoryImpl(dao, ftsDao, pipeline, semantic)

    @Test
    fun `import parses, indexes and returns document`() = runTest {
        val file = tmp.newFile("notes.txt").apply { writeText("hello world") }
        coEvery { pipeline.extract(file, KnowledgeFileType.TEXT) } returns "hello world"

        val result = repo.importDocument(file.absolutePath, KnowledgeCategory.NOTES)

        assertThat(result.isSuccess()).isTrue()
        coVerify { dao.upsert(any()) }
        coVerify { ftsDao.upsert(any()) }
        coVerify { semantic.upsert(any(), any()) }
    }

    @Test
    fun `import missing file returns failure`() = runTest {
        val result = repo.importDocument("/no/such/file.txt", KnowledgeCategory.GENERAL)
        assertThat(result.isFailure()).isTrue()
    }

    @Test
    fun `delete removes from dao fts and semantic`() = runTest {
        repo.deleteDocument("d1")
        coVerify { dao.delete("d1") }
        coVerify { ftsDao.deleteByDoc("d1") }
        coVerify { semantic.remove("d1") }
    }

    @Test
    fun `rebuild rehydrates semantic index from fts`() = runTest {
        val row = com.engineeromar.aiagent.data.local.dao.FtsRow("d1", "Title", "Body")
        coEvery { ftsDao.all() } returns listOf(row)
        val result = repo.rebuildIndex()
        assertThat(result.isSuccess()).isTrue()
        coVerify { semantic.clear() }
        coVerify { semantic.upsert("d1", "Title. Body") }
    }

    @Test
    fun `getDocument returns failure for unknown id`() = runTest {
        coEvery { dao.getById("missing") } returns null
        val result = repo.getDocument("missing")
        assertThat(result.isFailure()).isTrue()
    }

    @Test
    fun `getDocument touches lastOpenedAt`() = runTest {
        val entity = sampleEntity()
        coEvery { dao.getById("d1") } returns entity
        repo.getDocument("d1")
        coVerify { dao.touch("d1", any()) }
    }

    @Test
    fun `semanticSearch ranks via semantic index`() = runTest {
        coEvery { semantic.search("kotlin", 10) } returns listOf(com.engineeromar.aiagent.domain.search.ScoredDoc("d1", 0.9f))
        coEvery { dao.getById("d1") } returns sampleEntity()
        val hits = repo.semanticSearch("kotlin")
        assertThat(hits).hasSize(1)
        assertThat(hits.first().score).isWithin(0.01f).of(0.9f)
    }

    private fun sampleEntity() = KnowledgeEntity(
        id = "d1", title = "Doc", filePath = "/x", fileType = "txt",
        category = "notes", contentText = "body", sizeBytes = 4, pageCount = 1,
        createdAt = 0, lastOpenedAt = null, tags = listOf("txt"),
    )
}
