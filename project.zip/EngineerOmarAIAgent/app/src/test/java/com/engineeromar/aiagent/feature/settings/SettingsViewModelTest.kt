package com.engineeromar.aiagent.feature.settings

import app.cash.turbine.test
import com.engineeromar.aiagent.core.config.AiProviderType
import com.engineeromar.aiagent.core.config.AppConfig
import com.engineeromar.aiagent.core.config.ConfigurationManager
import com.engineeromar.aiagent.core.config.Language
import com.engineeromar.aiagent.core.config.ThemeMode
import com.engineeromar.aiagent.core.security.SecureStorage
import com.google.common.truth.Truth.assertThat
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Before
import org.junit.Test

class SettingsViewModelTest {

    private val configManager = mockk<ConfigurationManager>(relaxed = true)
    private val secure = mockk<SecureStorage>(relaxed = true)

    private val defaultConfig = AppConfig(
        language = Language.ENGLISH,
        theme = ThemeMode.DARK,
        dynamicColor = false,
        aiProvider = AiProviderType.OPENAI,
        biometricLock = false,
        pinEnabled = false,
        performanceMode = com.engineeromar.aiagent.core.config.PerformanceMode.BALANCED,
        appVersion = "1.0.0",
    )

    @Before fun setUp() {
        Dispatchers.setMain(UnconfinedTestDispatcher())
        every { configManager.config } returns flowOf(defaultConfig)
    }

    @After fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `config is exposed as state flow`() = runTest {
        val vm = SettingsViewModel(configManager, secure)
        vm.config.test {
            assertThat(awaitItem()?.aiProvider).isEqualTo(AiProviderType.OPENAI)
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun `saveApiKey stores value when non-blank`() {
        val vm = SettingsViewModel(configManager, secure)
        vm.saveApiKey(SecureStorage.KEY_OPENAI_API_KEY, "sk-test")
        io.mockk.verify { secure.put(SecureStorage.KEY_OPENAI_API_KEY, "sk-test") }
    }

    @Test
    fun `saveApiKey removes value when blank`() {
        val vm = SettingsViewModel(configManager, secure)
        vm.saveApiKey(SecureStorage.KEY_GITHUB_PAT, "   ")
        io.mockk.verify { secure.remove(SecureStorage.KEY_GITHUB_PAT) }
    }

    @Test
    fun `apiKey reads from secure storage`() {
        every { secure.get(SecureStorage.KEY_GITHUB_PAT) } returns "ghp_xxx"
        val vm = SettingsViewModel(configManager, secure)
        assertThat(vm.apiKey(SecureStorage.KEY_GITHUB_PAT)).isEqualTo("ghp_xxx")
    }

    @Test
    fun `clearAllSecrets delegates to storage`() {
        val vm = SettingsViewModel(configManager, secure)
        vm.clearAllSecrets()
        io.mockk.verify { secure.clear() }
    }

    @Test
    fun `setLanguage updates configuration`() = runTest {
        val vm = SettingsViewModel(configManager, secure)
        vm.setLanguage(Language.ARABIC)
        coEvery { configManager.update(any()) } returns Unit
        io.mockk.coVerify { configManager.update(any()) }
    }
}
