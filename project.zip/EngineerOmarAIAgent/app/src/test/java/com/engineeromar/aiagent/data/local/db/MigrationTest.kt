package com.engineeromar.aiagent.data.local.db

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.google.common.truth.Truth.assertThat
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Verifies the Room database opens cleanly at the declared version and that
 * every registered DAO is reachable. Migration correctness is exercised via
 * Room's MigrationTestHelper against exported JSON schemas in a real build
 * (schema files are emitted by the `room.schemaLocation` KSP arg).
 *
 * Runs on the JVM via Robolectric so it lives under `unitTest` (no emulator).
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class AppDatabaseTest {

    private lateinit var db: AppDatabase

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() { db.close() }

    @Test
    fun `all DAO accessors are wired`() {
        assertThat(db.projectDao()).isNotNull()
        assertThat(db.conversationDao()).isNotNull()
        assertThat(db.messageDao()).isNotNull()
        assertThat(db.knowledgeDao()).isNotNull()
        assertThat(db.knowledgeFtsDao()).isNotNull()
        assertThat(db.commandLogDao()).isNotNull()
        assertThat(db.memoryDao()).isNotNull()
        assertThat(db.fileItemDao()).isNotNull()
    }

    @Test
    fun `knowledge FTS upsert then search returns the doc`() = runTest {
        val fts = db.knowledgeFtsDao()
        fts.upsert(
            com.engineeromar.aiagent.data.local.entity.KnowledgeFtsEntity(
                docId = "d1", title = "Kotlin Coroutines", body = "async flow channel",
            ),
        )
        val ids = fts.searchDocIds("coroutines", 10)
        assertThat(ids).contains("d1")
    }

    @Test
    fun `version constant matches entity count expectation`() {
        // Bumping the entity list MUST bump VERSION and add a migration.
        assertThat(AppDatabase.VERSION).isAtLeast(2)
    }
}
