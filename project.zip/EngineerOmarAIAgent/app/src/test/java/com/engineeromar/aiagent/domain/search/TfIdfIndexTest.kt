package com.engineeromar.aiagent.domain.search

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class TfIdfIndexTest {

    @Test
    fun `empty index returns no results`() {
        val index = TfIdfIndex()
        assertThat(index.search("anything", 10)).isEmpty()
        assertThat(index.size()).isEqualTo(0)
    }

    @Test
    fun `upsert then search ranks matching doc first`() {
        val index = TfIdfIndex()
        index.upsert("d1", "android kotlin compose viewmodel clean architecture")
        index.upsert("d2", "python data science pandas numpy")

        val results = index.search("kotlin", 5)
        assertThat(results).isNotEmpty()
        assertThat(results.first().documentId).isEqualTo("d1")
    }

    @Test
    fun `repeated terms boost document relevance`() {
        val index = TfIdfIndex()
        index.upsert("frequent", "compose compose compose viewmodel viewmodel")
        index.upsert("sparse", "compose once")

        val results = index.search("compose", 5)
        assertThat(results.first().documentId).isEqualTo("frequent")
    }

    @Test
    fun `remove deletes document from index`() {
        val index = TfIdfIndex()
        index.upsert("d1", "android kotlin")
        index.upsert("d2", "android java")
        index.remove("d1")

        val results = index.search("kotlin", 5)
        assertThat(results.any { it.documentId == "d1" }).isFalse()
        assertThat(index.size()).isEqualTo(1)
    }

    @Test
    fun `clear empties the index`() {
        val index = TfIdfIndex()
        index.upsert("d1", "one two three")
        index.upsert("d2", "four five six")
        index.clear()
        assertThat(index.size()).isEqualTo(0)
        assertThat(index.search("one", 5)).isEmpty()
    }

    @Test
    fun `stopwords are ignored during tokenisation`() {
        val index = TfIdfIndex()
        index.upsert("d1", "the android and kotlin")
        // Searching for a stopword yields nothing.
        assertThat(index.search("the", 5)).isEmpty()
        assertThat(index.search("android", 5)).isNotEmpty()
    }

    @Test
    fun `arabic text is tokenised and searchable`() {
        val index = TfIdfIndex()
        index.upsert("ar", "هذا نص باللغة العربية للاختبار")
        assertThat(index.search("العربية", 5).firstOrNull()?.documentId).isEqualTo("ar")
    }

    @Test
    fun `replace upsert overwrites previous content`() {
        val index = TfIdfIndex()
        index.upsert("d1", "android kotlin")
        index.upsert("d1", "python django")
        // Old term should no longer match.
        assertThat(index.search("kotlin", 5)).isEmpty()
        assertThat(index.search("python", 5)).isNotEmpty()
    }

    @Test
    fun `query with no matching terms returns empty`() {
        val index = TfIdfIndex()
        index.upsert("d1", "android kotlin")
        assertThat(index.search("quantum", 5)).isEmpty()
    }

    @Test
    fun `limit caps the number of results`() {
        val index = TfIdfIndex()
        repeat(10) { i -> index.upsert("d$i", "shared term document number $i") }
        assertThat(index.search("shared", 3)).hasSize(3)
    }
}
