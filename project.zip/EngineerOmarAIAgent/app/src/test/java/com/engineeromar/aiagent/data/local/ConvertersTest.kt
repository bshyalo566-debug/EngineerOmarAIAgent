package com.engineeromar.aiagent.data.local

import com.google.common.truth.Truth.assertThat
import java.util.Date
import org.junit.Test

class ConvertersTest {

    private val converters = Converters()

    @Test
    fun `date round-trips through timestamp`() {
        val date = Date(1_700_000_000_000L)
        val back = converters.fromTimestamp(converters.dateToTimestamp(date))
        assertThat(back?.time).isEqualTo(date.time)
    }

    @Test
    fun `null date maps to null timestamp`() {
        assertThat(converters.dateToTimestamp(null)).isNull()
        assertThat(converters.fromTimestamp(null)).isNull()
    }

    @Test
    fun `list round-trips through string`() {
        val list = listOf("Android", "Kotlin", "Compose")
        val encoded = converters.stringListToString(list)
        val back = converters.stringToStringList(encoded)
        assertThat(back).isEqualTo(list)
    }

    @Test
    fun `null or empty list yields empty`() {
        assertThat(converters.stringToStringList(null)).isEmpty()
        assertThat(converters.stringToStringList("")).isEmpty()
    }

    @Test
    fun `empty list encodes to empty string`() {
        assertThat(converters.stringListToString(emptyList())).isEmpty()
    }

    @Test
    fun `single-element list round-trips`() {
        val back = converters.stringToStringList(converters.stringListToString(listOf("only")))
        assertThat(back).containsExactly("only")
    }
}
