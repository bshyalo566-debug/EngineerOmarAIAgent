package com.engineeromar.aiagent.core.error

import com.google.common.truth.Truth.assertThat
import java.io.IOException
import java.net.UnknownHostException
import org.junit.Test

class AppErrorTest {

    @Test
    fun `toAppError maps IOException to Network`() {
        val error = IOException("broken pipe").toAppError()
        assertThat(error).isInstanceOf(AppError.Network::class.java)
    }

    @Test
    fun `toAppError maps UnknownHostException to Network`() {
        val error = UnknownHostException().toAppError()
        assertThat(error).isInstanceOf(AppError.Network::class.java)
    }

    @Test
    fun `toAppError maps SecurityException to Security`() {
        val error = SecurityException("nope").toAppError()
        assertThat(error).isInstanceOf(AppError.Security::class.java)
    }

    @Test
    fun `toAppError maps unknown throwable to Unknown`() {
        val error = IllegalStateException("boom").toAppError()
        assertThat(error).isInstanceOf(AppError.Unknown::class.java)
    }

    @Test
    fun `toAppError is idempotent on AppError`() {
        val original = AppError.Validation("field", "bad")
        val mapped = (original as Throwable).toAppError()
        assertThat(mapped).isSameInstanceAs(original)
    }

    @Test
    fun `permission error carries missing permissions`() {
        val error = AppError.Permission(listOf("RECORD_AUDIO"), "missing")
        assertThat(error.permissions).containsExactly("RECORD_AUDIO")
    }

    @Test
    fun `AiProvider carries code`() {
        val error = AppError.AiProvider("rate limited", code = "429")
        assertThat(error.code).isEqualTo("429")
    }
}
