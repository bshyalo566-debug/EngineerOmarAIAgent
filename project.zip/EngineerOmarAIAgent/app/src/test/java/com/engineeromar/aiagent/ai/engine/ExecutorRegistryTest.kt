package com.engineeromar.aiagent.ai.engine

import com.google.common.truth.Truth.assertThat
import io.mockk.mockk
import org.junit.Test

class ExecutorRegistryTest {

    private val one = mockk<Executor>()
    private val two = mockk<Executor>()

    @Test
    fun `executorFor returns null for unknown intent`() {
        val registry = ExecutorRegistry(emptyMap())
        assertThat(registry.executorFor(Intents.OPEN_URL)).isNull()
    }

    @Test
    fun `executorFor resolves by intent id`() {
        val registry = ExecutorRegistry(mapOf("automation.open_url" to one))
        assertThat(registry.executorFor(Intents.OPEN_URL)).isSameInstanceAs(one)
    }

    @Test
    fun `all exposes every registered executor`() {
        val registry = ExecutorRegistry(
            mapOf("automation.open_url" to one, "git.commit" to two),
        )
        assertThat(registry.all()).containsExactly(one, two)
    }
}

class VerifierTest {

    private val verifier = Verifier()

    @Test
    fun `verifier delegates to result success flag`() {
        val ok = ExecutionResult(true, "ok")
        val bad = ExecutionResult(false, "nope")
        assertThat(verifier.verify(Intents.UNKNOWN, ExecutionPlan(Intents.UNKNOWN, emptyList()), ok)).isTrue()
        assertThat(verifier.verify(Intents.UNKNOWN, ExecutionPlan(Intents.UNKNOWN, emptyList()), bad)).isFalse()
    }
}
