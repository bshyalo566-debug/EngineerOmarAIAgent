package com.engineeromar.aiagent.ai.engine

import com.engineeromar.aiagent.core.permission.PermissionManager
import com.engineeromar.aiagent.data.local.dao.CommandLogDao
import com.engineeromar.aiagent.domain.util.Result
import com.google.common.truth.Truth.assertThat
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import org.junit.Test

class CommandEngineTest {

    private val intentDetector = mockk<IntentDetector>()
    private val taskPlanner = mockk<TaskPlanner>()
    private val permissionManager = mockk<PermissionManager>()
    private val registry = mockk<ExecutorRegistry>()
    private val verifier = mockk<Verifier>()
    private val logDao = mockk<CommandLogDao>(relaxed = true)
    private val json = Json { ignoreUnknownKeys = true }

    private val engine = CommandEngine(
        intentDetector, taskPlanner, permissionManager, registry, verifier, logDao, json,
    )

    @Test
    fun `fails fast with clear error when permission missing`() = runTest {
        every { intentDetector.detect(any()) } returns Intents.GIT_PUSH
        coEvery { taskPlanner.plan(any(), any()) } returns ExecutionPlan(Intents.GIT_PUSH, listOf("step"))
        every { permissionManager.validate(any()) } returns
            Result.Failure(com.engineeromar.aiagent.core.error.AppError.Permission(listOf("p"), "nope"))

        val report = engine.execute("push my code")

        assertThat(report.status).isEqualTo(com.engineeromar.aiagent.domain.model.CommandStatus.FAILED)
        assertThat(report.verificationPassed).isFalse()
    }

    @Test
    fun `succeeds end-to-end when executor passes verification`() = runTest {
        val intent = Intents.GENERATE_CODE
        every { intentDetector.detect(any()) } returns intent
        coEvery { taskPlanner.plan(any(), any()) } returns ExecutionPlan(intent, listOf("s1", "s2"))
        every { permissionManager.validate(any()) } returns Result.Success(Unit)
        val executor = mockk<Executor>()
        coEvery { executor.execute(any()) } returns ExecutionResult(true, "done", listOf("artifact"))
        every { registry.executorFor(any()) } returns executor
        every { verifier.verify(any(), any(), any()) } returns true

        val report = engine.execute("generate a kotlin function")

        assertThat(report.status).isEqualTo(com.engineeromar.aiagent.domain.model.CommandStatus.SUCCESS)
        assertThat(report.plan).containsExactly("s1", "s2")
    }
}
