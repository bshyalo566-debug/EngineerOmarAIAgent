package com.engineeromar.aiagent.ai.engine

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class TaskPlannerTest {

    private val planner = TaskPlanner()

    @Test
    fun `generate code plan has ordered steps`() {
        val plan = planner.plan(Intents.GENERATE_CODE, "write a kotlin function")
        assertThat(plan.steps).isNotEmpty()
        assertThat(plan.intent).isEqualTo(Intents.GENERATE_CODE)
    }

    @Test
    fun `review code plan includes summarise step`() {
        val plan = planner.plan(Intents.REVIEW_CODE, "review my code")
        assertThat(plan.steps.any { it.contains("issue", ignoreCase = true) }).isTrue()
    }

    @Test
    fun `git commit plan includes compose message step`() {
        val plan = planner.plan(Intents.GIT_COMMIT, "commit changes")
        assertThat(plan.steps.any { it.contains("message", ignoreCase = true) }).isTrue()
    }

    @Test
    fun `unknown intent delegates to agent`() {
        val plan = planner.plan(Intents.ANSWER_QUESTION, "what is kotlin")
        assertThat(plan.steps.first()).contains("Delegate")
    }

    @Test
    fun `plan preserves intent reference`() {
        val intent = Intents.FILE_SEARCH
        val plan = planner.plan(intent, "search files")
        assertThat(plan.intent).isSameInstanceAs(intent)
    }
}
