package com.engineeromar.aiagent.feature.editor.search

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class FindReplaceEngineTest {

    private val engine = FindReplaceEngine()

    @Test
    fun `empty query returns no matches`() {
        assertThat(engine.find("hello world", "")).isEmpty()
    }

    @Test
    fun `case-insensitive match is found`() {
        val matches = engine.find("Hello HELLO hello", "hello")
        assertThat(matches).hasSize(3)
    }

    @Test
    fun `case-sensitive match excludes different case`() {
        val matches = engine.find("Hello hello", "Hello", ignoreCase = false)
        assertThat(matches).hasSize(1)
        assertThat(matches.first().start).isEqualTo(0)
    }

    @Test
    fun `match line and column are one-based`() {
        val src = "line one\nline two\nfind me"
        val match = engine.find(src, "find me").first()
        assertThat(match.line).isEqualTo(3)
        assertThat(match.column).isEqualTo(1)
    }

    @Test
    fun `whole word mode excludes substrings`() {
        val matches = engine.find("classification class", "class", wholeWord = true)
        assertThat(matches).hasSize(1)
        assertThat(matches.first().start).isEqualTo("classification ".length)
    }

    @Test
    fun `regex mode matches patterns`() {
        val matches = engine.find("abc123def456", "\\d+", regex = true)
        assertThat(matches).hasSize(2)
    }

    @Test
    fun `invalid regex returns empty list`() {
        assertThat(engine.find("abc", "(invalid", regex = true)).isEmpty()
    }

    @Test
    fun `replaceAll substitutes all literal occurrences`() {
        val out = engine.replaceAll("foo bar foo", "foo", "baz", ignoreCase = true, wholeWord = false, regex = false)
        assertThat(out).isEqualTo("baz bar baz")
    }

    @Test
    fun `replaceAll with regex substitutes matches`() {
        val out = engine.replaceAll("a1 b2 c3", "\\d", "0", ignoreCase = false, wholeWord = false, regex = true)
        assertThat(out).isEqualTo("a0 b0 c0")
    }

    @Test
    fun `no match returns empty`() {
        assertThat(engine.find("hello", "world")).isEmpty()
    }
}
