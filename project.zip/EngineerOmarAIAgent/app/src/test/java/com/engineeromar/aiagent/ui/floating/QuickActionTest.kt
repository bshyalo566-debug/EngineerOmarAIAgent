package com.engineeromar.aiagent.ui.floating

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class QuickActionTest {

    @Test
    fun `defaults include explain review commit format`() {
        val labels = QuickAction.defaults.map { it.label }
        assertThat(labels).containsAtLeast("Explain", "Review", "Commit", "Format")
    }

    @Test
    fun `every default has a non-blank request`() {
        QuickAction.defaults.forEach { action ->
            assertThat(action.request.isNotBlank()).isTrue()
        }
    }

    @Test
    fun `custom QuickAction carries its data`() {
        val action = QuickAction("Deploy", "deploy the app")
        assertThat(action.label).isEqualTo("Deploy")
        assertThat(action.request).isEqualTo("deploy the app")
    }
}
