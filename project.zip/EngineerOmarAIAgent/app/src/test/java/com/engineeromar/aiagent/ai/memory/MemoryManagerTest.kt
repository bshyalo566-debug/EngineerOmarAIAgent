package com.engineeromar.aiagent.ai.memory

import com.engineeromar.aiagent.data.local.dao.MemoryDao
import com.engineeromar.aiagent.data.local.entity.MemoryEntity
import com.engineeromar.aiagent.domain.model.MemoryScope
import com.google.common.truth.Truth.assertThat
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import org.junit.Test

class MemoryManagerTest {

    private val dao = mockk<MemoryDao>(relaxed = true)
    private val manager = MemoryManager(dao)

    @Test
    fun `remember persists an entity and returns an id`() = runTest {
        val id = manager.remember(MemoryScope.USER, "preference", "prefers dark mode", importance = 4)
        assertThat(id).isNotEmpty()
        coVerify { dao.upsert(match { it.content == "prefers dark mode" && it.importance == 4 }) }
    }

    @Test
    fun `importance is clamped to 1-5`() = runTest {
        manager.remember(MemoryScope.GLOBAL, "fact", "x", importance = 99)
        coVerify { dao.upsert(match { it.importance == 5 }) }
        manager.remember(MemoryScope.GLOBAL, "fact", "x", importance = -3)
        coVerify { dao.upsert(match { it.importance == 1 }) }
    }

    @Test
    fun `recall touches each returned memory`() = runTest {
        val entity = MemoryEntity(
            id = "m1", scope = "user", category = "preference", content = "dark mode",
            importance = 3, createdAt = 0, lastAccessedAt = 0, accessCount = 0,
        )
        coEvery { dao.topForScope("user", 8) } returns listOf(entity)
        val result = manager.recall(MemoryScope.USER)
        assertThat(result).hasSize(1)
        coVerify { dao.touch("m1", any()) }
    }

    @Test
    fun `recall empty scope yields empty context block`() = runTest {
        coEvery { dao.topForScope("global", 8) } returns emptyList()
        assertThat(manager.contextBlock(MemoryScope.GLOBAL)).isEqualTo("No prior context.")
    }

    @Test
    fun `contextBlock joins memories`() = runTest {
        val e1 = MemoryEntity("a", "global", "fact", "uses Kotlin", 3, 0, 0, 0)
        coEvery { dao.topForScope("global", 8) } returns listOf(e1)
        val block = manager.contextBlock(MemoryScope.GLOBAL)
        assertThat(block).contains("uses Kotlin")
        assertThat(block).contains("(fact)")
    }

    @Test
    fun `forget deletes by id`() = runTest {
        manager.forget("m1")
        coVerify { dao.delete("m1") }
    }

    @Test
    fun `search delegates to dao`() = runTest {
        coEvery { dao.search(any()) } returns emptyList()
        manager.search("kotlin")
        coVerify { dao.search("kotlin") }
    }

    @Test
    fun `MemoryScope project prefix encodes id`() {
        assertThat(MemoryScope.project("p1").raw).isEqualTo("project:p1")
    }
}
