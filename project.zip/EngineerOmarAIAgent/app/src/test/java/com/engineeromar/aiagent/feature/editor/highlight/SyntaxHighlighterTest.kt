package com.engineeromar.aiagent.feature.editor.highlight

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class SyntaxHighlighterTest {

    private val highlighter = SyntaxHighlighter()

    @Test
    fun `empty input yields no tokens`() {
        assertThat(highlighter.tokenize("", CodeLanguage.KOTLIN)).isEmpty()
    }

    @Test
    fun `every character is covered by exactly one token`() {
        val source = "val x = 42"
        val tokens = highlighter.tokenize(source, CodeLanguage.KOTLIN)
        val covered = tokens.sumOf { it.end - it.start }
        assertThat(covered).isEqualTo(source.length)
    }

    @Test
    fun `kotlin keyword is classified`() {
        val tokens = highlighter.tokenize("fun answer(): Int", CodeLanguage.KOTLIN)
        val funToken = tokens.first { it.text == "fun" }
        assertThat(funToken.type).isEqualTo(TokenType.KEYWORD)
    }

    @Test
    fun `string literal is classified`() {
        val tokens = highlighter.tokenize("\"hello world\"", CodeLanguage.KOTLIN)
        val stringToken = tokens.first { it.type == TokenType.STRING }
        assertThat(stringToken.text).isEqualTo("\"hello world\"")
    }

    @Test
    fun `line comment is classified`() {
        val tokens = highlighter.tokenize("// a comment\nval x = 1", CodeLanguage.KOTLIN)
        val comment = tokens.first { it.type == TokenType.COMMENT }
        assertThat(comment.text).startsWith("//")
    }

    @Test
    fun `block comment spans multiple lines`() {
        val source = "/* multi\nline\ncomment */"
        val tokens = highlighter.tokenize(source, CodeLanguage.KOTLIN)
        val comment = tokens.first { it.type == TokenType.COMMENT }
        assertThat(comment.text).contains("multi")
        assertThat(comment.text).contains("comment")
    }

    @Test
    fun `number literal is classified`() {
        val tokens = highlighter.tokenize("val n = 0xFF + 3.14", CodeLanguage.KOTLIN)
        val numbers = tokens.filter { it.type == TokenType.NUMBER }.map { it.text }
        assertThat(numbers).contains("0xFF")
        assertThat(numbers).contains("3.14")
    }

    @Test
    fun `annotation is classified`() {
        val tokens = highlighter.tokenize("@Inject lateinit", CodeLanguage.KOTLIN)
        val annotation = tokens.first { it.type == TokenType.ANNOTATION }
        assertThat(annotation.text).isEqualTo("@Inject")
    }

    @Test
    fun `capitalised identifier is classified as type`() {
        val tokens = highlighter.tokenize("val user: User", CodeLanguage.KOTLIN)
        val userType = tokens.first { it.text == "User" }
        assertThat(userType.type).isEqualTo(TokenType.TYPE)
    }

    @Test
    fun `python uses hash comment`() {
        val tokens = highlighter.tokenize("x = 1 # comment", CodeLanguage.PYTHON)
        assertThat(tokens.any { it.type == TokenType.COMMENT && it.text.startsWith("#") }).isTrue()
    }

    @Test
    fun `javascript template literal is classified`() {
        val tokens = highlighter.tokenize("const s = `hello`", CodeLanguage.JAVASCRIPT)
        assertThat(tokens.any { it.type == TokenType.STRING && it.text.startsWith("`") }).isTrue()
    }

    @Test
    fun `unknown extension falls back to plaintext without crashing`() {
        val tokens = highlighter.tokenize("anything goes here 123", CodeLanguage.PLAINTEXT)
        assertThat(tokens.sumOf { it.end - it.start }).isEqualTo("anything goes here 123".length)
    }

    @Test
    fun `CodeLanguage forExtension maps known extensions`() {
        assertThat(CodeLanguage.forExtension("kt")).isEqualTo(CodeLanguage.KOTLIN)
        assertThat(CodeLanguage.forExtension("py")).isEqualTo(CodeLanguage.PYTHON)
        assertThat(CodeLanguage.forExtension("md")).isEqualTo(CodeLanguage.MARKDOWN)
        assertThat(CodeLanguage.forExtension("unknown")).isEqualTo(CodeLanguage.PLAINTEXT)
    }
}
