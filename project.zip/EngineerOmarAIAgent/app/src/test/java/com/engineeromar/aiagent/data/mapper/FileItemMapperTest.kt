package com.engineeromar.aiagent.data.mapper

import com.engineeromar.aiagent.domain.model.FileItem
import com.google.common.truth.Truth.assertThat
import java.io.File
import java.util.Date
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class FileItemMapperTest {

    @get:Rule val tmp = TemporaryFolder()

    @Test
    fun `file toDomain maps name extension and size`() {
        val file = tmp.newFile("Main.kt").apply { writeText("fun main() {}") }
        val domain = file.toDomain()
        assertThat(domain.name).isEqualTo("Main.kt")
        assertThat(domain.extension).isEqualTo("kt")
        assertThat(domain.isDirectory).isFalse()
        assertThat(domain.sizeBytes).isGreaterThan(0L)
    }

    @Test
    fun `directory has empty extension`() {
        val dir = tmp.newFolder("subdir")
        val domain = dir.toDomain()
        assertThat(domain.extension).isEmpty()
        assertThat(domain.isDirectory).isTrue()
        assertThat(domain.sizeBytes).isEqualTo(0L)
    }

    @Test
    fun `hidden file is marked`() {
        val file = tmp.newFile(".gitignore")
        assertThat(file.toDomain().isHidden).isTrue()
    }

    @Test
    fun `formattedSize scales correctly`() {
        val bytes = FileItem("p", "n", "txt", false, 500L, Date(), false, "text/plain")
        assertThat(bytes.formattedSize).isEqualTo("500 B")
        val kb = bytes.copy(sizeBytes = 2048L)
        assertThat(kb.formattedSize).contains("KB")
        val mb = bytes.copy(sizeBytes = 5L * 1024 * 1024)
        assertThat(mb.formattedSize).contains("MB")
    }

    @Test
    fun `mime is folder for directories`() {
        val dir = tmp.newFolder("d")
        assertThat(dir.toDomain().mimeType).isEqualTo("resource/folder")
    }

    @Test
    fun `known extensions resolve to expected mime`() {
        val pdf = tmp.newFile("doc.pdf").toDomain()
        assertThat(pdf.mimeType).isEqualTo("application/pdf")
        val json = tmp.newFile("c.json").toDomain()
        assertThat(json.mimeType).isEqualTo("application/json")
    }
}
