package com.engineeromar.aiagent.domain.model

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class DomainModelTest {

    @Test
    fun `FileItem formattedSize scales across units`() {
        val item = FileItem("p", "n", "txt", false, 0L, java.util.Date(), false, "text/plain")
        assertThat(item.copy(sizeBytes = 500).formattedSize).isEqualTo("500 B")
        assertThat(item.copy(sizeBytes = 2_048).formattedSize).contains("KB")
        assertThat(item.copy(sizeBytes = 2_097_152).formattedSize).contains("MB")
    }

    @Test
    fun `TechStack contains every supported language`() {
        assertThat(TechStack.ALL).containsAtLeast(
            TechStack.ANDROID, TechStack.KOTLIN, TechStack.JAVA, TechStack.FLUTTER,
            TechStack.REACT, TechStack.REACT_NATIVE, TechStack.NEXT_JS, TechStack.NODE_JS,
            TechStack.PYTHON, TechStack.HTML, TechStack.CSS, TechStack.JAVASCRIPT, TechStack.TYPESCRIPT,
        )
    }

    @Test
    fun `Project status enum covers lifecycle`() {
        assertThat(ProjectStatus.entries).containsExactly(
            ProjectStatus.ACTIVE, ProjectStatus.ARCHIVED, ProjectStatus.DELETED,
        )
    }

    @Test
    fun `VoiceLanguage supported set includes Arabic and English`() {
        assertThat(VoiceLanguage.SUPPORTED.map { it.tag }).containsAtLeast("en-US", "ar-SA")
    }

    @Test
    fun `MemoryScope project encodes id with prefix`() {
        assertThat(MemoryScope.project("abc").raw).isEqualTo("project:abc")
    }

    @Test
    fun `KnowledgeFileType ext values are lowercase`() {
        KnowledgeFileType.entries.forEach {
            assertThat(it.ext).isEqualTo(it.ext.lowercase())
        }
    }

    @Test
    fun `PluginPermission covers every capability exposed by PluginContext`() {
        assertThat(PluginPermission.entries).containsAtLeast(
            PluginPermission.NETWORK,
            PluginPermission.FILE_READ,
            PluginPermission.FILE_WRITE,
            PluginPermission.DATABASE,
            PluginPermission.AI_PROVIDER,
            PluginPermission.CLIPBOARD,
            PluginPermission.NOTIFICATIONS,
        )
    }

    @Test
    fun `CommandStatus covers full pipeline lifecycle`() {
        assertThat(CommandStatus.entries).containsExactly(
            CommandStatus.QUEUED, CommandStatus.RUNNING,
            CommandStatus.SUCCESS, CommandStatus.FAILED, CommandStatus.CANCELLED,
        )
    }
}
