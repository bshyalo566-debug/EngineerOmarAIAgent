package com.engineeromar.aiagent.feature.agent

import com.engineeromar.aiagent.ai.agent.EngineeringAgent
import com.google.common.truth.Truth.assertThat
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Before
import org.junit.Test

class AgentViewModelTest {

    private val agent = mockk<EngineeringAgent>()

    @Before fun setUp() {
        Dispatchers.setMain(UnconfinedTestDispatcher())
    }

    @After fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `send appends user message then agent reply`() = runTest {
        coEvery { agent.ask(any(), any(), any()) } returns "Hello back"
        val vm = AgentViewModel(agent)

        vm.send("Hi Omar")

        // First line is the user's; the second is the assistant's.
        assertThat(vm.messages.value.first().fromUser).isTrue()
        assertThat(vm.messages.value.first().text).isEqualTo("Hi Omar")
        assertThat(vm.messages.value.last().fromUser).isFalse()
        assertThat(vm.messages.value.last().text).isEqualTo("Hello back")
    }

    @Test
    fun `busy flag is cleared after the reply`() = runTest {
        coEvery { agent.ask(any(), any(), any()) } returns "ok"
        val vm = AgentViewModel(agent)
        vm.send("anything")
        assertThat(vm.busy.value).isFalse()
    }

    @Test
    fun `multiple sends accumulate history`() = runTest {
        coEvery { agent.ask(any(), any(), any()) } returns "ack"
        val vm = AgentViewModel(agent)
        vm.send("one")
        vm.send("two")
        assertThat(vm.messages.value.size).isEqualTo(4) // 2 user + 2 assistant
    }
}
