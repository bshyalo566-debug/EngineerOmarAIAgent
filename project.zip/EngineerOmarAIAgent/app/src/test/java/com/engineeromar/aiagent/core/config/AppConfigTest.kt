package com.engineeromar.aiagent.core.config

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class AppConfigTest {

    @Test
    fun `default config has sensible values`() {
        val config = AppConfig()
        assertThat(config.theme).isEqualTo(ThemeMode.DARK)
        assertThat(config.language).isEqualTo(Language.ENGLISH)
        assertThat(config.aiProvider).isEqualTo(AiProviderType.OPENAI)
        assertThat(config.performanceMode).isEqualTo(PerformanceMode.BALANCED)
    }

    @Test
    fun `language enum codes are BCP-47 compatible`() {
        Language.entries.forEach {
            assertThat(it.code).matches("[a-z]{2}(-[A-Z]{2})?")
        }
    }

    @Test
    fun `arabic language is present`() {
        assertThat(Language.entries.map { it.code }).contains("ar")
    }

    @Test
    fun `theme mode covers system dark light`() {
        assertThat(ThemeMode.entries).containsExactly(
            ThemeMode.LIGHT, ThemeMode.DARK, ThemeMode.SYSTEM,
        )
    }

    @Test
    fun `ai provider includes local offline option`() {
        assertThat(AiProviderType.entries).contains(AiProviderType.LOCAL)
    }

    @Test
    fun `performance mode includes power saver`() {
        assertThat(PerformanceMode.entries).containsAtLeast(
            PerformanceMode.POWER_SAVER, PerformanceMode.BALANCED, PerformanceMode.MAX_PERFORMANCE,
        )
    }
}
