package com.engineeromar.aiagent.feature.editor.autocomplete

import com.engineeromar.aiagent.feature.editor.highlight.CodeLanguage
import com.google.common.truth.Truth.assertThat
import org.junit.Test

class AutocompleteSourceTest {

    private val source = AutocompleteSource()

    @Test
    fun `empty prefix yields no completions`() {
        assertThat(source.completionsFor("", CodeLanguage.KOTLIN, emptySet())).isEmpty()
    }

    @Test
    fun `kotlin keywords matching prefix are offered`() {
        val labels = source.completionsFor("fu", CodeLanguage.KOTLIN, emptySet()).map { it.label }
        assertThat(labels).contains("fun")
    }

    @Test
    fun `buffer identifiers are offered for reuse`() {
        val ids = setOf("userName", "userId", "userEmail")
        val labels = source.completionsFor("user", CodeLanguage.KOTLIN, ids).map { it.label }
        assertThat(labels).containsAtLeast("userName", "userId", "userEmail")
    }

    @Test
    fun `identifiers shorter than prefix are excluded`() {
        val ids = setOf("us", "user")
        val labels = source.completionsFor("user", CodeLanguage.KOTLIN, ids).map { it.label }
        assertThat(labels).contains("user")
        assertThat(labels).doesNotContain("us")
    }

    @Test
    fun `python snippet is offered for def`() {
        val labels = source.completionsFor("def", CodeLanguage.PYTHON, emptySet()).map { it.label }
        assertThat(labels).contains("def")
    }

    @Test
    fun `capitalised builtin from buffer is offered as identifier`() {
        val ids = setOf("Repository")
        val completions = source.completionsFor("Repo", CodeLanguage.KOTLIN, ids)
        assertThat(completions.map { it.label }).contains("Repository")
    }

    @Test
    fun `results are distinct by label`() {
        val ids = setOf("fun") // collides with keyword
        val completions = source.completionsFor("fun", CodeLanguage.KOTLIN, ids)
        assertThat(completions.count { it.label == "fun" }).isEqualTo(1)
    }

    @Test
    fun `plaintext yields no keyword completions but no crash`() {
        val completions = source.completionsFor("a", CodeLanguage.PLAINTEXT, emptySet())
        // No keyword set for plaintext; may still return nothing or snippets.
        assertThat(completions.size).isAtMost(50)
    }
}
