package com.engineeromar.aiagent.feature.editor.diagnostics

import com.engineeromar.aiagent.feature.editor.highlight.CodeLanguage
import com.google.common.truth.Truth.assertThat
import org.junit.Test

class DiagnosticsEngineTest {

    private val engine = DiagnosticsEngine()

    @Test
    fun `clean short code produces no diagnostics`() {
        val diags = engine.analyze("val x = 1\nval y = 2", CodeLanguage.KOTLIN)
        assertThat(diags).isEmpty()
    }

    @Test
    fun `long line is flagged as warning`() {
        val long = "x".repeat(150)
        val diags = engine.analyze(long, CodeLanguage.KOTLIN)
        assertThat(diags.any { it.rule == "line-length" }).isTrue()
    }

    @Test
    fun `trailing whitespace is flagged as info`() {
        val diags = engine.analyze("val x = 1   ", CodeLanguage.KOTLIN)
        assertThat(diags.any { it.rule == "trailing-ws" && it.severity == Severity.INFO }).isTrue()
    }

    @Test
    fun `unclosed bracket is flagged as error`() {
        val diags = engine.analyze("fun foo(: Int", CodeLanguage.KOTLIN)
        assertThat(diags.any { it.rule == "unbalanced-bracket" && it.severity == Severity.ERROR }).isTrue()
    }

    @Test
    fun `mixed tabs and spaces is flagged`() {
        val diags = engine.analyze("\t    val x = 1", CodeLanguage.KOTLIN)
        assertThat(diags.any { it.rule == "indent-mix" }).isTrue()
    }

    @Test
    fun `balanced brackets produce no bracket errors`() {
        val src = "fun foo(a: Int): List<Int> { return listOf(a) }"
        val diags = engine.analyze(src, CodeLanguage.KOTLIN)
        assertThat(diags.none { it.rule.startsWith("bracket") || it.rule == "unbalanced-bracket" }).isTrue()
    }

    @Test
    fun `brackets inside strings are ignored`() {
        val src = "val s = \"[not a bracket\""
        val diags = engine.analyze(src, CodeLanguage.KOTLIN)
        assertThat(diags.none { it.rule.contains("bracket") }).isTrue()
    }

    @Test
    fun `python does not run bracket analysis`() {
        val diags = engine.analyze("def foo(", CodeLanguage.PYTHON)
        assertThat(diags.none { it.rule.contains("bracket") }).isTrue()
    }

    @Test
    fun `diagnostic line numbers are one-based`() {
        val src = "val a = 1\nval b = 2\n" + "x".repeat(150)
        val diags = engine.analyze(src, CodeLanguage.KOTLIN)
        val longLine = diags.first { it.rule == "line-length" }
        assertThat(longLine.line).isEqualTo(3)
    }

    @Test
    fun `custom max line length is respected`() {
        val diags = engine.analyze("abcdef", CodeLanguage.KOTLIN, maxLineLength = 3)
        assertThat(diags.any { it.rule == "line-length" }).isTrue()
    }
}
