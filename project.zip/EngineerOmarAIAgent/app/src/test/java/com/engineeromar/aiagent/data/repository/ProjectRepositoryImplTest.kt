package com.engineeromar.aiagent.data.repository

import app.cash.turbine.test
import com.engineeromar.aiagent.data.local.dao.ProjectDao
import com.engineeromar.aiagent.data.local.entity.ProjectEntity
import com.engineeromar.aiagent.domain.model.Project
import com.engineeromar.aiagent.domain.model.ProjectStatus
import com.google.common.truth.Truth.assertThat
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.runTest
import org.junit.Test

class ProjectRepositoryImplTest {

    private val dao = mockk<ProjectDao>(relaxed = true)
    private val repo = ProjectRepositoryImpl(dao)

    private val sampleEntity = ProjectEntity(
        id = "p1", name = "App", description = "demo", rootPath = "/p",
        techStack = listOf("Android"), language = "Kotlin", status = "active",
        repoUrl = null, createdAt = 1, updatedAt = 2, pinned = false, color = 0xFFD4AF37,
    )

    @Test
    fun `observeProjects maps entities to domain`() = runTest {
        every { dao.observeAll() } returns MutableStateFlow(listOf(sampleEntity))
        repo.observeProjects().test {
            val list = awaitItem()
            assertThat(list).hasSize(1)
            assertThat(list.first().status).isEqualTo(ProjectStatus.ACTIVE)
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun `create persists entity`() = runTest {
        val project = Project("p2", "X", "", "/x", emptyList(), "Kotlin",
            ProjectStatus.ACTIVE, null, 0, 0, false, 0xFFD4AF37)
        repo.create(project)
        coVerify { dao.upsert(any()) }
    }
}
