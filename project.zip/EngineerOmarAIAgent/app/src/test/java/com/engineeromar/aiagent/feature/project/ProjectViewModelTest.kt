package com.engineeromar.aiagent.feature.project

import com.engineeromar.aiagent.domain.model.Project
import com.engineeromar.aiagent.domain.model.ProjectStatus
import com.engineeromar.aiagent.domain.repository.ProjectRepository
import com.engineeromar.aiagent.domain.usecase.project.ArchiveProjectUseCase
import com.engineeromar.aiagent.domain.usecase.project.CreateProjectUseCase
import com.engineeromar.aiagent.domain.usecase.project.DeleteProjectUseCase
import com.engineeromar.aiagent.domain.usecase.project.ObserveProjectsUseCase
import com.engineeromar.aiagent.domain.usecase.project.SearchProjectsUseCase
import com.engineeromar.aiagent.domain.usecase.project.CreateProjectInput
import com.google.common.truth.Truth.assertThat
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Before
import org.junit.Test

class ProjectViewModelTest {

    private val repo = mockk<ProjectRepository>(relaxed = true)
    private lateinit var vm: ProjectViewModel

    private val sampleProject = Project(
        id = "p1", name = "Sample", description = "demo",
        rootPath = "/p", techStack = listOf("Android"), language = "Kotlin",
        status = ProjectStatus.ACTIVE, repoUrl = null,
        createdAt = 0, updatedAt = 0, pinned = false, color = 0xFFD4AF37,
    )

    @Before
    fun setUp() {
        Dispatchers.setMain(UnconfinedTestDispatcher())
        coEvery { repo.observeProjects() } returns MutableStateFlow(listOf(sampleProject))
        coEvery { repo.search(any()) } returns listOf(sampleProject)
        vm = ProjectViewModel(
            ObserveProjectsUseCase(repo),
            CreateProjectUseCase(repo),
            SearchProjectsUseCase(repo),
            ArchiveProjectUseCase(repo),
            DeleteProjectUseCase(repo),
        )
    }

    @After fun tearDown() { Dispatchers.resetMain() }

    @Test
    fun `observeProjects surfaces projects`() = runTest {
        assertThat(vm.projects.value).hasSize(1)
        assertThat(vm.projects.value.first().name).isEqualTo("Sample")
    }

    @Test
    fun `onQueryChange triggers search`() = runTest {
        vm.onQueryChange("Sam")
        assertThat(vm.searchResults.value).hasSize(1)
    }

    @Test
    fun `onQueryChange with blank clears results`() = runTest {
        vm.onQueryChange("Sam")
        vm.onQueryChange("")
        assertThat(vm.searchResults.value).isEmpty()
    }

    @Test
    fun `archive delegates to use case`() = runTest {
        vm.archive(sampleProject)
        coVerify { repo.setStatus("p1", ProjectStatus.ARCHIVED) }
    }

    @Test
    fun `delete delegates to use case`() = runTest {
        vm.delete(sampleProject)
        coVerify { repo.delete(sampleProject) }
    }

    @Test
    fun `createProject passes input to use case`() = runTest {
        val input = CreateProjectInput(
            name = "New", description = "d", rootPath = "/r",
            techStack = listOf("Kotlin"), language = "Kotlin",
            repoUrl = null, color = 0xFFD4AF37,
        )
        vm.createProject(input)
        coVerify { repo.create(any()) }
    }
}
