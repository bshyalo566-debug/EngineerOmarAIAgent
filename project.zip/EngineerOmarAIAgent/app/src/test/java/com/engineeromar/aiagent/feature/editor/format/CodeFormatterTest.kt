package com.engineeromar.aiagent.feature.editor.format

import com.engineeromar.aiagent.feature.editor.highlight.CodeLanguage
import com.google.common.truth.Truth.assertThat
import org.junit.Test

class CodeFormatterTest {

    private val formatter = CodeFormatter(indentSize = 4)

    @Test
    fun `trailing whitespace is trimmed`() {
        val out = formatter.format("val x = 1   \n", CodeLanguage.KOTLIN)
        assertThat(out.lines().first()).isEqualTo("val x = 1")
    }

    @Test
    fun `result ends with single trailing newline`() {
        val out = formatter.format("val x = 1", CodeLanguage.KOTLIN)
        assertThat(out.endsWith("\n")).isTrue()
        assertThat(out.count { it == '\n' }).isEqualTo(1)
    }

    @Test
    fun `three or more blank lines collapse to two`() {
        val out = formatter.format("a\n\n\n\n\nb", CodeLanguage.KOTLIN)
        assertThat(out).doesNotContain("\n\n\n")
    }

    @Test
    fun `crlf is normalised to lf`() {
        val out = formatter.format("val x = 1\r\nval y = 2\r\n", CodeLanguage.KOTLIN)
        assertThat(out).doesNotContain("\r")
    }

    @Test
    fun `nested braces increase indentation`() {
        val out = formatter.format("fun a() {\nval x = 1\n}", CodeLanguage.KOTLIN)
        val lines = out.lines()
        // Indented body line should start with 4 spaces.
        assertThat(lines.any { it.startsWith("    val x = 1") }).isTrue()
    }

    @Test
    fun `closing brace reduces indentation on its line`() {
        val out = formatter.format("fun a() {\nval x = 1\n}", CodeLanguage.KOTLIN)
        val closing = out.lines().firstOrNull { it.trim() == "}" }
        assertThat(closing).isNotNull()
        assertThat(closing!!.startsWith(" ")).isFalse()
    }

    @Test
    fun `empty input yields empty output`() {
        assertThat(formatter.format("", CodeLanguage.KOTLIN)).isEmpty()
    }

    @Test
    fun `brackets inside strings do not affect indentation`() {
        val out = formatter.format("val s = \"{\"", CodeLanguage.KOTLIN)
        // No body line should be artificially indented.
        assertThat(out.lines().first().startsWith(" ")).isFalse()
    }
}
