# Contributing to Engineer Omar AI Agent

Thanks for considering a contribution! This document explains the workflow and
the quality bars every change must clear.

## Code of Conduct

Be respectful and constructive. Harassment, discrimination, and personal
attacks are not tolerated.

## Before you start

- Open an issue describing the change for non-trivial work — it avoids
  duplicate effort and lets us agree on the approach first.
- Check the [issue tracker](../../issues) for `good first issue` labels.

## Development setup

1. Install **JDK 17**, **Android Studio Koala+** (AGP 8.5).
2. Clone the repo and run the wrapper bootstrap:
   ```bash
   git clone <your-fork-url>
   cd EngineerOmarAIAgent
   ./bootstrap-gradle.sh     # generates gradle/wrapper/gradle-wrapper.jar
   ```
3. Open the project in Android Studio (it will pick up the Gradle wrapper).

## Architecture rules (non-negotiable)

- **Dependency direction is inward only.** `feature/` → `domain/`; `data/`
  implements `domain/`. Never import Room/Retrofit/Android from `domain/`.
- Domain returns `Result<T>`; never use exceptions for control flow.
- New feature? Mirror the existing **Project Manager** end-to-end pattern:
  domain model → repository interface → use cases → Room entity+DAO+mapper →
  repository impl (bound in `RepositoryModule`) → ViewModel → Screen →
  `Destination` + NavHost entry.
- Adding a capability to the agent? Add an `Intent` + an `Executor` and wire
  it in `ExecutorModule`. The Command Engine core must stay untouched.

## Coding standards

- Kotlin 2.0, `jvmTarget = 17`. `val`-only data classes. No wildcard imports.
- Public API gets KDoc. Keep functions short and single-purpose (SRP).
- Log via `Logger`, never `android.util.Log`. Never log secrets.
- Permission-gated actions must go through `PermissionManager.validate(...)`.

## Tests

- Every new domain/data class or use case ships with a unit test.
- Repository tests use MockK against the DAO; ViewModels use `runTest` +
  `UnconfinedTestDispatcher`.
- Run locally before pushing:
  ```bash
  ./gradlew testStandardDebugUnitTest lintStandardDebug
  ```
- Target ≥ 80% line coverage on `domain/`, `data/repository/`,
  `ai/engine/`, and `feature/editor/` (pure-logic modules).

## Commit & PR style

- Conventional Commits: `feat(agent): add code-review executor`,
  `fix(editor): debounce find`, `docs: …`, `test: …`, `refactor: …`,
  `chore: …`.
- One logical change per PR. Keep PRs reviewable (< ~600 lines where possible).
- The PR description links the issue, summarises the approach, and lists how it
  was tested.
- Screenshots/GIFs for UI changes.

## CI gates

Every PR must pass:
- `lintStandardDebug` (no new errors)
- `testStandardDebugUnitTest`
- `assembleStandardDebug`

Releases are cut by tagging `vX.Y.Z` — see [Deployment](docs/DEPLOYMENT_GUIDE.md).

## Reporting security issues

**Do not open a public issue for security problems.** Email the maintainer
privately so a fix can ship before disclosure.

## Licensing

By submitting, you agree your contribution is licensed under the project's
[Apache 2.0 license](LICENSE).
