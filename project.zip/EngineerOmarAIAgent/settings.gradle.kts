pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven("https://jitpack.io")
    }
}

rootProject.name = "EngineerOmarAIAgent"

// ------------------------------------------------------------------
// Modular architecture: each line below is a ready-to-enable module.
// Features can be split into `:feature:xxx` modules for true isolation
// and faster incremental builds. Kept as a single :app module here to
// keep the starter cohesive; promote to modules as the team scales.
// ------------------------------------------------------------------
include(":app")
// include(":core")
// include(":data")
// include(":domain")
// include(":feature:dashboard")
// include(":feature:agent")
// include(":feature:project")
// include(":feature:editor")
// include(":feature:knowledge")
// include(":feature:git")
// include(":feature:filemanager")
