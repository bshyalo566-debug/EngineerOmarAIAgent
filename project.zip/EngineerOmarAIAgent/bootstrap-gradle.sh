#!/usr/bin/env bash
#
# One-time bootstrap for the Gradle wrapper.
#
# `gradle-wrapper.jar` is a binary that cannot be committed as text. This
# script generates it (and refreshes the wrapper scripts) using either a
# locally-installed Gradle or by downloading the official Gradle
# distribution. Run it once on a clean checkout.
#
#   ./bootstrap-gradle.sh
#
set -euo pipefail

cd "$(dirname "$0")"

if command -v gradle >/dev/null 2>&1; then
  echo "✓ Found Gradle on PATH — generating wrapper."
  gradle wrapper --gradle-version 8.9 --distribution-type bin
elif [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ]; then
  echo "✓ No Gradle on PATH. Downloading Gradle 8.9 to generate the wrapper…"
  TMPDIR="$(mktemp -d)"
  trap 'rm -rf "$TMPDIR"' EXIT
  URL="https://services.gradle.org/distributions/gradle-8.9-bin.zip"
  curl -fsSL "$URL" -o "$TMPDIR/gradle.zip"
  unzip -q "$TMPDIR/gradle.zip" -d "$TMPDIR"
  "$TMPDIR/gradle-8.9/bin/gradle" wrapper --gradle-version 8.9 --distribution-type bin
else
  echo "✗ Neither gradle nor JAVA_HOME is set. Install JDK 17+ and rerun." >&2
  exit 1
fi

chmod +x gradlew
echo "✓ Gradle wrapper ready. Run ./gradlew assembleStandardRelease to build."
