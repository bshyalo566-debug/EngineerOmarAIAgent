# Folder Structure

```
EngineerOmarAIAgent/
├── settings.gradle.kts              # module graph (single :app; feature modules ready to enable)
├── build.gradle.kts                 # root — plugin declarations only
├── gradle.properties                # JVM/Gradle/AndroidX tuning
├── gradle/
│   └── libs.versions.toml           # version catalog (single source of truth)
├── .gitignore
├── README.md
├── docs/                            # full engineering documentation
│   ├── ARCHITECTURE.md
│   ├── FOLDER_STRUCTURE.md
│   ├── DATABASE_SCHEMA.md
│   ├── DEVELOPER_GUIDE.md
│   ├── DEPLOYMENT_GUIDE.md
│   ├── SECURITY.md
│   ├── TESTING.md
│   ├── USER_MANUAL.md
│   └── API_REFERENCE.md
│
└── app/
    ├── build.gradle.kts             # app module: deps, SDK, build types, KSP, Room schema export
    ├── proguard-rules.pro
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml
        │   ├── res/
        │   │   ├── values/           # strings, colors, themes
        │   │   ├── values-ar/        # Arabic localization (RTL)
        │   │   ├── drawable/         # bg_floating_bubble, icons
        │   │   └── xml/              # data_extraction_rules
        │   └── java/com/engineeromar/aiagent/
        │       ├── EngineerOmarApp.kt        # @HiltAndroidApp, logging, crash, WorkManager config
        │       ├── MainActivity.kt           # edge-to-edge, theme wiring
        │       ├── HiltTestRunner.kt         # instrumented test runner
        │       │
        │       ├── core/                     # ── cross-cutting subsystems ──
        │       │   ├── config/               # ConfigurationManager, AppConfig, enums
        │       │   ├── di/                   # AppModule, DatabaseModule, NetworkModule, RepositoryModule
        │       │   ├── error/                # AppError hierarchy, GlobalErrorHandler, Throwable.toAppError
        │       │   ├── logging/              # Logger façade, FileLogger (rotating, persistent)
        │       │   ├── permission/           # PermissionManager (single validation seam)
        │       │   ├── security/             # SecureStorage (Keystore), BiometricAuthManager
        │       │   ├── cache/                # CacheManager (LruCache + disk)
        │       │   ├── storage/              # StorageDirectories (organised local layout)
        │       │   ├── lifecycle/            # AppLifecycleObserver
        │       │   └── update/               # UpdateManager
        │       │
        │       ├── domain/                   # ── pure Kotlin, no Android ──
        │       │   ├── model/                # Project, Conversation, Knowledge, CommandLog, Memory, ...
        │       │   ├── repository/           # interfaces (ProjectRepository, ...)
        │       │   ├── usecase/              # use cases per feature (project/, ...)
        │       │   └── util/                 # Result<T> (railway-oriented)
        │       │
        │       ├── data/                     # ── implements domain ──
        │       │   ├── local/
        │       │   │   ├── db/AppDatabase.kt
        │       │   │   ├── dao/              # Project/Conversation/Message/Knowledge/CommandLog/Memory/FileItem
        │       │   │   ├── entity/           # Room entities
        │       │   │   └── Converters.kt
        │       │   ├── mapper/               # Entity ↔ Domain mappers
        │       │   └── repository/           # ProjectRepositoryImpl, ...
        │       │
        │       ├── ai/                       # ── AI subsystem ──
        │       │   ├── provider/             # AiProvider (Strategy), OpenAiProvider, AiProviderFactory
        │       │   ├── engine/               # CommandEngine pipeline + Intent/Planner/Executor/Verifier/Registry
        │       │   │   └── executors/        # CodeGenerationExecutor, KnowledgeSearchExecutor
        │       │   ├── memory/               # MemoryManager (long-term recall)
        │       │   └── agent/                # EngineeringAgent (orchestration)
        │       │
        │       ├── feature/                  # ── MVVM features (Compose) ──
        │       │   ├── dashboard/            # DashboardScreen
        │       │   ├── agent/                # AgentScreen + AgentViewModel (reference chat)
        │       │   ├── project/              # ProjectsScreen + ProjectViewModel + detail (reference feature)
        │       │   ├── knowledge/            # KnowledgeScreen
        │       │   ├── editor/               # (Code Editor — scaffold)
        │       │   ├── git/                  # (Git — scaffold)
        │       │   ├── filemanager/          # (File Manager — scaffold)
        │       │   ├── voice/                # (Voice Assistant — scaffold)
        │       │   └── settings/             # SettingsScreen
        │       │
        │       ├── ui/                       # ── shared UI ──
        │       │   ├── theme/                # Color (Luxury Black + Gold), Theme, Type
        │       │   ├── navigation/           # Destinations, AppNavigation
        │       │   └── components/           # (shared composables)
        │       │
        │       └── service/                  # ── foreground services ──
        │           ├── FloatingAssistantService.kt   # overlay bubble (SYSTEM_ALERT_WINDOW)
        │           └── CommandExecutionService.kt    # long-running command tasks
        │
        └── test/                             # ── unit tests (JVM) ──
            └── java/com/engineeromar/aiagent/
                ├── ai/engine/                # CommandEngineTest, IntentDetectorTest
                └── data/repository/          # ProjectRepositoryImplTest
```

## How to add a new feature module

1. Domain: add `model`, `repository` interface, and `usecase`.
2. Data: add `entity` + `dao`, register in `AppDatabase`, add `mapper` + repository impl, bind in `RepositoryModule`.
3. Feature: add `feature/<name>/` with `ViewModel` + `Screen`, register a `Destination`, add a `composable` in `AppNavigation`.
4. Test: unit-test the use case + repository (MockK), screen (Compose UI test).
5. Optional: split into a Gradle `:feature:<name>` module for isolation.

See [`DEVELOPER_GUIDE.md`](DEVELOPER_GUIDE.md) for a worked example.
