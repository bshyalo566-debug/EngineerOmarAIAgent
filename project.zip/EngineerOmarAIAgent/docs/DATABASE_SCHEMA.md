# Database Schema

**Engine:** Room (SQLite via AndroidX) · **DB name:** `engineer_omar.db` · **Version:** 1 · **Schema export:** `app/schemas/`

> At rest, the DB file should be wrapped with **SQLCipher** for production (see `SECURITY.md`). It lives in app-private storage so no broad file permission is required.

## ER overview

```
projects ──< conversations ──< messages
projects ──< file_items
knowledge            (standalone document index)
command_logs         (append-only audit)
memories             (long-term memory; scoped)
```

---

## `projects`
| Column | Type | Notes |
|---|---|---|
| `id` | TEXT PK | UUID |
| `name` | TEXT | |
| `description` | TEXT | |
| `rootPath` | TEXT | absolute path under `Projects/` |
| `techStack` | TEXT | delimiter-joined list (Android, Kotlin, …) |
| `language` | TEXT | primary language |
| `status` | TEXT | `active` \| `archived` \| `deleted` |
| `repoUrl` | TEXT? | optional remote |
| `createdAt` | INTEGER | epoch ms |
| `updatedAt` | INTEGER | epoch ms (indexed) |
| `pinned` | INTEGER | 0/1 |
| `color` | INTEGER | card accent |

**Indexes:** `status`, `techStack`, `updatedAt`.

## `conversations`
| Column | Type | Notes |
|---|---|---|
| `id` | TEXT PK | |
| `title` | TEXT | |
| `projectId` | TEXT? | FK → projects (ON DELETE SET NULL) |
| `scope` | TEXT | `general` \| `project` \| `knowledge` \| `code` |
| `createdAt` | INTEGER | |
| `updatedAt` | INTEGER | indexed |
| `pinned` | INTEGER | |
| `tokenCount` | INTEGER | cumulative |

**Indexes:** `projectId`, `updatedAt`.

## `messages`
| Column | Type | Notes |
|---|---|---|
| `id` | TEXT PK | |
| `conversationId` | TEXT | FK → conversations (ON DELETE CASCADE) |
| `role` | TEXT | `user` \| `assistant` \| `system` \| `tool` |
| `content` | TEXT | |
| `createdAt` | INTEGER | indexed |
| `tokensIn` / `tokensOut` | INTEGER | usage accounting |
| `model` | TEXT? | |
| `attachments` | TEXT | delimiter-joined list |
| `status` | TEXT | `ok` \| `error` \| `streaming` |

**Indexes:** `conversationId`, `createdAt`.

## `knowledge`
| Column | Type | Notes |
|---|---|---|
| `id` | TEXT PK | |
| `title` | TEXT | indexed |
| `filePath` | TEXT | |
| `fileType` | TEXT | `pdf` \| `md` \| `txt` \| `docx` |
| `category` | TEXT | `books` \| `api-docs` \| `framework-docs` \| `notes` |
| `contentText` | TEXT | extracted plain text (searchable) |
| `embedding` | BLOB? | reserved for on-device semantic search |
| `sizeBytes` | INTEGER | |
| `pageCount` | INTEGER | |
| `createdAt` | INTEGER | |
| `lastOpenedAt` | INTEGER? | |
| `tags` | TEXT | list |

**Indexes:** `category`, `fileType`, `title`.
> **Upgrade path:** promote `contentText` to an **FTS4/FTS5** virtual table for full-text search; add a vector table for embeddings.

## `command_logs` (append-only)
| Column | Type | Notes |
|---|---|---|
| `id` | TEXT PK | |
| `createdAt` | INTEGER | indexed |
| `intent` | TEXT | detected intent id |
| `request` | TEXT | raw user request |
| `plan` | TEXT | serialised ExecutionPlan (JSON) |
| `status` | TEXT | `queued` \| `running` \| `success` \| `failed` \| `cancelled` |
| `durationMs` | INTEGER | |
| `permissionGranted` | INTEGER | |
| `errorMessage` | TEXT? | |
| `subsystem` | TEXT | `agent` \| `git` \| `file` \| `knowledge` \| `voice` \| … |
| `verificationPassed` | INTEGER | |

**Indexes:** `createdAt`, `status`, `intent`. Pruned by `createdAt` via `pruneOlderThan`.

## `memories`
| Column | Type | Notes |
|---|---|---|
| `id` | TEXT PK | |
| `scope` | TEXT | `global` \| `user` \| `project:<id>` |
| `category` | TEXT | `preference` \| `fact` \| `pattern` \| `command` \| `context` |
| `content` | TEXT | |
| `importance` | INTEGER | 1..5 (ranking) |
| `embedding` | BLOB? | reserved |
| `createdAt` | INTEGER | |
| `lastAccessedAt` | INTEGER | |
| `accessCount` | INTEGER | |

**Indexes:** `scope`, `createdAt`, `importance`.

## `file_items`
| Column | Type | Notes |
|---|---|---|
| `id` | TEXT PK | |
| `path` | TEXT UNIQUE | canonical absolute path |
| `name` | TEXT | |
| `ext` | TEXT | |
| `isDirectory` | INTEGER | |
| `sizeBytes` | INTEGER | |
| `projectId` | TEXT? | |
| `isFavorite` | INTEGER | |
| `lastOpenedAt` | INTEGER? | |
| `mimeType` | TEXT? | |

**Indexes:** unique `path`, `projectId`, `isFavorite`, `lastOpenedAt`.

---

## Migrations

Schema is exported (`ksp room.schemaLocation`). Bump `AppDatabase.VERSION` and supply a `Migration` per change. Never use `fallbackToDestructiveMigration` in production — it destroys user data; it's used here only for downgrades.

## Suggested future tables
- `git_repositories`, `git_branches`, `git_commits` (Git/GitHub sync cache)
- `templates` (project & snippet templates)
- `embeddings` (vector store for semantic Knowledge/Memory search)
