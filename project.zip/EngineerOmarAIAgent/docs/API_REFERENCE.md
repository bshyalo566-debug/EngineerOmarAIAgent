# Internal API Reference

A quick map of the public Kotlin API surface, grouped by layer. Packages are rooted at `com.engineeromar.aiagent`.

## Core

| Symbol | Purpose |
|---|---|
| `core.config.ConfigurationManager` | reactive `Flow<AppConfig>` + `suspend update(transform)` |
| `core.config.AppConfig` | immutable config snapshot (`language`, `theme`, `aiProvider`, `biometricLock`, `pinEnabled`, `performanceMode`) |
| `core.logging.Logger` | `v/d/i/w/e(tag) { msg }` façade |
| `core.logging.FileLogger` | rotating persistent log; `readRecent()`, `listLogFiles()` |
| `core.error.AppError` | sealed hierarchy: `Network/Database/Storage/AiProvider/Permission/Validation/Security/Unknown` |
| `core.error.GlobalErrorHandler` | `install()` JVM uncaught-exception handler |
| `core.error.Throwable.toAppError()` | map any throwable to `AppError` |
| `core.permission.PermissionManager` | `isGranted`, `validate(required): Result<Unit>` |
| `core.security.SecureStorage` | Keystore-backed `put/get/remove/contains/clear` |
| `core.security.BiometricAuthManager` | `availability()`, `suspend authenticate(activity, title)` |
| `core.cache.CacheManager` | `get/put/evict/prune` (LruCache + disk) |
| `core.storage.StorageDirectories` | typed `projectsDir`, `knowledgeDir`, `logsDir`, … |

## Domain

| Symbol | Purpose |
|---|---|
| `domain.util.Result<T>` | `Success(data) \| Failure(AppError)` with `map`/`flatMap` |
| `domain.model.Project`, `Conversation`, `ChatMessage`, `KnowledgeDocument`, `CommandLog`, `Memory` | immutable models |
| `domain.repository.ProjectRepository` | `observeProjects`, `getProject`, `search`, `create`, `update`, `setStatus`, `delete` |
| `domain.usecase.project.*` | `ObserveProjectsUseCase`, `CreateProjectUseCase`, `ArchiveProjectUseCase`, `DeleteProjectUseCase`, … |

## Data

| Symbol | Purpose |
|---|---|
| `data.local.db.AppDatabase` | Room DB; `projectDao()`, `conversationDao()`, `messageDao()`, `knowledgeDao()`, `commandLogDao()`, `memoryDao()`, `fileItemDao()` |
| `data.local.dao.*Dao` | typed queries (observe, search, upsert, prune) |
| `data.mapper.*Mapper` | `Entity ↔ Domain` |
| `data.repository.ProjectRepositoryImpl` | implements `ProjectRepository` |

## AI subsystem

| Symbol | Purpose |
|---|---|
| `ai.provider.AiProvider` | `suspend complete(request): CompletionResponse`; `stream(request): Flow<String>` |
| `ai.provider.OpenAiProvider` | OpenAI Chat Completions via OkHttp |
| `ai.provider.AiProviderFactory` | `forType(AiProviderType): AiProvider` |
| `ai.provider.CompletionRequest/Response`, `EngineeringSystemPrompt` | prompt/data contracts |
| `ai.engine.CommandEngine` | `suspend execute(request, subsystem): CompletionReport`; `reports: SharedFlow` |
| `ai.engine.IntentDetector` / `TaskPlanner` / `Verifier` / `ExecutorRegistry` | pipeline stages |
| `ai.engine.Executor` | strategy contract for a capability |
| `ai.memory.MemoryManager` | `remember`, `recall`, `search`, `contextBlock` |
| `ai.agent.EngineeringAgent` | `ask(...)`, `run(...)`, `remember(...)` |

## UI

| Symbol | Purpose |
|---|---|
| `ui.theme.EngineerOmarTheme` | Material 3 Luxury Black + Gold; `MainViewModel` drives dark/light |
| `ui.navigation.Destination` / `AppNavigation` | routes + NavHost |
| `feature.<name>.<Name>ViewModel` / `<Name>Screen` | MVVM per feature |
| `service.FloatingAssistantService` | overlay bubble FGS |
| `service.CommandExecutionService` | long-running command FGS |

## Build / config
- Version catalog: `gradle/libs.versions.toml` (single source of truth).
- App module: `app/build.gradle.kts`.
- Application id: `com.engineeromar.aiagent`, `minSdk 26`, `targetSdk 34`, Java 17.
