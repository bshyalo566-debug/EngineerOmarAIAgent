# User Manual (EN / دليل المستخدم)

## English

**Engineer Omar AI Agent** is your on-phone engineering companion.

### First steps
1. Open the app and finish the optional biometric/PIN setup.
2. Go to **Settings → AI Provider**, choose a provider, and paste your API key (stored encrypted on-device).
3. Tap **Projects → New Project** to register a project (Flutter, Android, Kotlin, JS/TS, etc.).
4. Open the **Agent** tab and ask Omar to generate, explain, review, or refactor code.

### Floating Assistant
- Enable **Display over other apps** when prompted.
- A draggable bubble appears; tap to expand the assistant window above any app.

### Voice
- Grant the microphone permission to use voice commands (Arabic + English).

### Privacy
- All data is stored **on your device**. Backups are encrypted with your passphrase.
- **Settings → Privacy → Delete everything** wipes all local data.

---

## العربية

**وكيل المهندس عمر الذكي** هو مساعدك الهندسي على هاتفك.

### الخطوات الأولى
1. افتح التطبيق وأكمل إعداد القفل الإلكتروني/الرقم السري (اختياري).
2. انتقل إلى **الإعدادات ← مزوّد الذكاء الاصطناعي**، اختر مزوّداً وألصق مفتاح الـ API (يُحفظ مشفّراً على الجهاز).
3. اضغط **المشاريع ← مشروع جديد** لتسجيل مشروع (فلاتر، أندرويد، كوتلين، جافاسكريبت/تايبسكريبت…).
4. افتح تبويب **المساعد** واطلب من عمر توليد، شرح، مراجعة، أو إعادة هيكلة الكود.

### المساعد العائم
- فعّل **العرض فوق التطبيقات** عند الطلب.
- تظهر فقاعة قابلة للسحب؛ اضغط عليها لتوسيع نافذة المساعد فوق أي تطبيق.

### الصوت
- امنح إذن الميكروفون لاستخدام الأوامر الصوتية (عربي + إنجليزي).

### الخصوصية
- كل بياناتك تُخزَّن **على جهازك**. النسخ الاحتياطية مشفّرة بكلمة سرّك.
- **الإعدادات ← الخصوصية ← حذف كل شيء** يمسح كل البيانات المحلية.
