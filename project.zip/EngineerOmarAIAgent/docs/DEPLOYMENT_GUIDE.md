# Deployment Guide

How to build, sign, and ship Engineer Omar AI Agent.

## Build matrix

| Flavor × Type | Output | Minify | Purpose |
|---|---|---|---|
| `standard` × `debug` | `app-debug.apk` | off | local dev |
| `standard` × `release` | `app-release.apk` / `.aab` | on (R8 + resource shrink) | Play Store + sideload |
| `fdroid` × `release` | `app-fdroid-release.apk` | on | F-Droid-style channel (no proprietary deps) |

## Generate the Gradle wrapper (one time per fresh clone)

The `gradle-wrapper.jar` is binary and intentionally not hand-authored in the
repo. Generate it once:

```bash
./bootstrap-gradle.sh
```

This uses any local Gradle (or downloads Gradle 8.9) to produce
`gradle/wrapper/gradle-wrapper.jar` and refresh `gradlew`. After that, all
builds go through `./gradlew …`.

## Release signing

1. Generate a keystore (keep it safe — loss means you cannot update the app):
   ```bash
   keytool -genkeypair -v -keystore eo-release.jks -keyalg RSA -keysize 4096 \
     -alias eo -validity 10000
   ```
2. Create **`keystore.properties`** at the repo root (git-ignored):
   ```properties
   storeFile=/absolute/path/to/eo-release.jks
   storePassword=********
   keyAlias=eo
   keyPassword=********
   ```
3. `app/build.gradle.kts` automatically wires `signingConfigs.release` when
   that file is present. Build:
   ```bash
   ./gradlew assembleStandardRelease
   ./gradlew bundleStandardRelease   # .aab for Play
   ```

> Never commit keystores or `keystore.properties`. CI injects them via secrets.

## CI/CD — `.github/workflows/ci.yml`

**On every push / PR (`main`, `develop`):**
1. Generate wrapper if missing.
2. `./gradlew lintStandardDebug`
3. `./gradlew testStandardDebugUnitTest`
4. `./gradlew assembleStandardDebug`
5. Upload test reports + debug APK as artifacts.

**On `v*` tags (release):**
1. Decode `SIGNING_KEYSTORE_BASE64` → `eo-release.jks`.
2. Write `keystore.properties` from secrets.
3. `./gradlew bundleStandardRelease` + `assembleStandardRelease`.
4. Attach signed AAB + APK to a GitHub Release (auto-generated notes).

### Required GitHub secrets (Settings → Secrets and variables → Actions)

| Secret | Value |
|---|---|
| `SIGNING_KEYSTORE_BASE64` | `base64 < eo-release.jks` |
| `SIGNING_STORE_PASSWORD` | keystore password |
| `SIGNING_KEY_ALIAS` | key alias (e.g. `eo`) |
| `SIGNING_KEY_PASSWORD` | key password |

## Cutting a release

```bash
# 1. Ensure CHANGELOG.md is updated under [Unreleased].
# 2. Bump versionCode/versionName in app/build.gradle.kts.
# 3. Commit and tag.
git commit -am "chore: release v1.0.0"
git tag v1.0.0
git push origin main --tags
```

Pushing the tag triggers the release job; the GitHub Release page will hold the
signed artifacts within ~10 minutes.

## Play Store submission checklist

- **Upload `.aab`** (size-optimised, Play handles per-device delivery).
- **Permissions:** justify each in the Play Console Data Safety form and the
  in-app permission declarations. Specifically explain:
  - `SYSTEM_ALERT_WINDOW` — Floating Assistant bubble.
  - `RECORD_AUDIO` — Voice assistant.
  - `USE_BIOMETRIC` — App lock.
  - Foreground service (`specialUse`) — explain in the submission; the
    `PROPERTY_SPECIAL_USE_FGS_SUBTYPE` is declared in the manifest.
  - `READ_MEDIA_*` — Knowledge import / File Manager.
- **Privacy policy URL** is required (the app stores data locally only; declare
  no sharing).
- **Content rating** questionnaire.
- **Data Safety:** local-only storage, encrypted backups, no ad SDKs, no
  analytics that exfiltrate PII.
- `targetSdk 34` (or whichever Play currently requires).

## F-Droid-style build

```bash
./gradlew assembleFdroidRelease
```

The `fdroid` flavor compiles with `BuildConfig.FDROID = true` so the app can
disable any proprietary code path. Real F-Droid inclusion requires a metadata
recipe (`com.engineeromar.aiagent.yml`) submitted to the F-Droid data repo.

## On-device storage layout (auto-created at first launch)

```
<app-private external>/EngineerOmarAIAgent/
   Projects/  Knowledge/  Templates/  Backups/  Downloads/  Exports/
<app-private internal>/Logs/        (rotating logs)
<cache>/EngineerOmar/               (transient)
```

## Update strategy

- `UpdateManager` checks a hosted manifest; compare semver.
- For Play-distributed builds, prefer **Play In-App Updates** (`AppUpdateManager`).
- For sideloaded builds, use a self-update flow gated behind user consent +
  signature verification.

## Backups & restore

- Encrypted backups are written to `Backups/` (DB export + settings) using a
  user passphrase derived through PBKDF2.
- Restore validates the passphrase + schema version before importing; refuses
  downgrades.
