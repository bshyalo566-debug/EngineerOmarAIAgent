# Developer Guide

How to extend Engineer Omar AI Agent without touching the core.

## Conventions
- **Language:** Kotlin 2.0, `jvmTarget = 17`.
- **Naming:** packages `com.engineeromar.aiagent.<layer>.<feature>`.
- **Immutability:** domain models are `data class` with `val` only.
- **No exception flow:** return `Result<T>`; map throwables via `toAppError()`.
- **Logging:** always via `Logger`, never `android.util.Log`.
- **DI:** constructor injection; bind interfaces in `core/di/RepositoryModule`.

## Worked example — add a "Notes" feature end-to-end

### 1. Domain
```kotlin
// domain/model/Note.kt
data class Note(val id: String, val title: String, val body: String, val createdAt: Long)

// domain/repository/NoteRepository.kt
interface NoteRepository {
    fun observe(): Flow<List<Note>>
    suspend fun save(note: Note)
}

// domain/usecase/note/SaveNoteUseCase.kt
class SaveNoteUseCase @Inject constructor(private val repo: NoteRepository) {
    suspend operator fun invoke(n: Note) = repo.save(n)
}
```

### 2. Data
```kotlin
// data/local/entity/NoteEntity.kt
@Entity(tableName = "notes")
data class NoteEntity(@PrimaryKey val id: String, val title: String, val body: String, val createdAt: Long)

// data/local/dao/NoteDao.kt
@Dao interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY createdAt DESC") fun observe(): Flow<List<NoteEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(e: NoteEntity)
}
```
Register entity in `AppDatabase` (bump `VERSION`, add a `Migration`), add the DAO accessor, and a provider in `DatabaseModule`.

```kotlin
// data/mapper/NoteMapper.kt  + data/repository/NoteRepositoryImpl.kt
```
Bind it:
```kotlin
@Binds @Singleton abstract fun bindNoteRepository(impl: NoteRepositoryImpl): NoteRepository
```

### 3. Feature (MVVM)
```kotlin
@HiltViewModel
class NoteViewModel @Inject constructor(save: SaveNoteUseCase, observe: ObserveNotesUseCase) : ViewModel() {
    val notes = observe().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    fun save(n: Note) = viewModelScope.launch { save(n) }
}

@Composable fun NoteScreen(vm: NoteViewModel = hiltViewModel()) { /* collect vm.notes */ }
```
Add a `Destination`, register the `composable` in `AppNavigation`.

### 4. Tests
- Unit test `NoteRepositoryImpl` with MockK against `NoteDao` (see `ProjectRepositoryImplTest`).
- Unit test the use case with a fake repository.

## Adding a capability to the Command Engine

```kotlin
// 1. Declare an intent
val DEPLOY = Intent("app.deploy", requiredPermissions = listOf(INTERNET))

// 2. Implement an executor
class DeployExecutor @Inject constructor(...) : Executor {
    override val handledIntent get() = DEPLOY
    override suspend fun execute(plan: ExecutionPlan): ExecutionResult { ... }
}

// 3. Register it in ExecutorRegistry, and add a detection rule in IntentDetector.
```
The engine, planner, verifier, and logging stay untouched.

## Adding an AI provider

Implement `AiProvider` and return it from `AiProviderFactory.forType(...)` for a new `AiProviderType`. The `EngineeringAgent` automatically uses it.

## Performance rules
- Observe with `Flow` + `stateIn`; collect with `collectAsStateWithLifecycle`.
- Cache AI completions via `CacheManager`.
- Heavy work → WorkManager, never a raw background thread.
- Stream LLM responses to avoid blocking the UI.
- Use `derivedStateOf` to avoid recomputing in composition.

## Code style
- 4-space indent, no wildcard imports (except Compose).
- Public API → KDoc. Keep functions short and single-purpose (SRP).
- Run `./gradlew spotlessCheck detekt test` (add Spotless/Detekt plugins for enforcement).
