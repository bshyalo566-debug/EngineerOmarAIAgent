# System Architecture

Engineer Omar AI Agent follows **Clean Architecture** with strict layering and a unidirectional dependency rule: dependencies always point **inward** toward the domain.

```
┌─────────────────────────────────────────────────────────────┐
│  PRESENTATION (feature/: Compose UI + ViewModels + Navigation)│
│   depends on → domain (use cases, models), not data          │
├─────────────────────────────────────────────────────────────┤
│  DOMAIN (pure Kotlin: models, repository interfaces, use      │
│   cases, Result/Either). No Android, no DB, no network.       │
├─────────────────────────────────────────────────────────────┤
│  DATA (Room entities+DAOs, repository impls, mappers,         │
│   AI provider implementations, network). Implements domain.   │
├─────────────────────────────────────────────────────────────┤
│  CORE (cross-cutting: DI, logging, errors, security,          │
│   permissions, cache, config, storage). Singleton subsystems. │
└─────────────────────────────────────────────────────────────┘
```

## Layers in detail

### Presentation (`feature/`, `ui/`)
- **Compose** screens, Material 3, Luxury Black + Gold theme, RTL/LTR aware.
- **ViewModels** expose `StateFlow`; state is collected with `collectAsStateWithLifecycle`.
- Navigation is centralised in `ui/navigation/` with a single `NavHost`.
- UI never touches Room/HTTP directly — only via use cases.

### Domain (`domain/`)
- Pure Kotlin. `model/` holds immutable data classes; `repository/` holds interfaces; `usecase/` orchestrates.
- `domain/util/Result.kt` — typed `Success | Failure` with explicit `AppError`. No exception-driven control flow.

### Data (`data/`)
- Room entities + DAOs (offline-first single source of truth).
- Repository **implementations** of domain interfaces; mappers convert `Entity ↔ Domain`.
- AI providers implement `ai/provider/AiProvider.kt`; the agent depends only on the interface.

### Core (`core/`)
- `di/` Hilt modules (App, Database, Network, Repository) — the composition root.
- `security/` Encrypted secrets + biometric gate.
- `permission/` single validation seam used by the Command Engine.
- `logging/`, `error/`, `cache/`, `config/`, `storage/`, `lifecycle/`, `update/`.

## Key architectural patterns

| Concern | Pattern |
|---|---|
| Dependency direction | Clean Architecture (inward only) |
| UI state | MVVM + unidirectional Flow |
| Data access | Repository + offline-first Room |
| Dependency injection | Hilt (compile-time graph) |
| Errors | Railway `Result<T>` + `AppError` |
| Extensibility | Strategy (AI providers, Executors) + Registry |
| Async | Coroutines + Flow |
| Permissions | Centralised `PermissionManager` |
| Secrets | Keystore-backed `SecureStorage` |

## The Command Engine pipeline

The deterministic core of the agent. Every privileged request flows through it:

```
User Request
   │
   ▼
[Intent Detection]      rule-based + AI escalation (IntentDetector)
   │
   ▼
[Task Planning]         ExecutionPlan (ordered steps) (TaskPlanner)
   │
   ▼
[Permission Validation] PermissionManager.validate(required)
   │  (fail-fast → CompletionReport.FAILED)
   ▼
[Execution]             ExecutorRegistry.executorFor(intent)
   │
   ▼
[Verification]          Verifier (compile/lint/exists)
   │
   ▼
[Logging]               CommandLogDao (append-only audit row)
   │
   ▼
[Completion Report]     SharedFlow<CompletionReport> → UI/logs
```

Open/Closed: adding a capability = add an `Intent`, an `Executor`, register it. **The engine core never changes.**

## Dependency rule enforcement

- Domain has **zero** Android/Room/Retrofit imports.
- Data depends on Domain (implements interfaces); Presentation depends on Domain (uses use cases).
- Hilt `@Module`s are the only place concrete implementations are bound to interfaces.

## Why this scales

- **Modular:** the `settings.gradle.kts` shows ready-to-enable `:feature:*` modules.
- **Offline-first:** Room is the source of truth; network is an enhancement.
- **Testable:** pure domain + interface seams → fast unit tests (see `TESTING.md`).
- **Secure by construction:** secrets never leave `SecureStorage`; permissions are a single choke point.
