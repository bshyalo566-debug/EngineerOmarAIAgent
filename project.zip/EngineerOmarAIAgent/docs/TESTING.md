# Testing Strategy

## Pyramid

```
        ┌──────────────┐
        │   E2E / UI   │  Compose UI tests, instrumented (androidTest)
        ├──────────────┤
        │ Integration  │  Room DAO tests (Robolectric / in-memory DB)
        ├──────────────┤
        │    Unit      │  Domain, use cases, repositories, engine (JVM)
        └──────────────┘
```

## Tools
- **JUnit 4** — runner.
- **MockK** — mocking for repositories/DAOs.
- **Truth** — fluent assertions.
- **Turbine** — `Flow` assertions.
- **kotlinx-coroutines-test** — `runTest`, virtual time.
- **Robolectric** — Room/Android unit tests on the JVM.
- **Hilt testing** — `HiltTestRunner` + `HiltAndroidRule` for DI in instrumented tests.

## What's covered (sample tests ship in `app/src/test/`)

| Test | Verifies |
|---|---|
| `CommandEngineTest` | fail-fast on missing permission; full pipeline success |
| `IntentDetectorTest` | rule mapping (commit → git, write → code, unknown → qa, url → open) |
| `ProjectRepositoryImplTest` | entity↔domain mapping; `create` persists; Flow mapping |

## Writing a repository test (pattern)

```kotlin
class NoteRepositoryImplTest {
    private val dao = mockk<NoteDao>(relaxed = true)
    private val repo = NoteRepositoryImpl(dao)

    @Test fun `save delegates to dao`() = runTest {
        repo.save(Note("1", "t", "b", 0))
        coVerify { dao.save(any()) }
    }
}
```

## Writing a use-case test

```kotlin
class SaveNoteUseCaseTest {
    @Test fun `invokes repo`() = runTest {
        val repo = mockk<NoteRepository>(relaxed = true)
        SaveNoteUseCase(repo).invoke(Note("1","t","b",0))
        coVerify { repo.save(any()) }
    }
}
```

## Compose UI test (instrumented)

```kotlin
@HiltAndroidTest
class ProjectsScreenTest {
    @get:Rule val hilt = HiltAndroidRule(this)

    @Test fun shows_empty_state() {
        composeRule.setContent { ProjectsScreen(onOpenProject = {}) }
        composeRule.onNodeWithText("New Project").assertIsDisplayed()
    }
}
```

## Performance & security testing (checklist)
- **Startup macrobenchmark** (`:benchmark` module) measures cold start.
- **Room migration tests** (`MigrationTestHelper`) for every schema bump.
- **Security:** verify no secrets in logs (grep build output), cleartext blocked, backup disabled.
- **Memory:** profile heavy screens with the Memory Profiler; assert the LruCache cap.

## CI gates
`./gradlew test` must pass. Add `connectedAndroidTest` on an emulator in CI for instrumented coverage.
