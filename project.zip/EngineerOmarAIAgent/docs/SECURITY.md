# Security & Privacy

Engineer Omar AI Agent is built **Security by Design** and **Privacy by Design**. No root. No exploits. No accessibility-service abuse. Only official Android APIs.

## Threat model & mitigations

| Threat | Mitigation |
|---|---|
| API keys / tokens stolen from device | Stored in `EncryptedSharedPreferences` (AES-GCM 256) with keys in the **Android Keystore**. Never logged. Wiped on "lock". |
| DB read by another app | App-private storage + (production) **SQLCipher**. No `android:allowBackup`. `dataExtractionRules` excludes prefs/root. |
| Privileged actions taken without consent | Every privileged action passes through `PermissionManager.validate(...)` in the Command Engine; fails fast with `AppError.Permission`. |
| Overlay abuse | `SYSTEM_ALERT_WINDOW` requested lazily; service refuses to start unless `Settings.canDrawOverlays()`. |
| Unauthorised app use | Optional **biometric** (`BiometricManager`, BIOMETRIC_STRONG / DEVICE_CREDENTIAL) + **PIN** gate at launch. |
| Credential leakage in logs | `FileLogger` lives under app-private `Logs/`; no secrets are logged. Debug tree only in `DEBUG`. |
| Supply-chain secrets in repo | `.gitignore` excludes keystores, `keystore.properties`, `secrets.properties`, `google-services.json`. |
| Crash leaking PII | Global handler logs stack traces to private files only; no remote crash reporter ships PII without consent. |
| Insecure network | HTTPS only; OkHttp does not allow cleartext; AI providers use TLS. |

## Permissions (declared + why)

| Permission | Why | Requested |
|---|---|---|
| `INTERNET`, `ACCESS_NETWORK_STATE` | AI providers, GitHub | install-time |
| `SYSTEM_ALERT_WINDOW` | Floating Assistant bubble | on-demand, with `canDrawOverlays()` check |
| `RECORD_AUDIO` | Voice assistant | on-demand |
| `READ_MEDIA_IMAGES/AUDIO/VIDEO` | Knowledge import / file manager | on-demand |
| `POST_NOTIFICATIONS` | Task notifications | on-demand |
| `USE_BIOMETRIC` / `USE_FINGERPRINT` | App lock | on-demand |
| Foreground service (`specialUse`) | Assistant + command execution | declared + explained in Play submission |

No `READ/WRITE_EXTERNAL_STORAGE`, no `MANAGE_EXTERNAL_STORAGE`, no `QUERY_ALL_PACKAGES`, no accessibility service for input automation. Privacy is non-negotiable.

## Secure secrets flow
```
User → Settings → enters API key
        └─→ SecureStorage.put(KEY, value)   (Keystore-encrypted)
Agent at call-time → SecureStorage.get(KEY) (held in memory only for the call)
                     └─→ never persisted, never logged
```

## Biometric / PIN flow
- `BiometricAuthManager.availability()` → `AVAILABLE | NO_HARDWARE | NOT_ENROLLED | UNAVAILABLE`.
- `MainActivity` (full build) gates on success when `config.biometricLock == true`.
- PIN is stored as a salted hash in `SecureStorage` (`KEY_APP_PIN_HASH`), never plaintext.

## Backups
- Encrypted with a user-supplied passphrase (Argon2/PBKDF2-derived key) written to `Backups/`.
- Restore verifies passphrase + schema version; refuses downgrade.

## What we deliberately do NOT do
- ❌ Root access or su invocation
- ❌ Accessibility service for UI automation of other apps
- ❌ Dexing/executing arbitrary code on device
- ❌ Cleartext traffic
- ❌ Shipping secrets in the APK or repo
- ❌ Background data exfiltration

## Compliance notes
- Data minimisation: only what each feature needs, stored locally.
- User control: export/delete-everything actions under Settings → Privacy.
- Transparency: every privileged command is logged to `command_logs` (auditable).
