# Security Policy

## Supported versions

| Version | Supported |
|---------|-----------|
| 1.0.x   | ✅        |
| < 1.0   | ❌        |

## Reporting a vulnerability

**Please do NOT open a public GitHub issue for security problems.**

Instead, email the maintainer privately with:
- a description of the issue and its impact,
- the minimal reproduction steps,
- the app version and Android version affected,
- any suggested fix.

We will acknowledge within 72 hours and aim to ship a fix within 30 days,
coordinating disclosure with you.

## Threat model summary

Engineer Omar AI Agent is built **Security by Design** and **Privacy by
Design**. The full threat model and mitigations live in
[`docs/SECURITY.md`](docs/SECURITY.md). Highlights:

- Secrets are stored in Keystore-backed `EncryptedSharedPreferences`; never
  logged, never in the APK.
- No root, no accessibility-service abuse across other apps, no cleartext
  traffic, no Dexing/executing arbitrary code.
- Every privileged action is gated by `PermissionManager` and audited in
  `command_logs`.
- FileProvider paths are scoped; zip extraction guards against zip-slip.
- Optional biometric / PIN lock at app launch.
