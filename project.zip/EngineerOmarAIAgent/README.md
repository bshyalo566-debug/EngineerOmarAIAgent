<div align="center">

# ⚡ Engineer Omar AI Agent

**A production-grade Android AI Engineering Platform.**
Manage your complete software-engineering workflow — from your phone.

Kotlin · Jetpack Compose · Material 3 · Hilt · Room · Coroutines/Flow · WorkManager · JGit · Retrofit

</div>

---

> **Not a chatbot.** Engineer Omar is an AI *engineering agent* — an agent
> command engine, a code editor, Git/GitHub, a knowledge base with offline
> semantic search, a floating assistant, voice, and full automation — built
> offline-first, secure by design, and ready for the Play Store.

## ✨ Highlights

| Module | What it does |
|---|---|
| **AI Agent + Command Engine** | 8-stage pipeline (Intent → Plan → Permission → Execute → Verify → Log → Report). Cloud or on-device completion. |
| **Code Editor** | Syntax highlighting (12 languages), diagnostics, formatter, find/replace, autocomplete, minimap, tabs, dark/light themes. |
| **Git Engine** | Full JGit: init, clone, status, add, commit, push, pull, fetch, checkout, merge, branches, log, diff. |
| **GitHub** | PAT-auth REST client: user, repos, create repo, commits, PRs, issues, releases. |
| **Knowledge Base** | PDF/Markdown/TXT/DOCX extraction + FTS4 keyword **and** offline TF-IDF semantic search. |
| **File Manager** | Browse, copy/move/rename/delete, ZIP compress/extract (zip-slip safe), search, favorites. |
| **Floating Assistant** | Draggable overlay bubble that expands into a full Compose panel over any app. |
| **Voice** | SpeechRecognizer STT + TextToSpeech TTS (Arabic + English). |
| **Plugin SDK** | Sandboxed, permission-scoped extension surface. |
| **Local AI** | Fully offline completion — zero network, zero API cost. |

## 🏛️ Architecture

Strict **Clean Architecture** (dependencies point inward only) + **MVVM** +
**Repository** + **Strategy** (AI providers, executors) + **Registry**
(plugins, executors). Domain is pure Kotlin — no Android, no DB, no network.

```
Presentation (feature/)  →  Domain (model/usecase/repository)  ←  Data (room/retrofit/jgit)
                                    ↑
                        Core (di/security/logging/cache/permission)
```

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## 🚀 Quick start

```bash
git clone <your-fork-url>
cd EngineerOmarAIAgent
./bootstrap-gradle.sh                    # one-time: generates the Gradle wrapper jar
./gradlew assembleStandardDebug          # build the debug APK
./gradlew testStandardDebugUnitTest      # run unit tests
./gradlew lintStandardDebug              # Android Lint
./gradlew installStandardDebug           # deploy to a device/emulator
```

**Requirements:** JDK 17, Android Studio Koala+ (AGP 8.5), API 26+ device.

### First run
1. (Optional) Enable **biometric / PIN** lock in Settings.
2. **Settings → AI Provider** → paste your key (stored Keystore-encrypted on-device), or pick **On-device (offline)**.
3. Grant **Display over other apps** to use the Floating Assistant.

## 🔐 Security & privacy

- No root. No accessibility-service abuse. No cleartext. **Official APIs only.**
- Secrets live in `EncryptedSharedPreferences` (AES-GCM 256) backed by the Android Keystore; never logged.
- Every privileged action is gated by `PermissionManager.validate(...)` and audited in `command_logs`.
- All user data stays on-device; backups are passphrase-encrypted.

Full threat model: [`docs/SECURITY.md`](docs/SECURITY.md).

## 🧪 Testing

Unit tests across the command engine, syntax highlighter, formatter,
diagnostics, find/replace, TF-IDF index, mappers, repositories, and
ViewModels. Strategy: [`docs/TESTING.md`](docs/TESTING.md).

```bash
./gradlew testStandardDebugUnitTest
```

## 📦 Release

```bash
# Local release build (needs keystore.properties — see docs/DEPLOYMENT_GUIDE.md)
./gradlew assembleStandardRelease
./gradlew bundleStandardRelease      # Play Store AAB
```

Tagging `vX.Y.Z` triggers the [CI release workflow](.github/workflows/ci.yml),
which builds and signs the AAB + APK and attaches them to a GitHub Release.

## 📚 Documentation

- [Architecture](docs/ARCHITECTURE.md)
- [Folder structure](docs/FOLDER_STRUCTURE.md)
- [Database schema](docs/DATABASE_SCHEMA.md)
- [Developer guide](docs/DEVELOPER_GUIDE.md)
- [Deployment guide](docs/DEPLOYMENT_GUIDE.md)
- [Security](docs/SECURITY.md)
- [Testing](docs/TESTING.md)
- [User manual (EN/AR)](docs/USER_MANUAL.md)
- [API reference](docs/API_REFERENCE.md)
- [Contributing](CONTRIBUTING.md)
- [Changelog](CHANGELOG.md)

## 🌍 Localization

Arabic (RTL) and English (LTR) ship by default. Strings live in
`app/src/main/res/values/` and `values-ar/`. The whole UI flips layout
direction with the system locale.

## 📄 License

[Apache License 2.0](LICENSE) — © 2024 Engineer Omar AI Agent.
